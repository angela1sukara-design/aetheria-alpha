import { ENEMY, RELATION } from "@/components/folio/data";
import { useFolio } from "@/components/folio/store";

function Meter({ name, value, max }: { name: string; value: number; max: number }) {
  const width = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <li>
      <div className="flex items-baseline justify-between gap-3">
        <span className="text-sm text-ink">{name}</span>
        <span className="text-sm text-muted tabular-nums">{value}</span>
      </div>
      <div className="mt-2 h-1 overflow-hidden rounded-full bg-ink/10">
        <div className="bar-fill h-full bg-accent" style={{ ["--v" as string]: width }} />
      </div>
    </li>
  );
}

export function PartyRail() {
  const party = useFolio((state) => state.party);
  const stage = useFolio((state) => state.stage);
  const setParty = useFolio((state) => state.setParty);
  const talking = stage === "talk";
  const enemy = party === "enemy" && !talking;

  if (enemy) {
    return (
      <div className="space-y-5">
        <div>
          <p className="text-sm text-muted">对面</p>
          <h2 className="mt-1 font-serif text-xl font-medium text-ink">敌人</h2>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex size-16 shrink-0 items-center justify-center rounded-lg border border-dashed border-ink/20 font-serif text-2xl text-ink">
            {ENEMY.mark}
          </div>
          <div className="min-w-0">
            <p className="text-sm text-ink">{ENEMY.name}</p>
            <p className="mt-1 text-sm text-muted">{ENEMY.role}</p>
            <p className="mt-1 text-sm text-faint">{ENEMY.stance}</p>
          </div>
        </div>
        <section>
          <h3 className="text-sm font-medium text-muted">状态</h3>
          <ul className="mt-3 space-y-3">
            <Meter name="体况" value={ENEMY.health} max={ENEMY.healthMax} />
          </ul>
          <p className="mt-3 text-sm text-ink">意图 · {ENEMY.intent}</p>
          <p className="mt-2 text-sm leading-relaxed text-faint">{ENEMY.note}</p>
        </section>
        <button
          type="button"
          onClick={() => setParty("npc")}
          className="min-h-11 text-sm text-muted transition-colors duration-150 hover:text-ink"
        >
          移开视线
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div>
        <p className="text-sm text-muted">对面</p>
        <h2 className="mt-1 font-serif text-xl font-medium text-ink">{talking ? "对话" : "人物"}</h2>
      </div>
      <div className="flex items-center gap-3">
        <div className="flex size-16 shrink-0 items-center justify-center rounded-lg border border-dashed border-ink/20 font-serif text-2xl text-ink">
          {RELATION.mark}
        </div>
        <div className="min-w-0">
          <p className="text-sm text-ink">{RELATION.name}</p>
          <p className="mt-1 text-sm text-muted">{RELATION.role}</p>
          <p className="mt-1 text-sm text-faint">{RELATION.presence}</p>
        </div>
      </div>
      <section>
        <h3 className="text-sm font-medium text-muted">关系</h3>
        <ul className="mt-3 space-y-3">
          <Meter name="熟悉" value={RELATION.familiarity} max={RELATION.familiarityMax} />
          <Meter name="信任" value={RELATION.trust} max={RELATION.trustMax} />
        </ul>
        <p className="mt-3 text-sm leading-relaxed text-faint">{RELATION.note}</p>
      </section>
      <section className="border-t border-ink/10 pt-5">
        <h3 className="text-sm font-medium text-muted">日程</h3>
        <ul className="mt-3 space-y-2">
          {RELATION.schedule.map((line) => (
            <li key={line} className="text-sm text-muted">
              {line}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

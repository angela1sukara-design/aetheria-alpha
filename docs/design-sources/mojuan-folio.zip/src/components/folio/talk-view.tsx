import { useEffect, useRef, useState } from "react";
import { SPEAKER, SPEAKER_META, SPEAKER_ROLE, TALK_LINES } from "@/components/folio/data";
import { useFolio } from "@/components/folio/store";
import { Typed } from "@/components/folio/typed";
import { Button } from "@/components/folio/ui";

function dialogOpen() {
  return Boolean(document.querySelector('[role="dialog"]'));
}

export function TalkView() {
  const fontScale = useFolio((state) => state.fontScale);
  const reveal = useFolio((state) => state.reveal);
  const reduceMotion = useFolio((state) => state.reduceMotion);
  const setStage = useFolio((state) => state.setStage);
  const setParty = useFolio((state) => state.setParty);
  const pushLog = useFolio((state) => state.pushLog);
  const [index, setIndex] = useState(0);
  const [skipped, setSkipped] = useState(false);
  const [lineDone, setLineDone] = useState(false);
  const instant = skipped || reveal === "instant" || reduceMotion;
  const last = index >= TALK_LINES.length - 1;
  const showChoices = lineDone && last;
  const line = TALK_LINES[index] ?? "";

  useEffect(() => {
    setSkipped(false);
    setLineDone(false);
  }, [index]);

  function advance() {
    if (showChoices) return;
    if (!lineDone) {
      setSkipped(true);
      return;
    }
    if (!last) setIndex((value) => value + 1);
  }

  function replay() {
    pushLog("对白", "回到第一句。");
    setIndex(0);
    setSkipped(false);
    setLineDone(false);
  }

  function jump(next: "page" | "cards") {
    if (next === "page") setParty("npc");
    pushLog("触发", next === "page" ? "从对白回到书页。" : "从对白进入故事卡。");
    setStage(next);
  }

  const actions = useRef({ advance, replay, jump, showChoices });
  actions.current = { advance, replay, jump, showChoices };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.repeat) return;
      const target = event.target;
      if (target instanceof Element && target.closest("button, a, input, textarea")) return;
      if (dialogOpen()) return;
      if (event.key === " ") {
        event.preventDefault();
        actions.current.advance();
      }
      if (!actions.current.showChoices) return;
      if (event.key === "1") actions.current.jump("page");
      if (event.key === "2") actions.current.jump("cards");
      if (event.key === "3") actions.current.replay();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="talk-layout">
      <div className="talk-portrait">
        <div className="talk-portrait-card">
          <p className="font-serif text-4xl text-ink">薇</p>
          <p className="mt-3 text-sm text-muted">立绘槽</p>
          <p className="mt-1 text-sm text-faint">角色图留在这里。</p>
        </div>
      </div>
      <div className="talk-lines">
        <div className="mx-auto w-full max-w-3xl px-4 py-4 lg:px-8">
          <button type="button" onClick={advance} className="w-full rounded-lg px-1 py-2 text-left">
            <h1 className="font-serif text-lg font-medium text-ink">{SPEAKER}</h1>
            <p className="mt-1 text-sm text-muted">
              {SPEAKER_ROLE} · {SPEAKER_META}
            </p>
            <p className="prose-scale mt-2 min-h-24 text-ink" data-scale={fontScale}>
              <Typed key={line} text={line} instant={instant} onDone={() => setLineDone(true)} />
            </p>
            {showChoices ? null : <p className="mt-3 text-sm text-faint">{lineDone ? "继续" : "跳过这句"}</p>}
          </button>
          {showChoices ? (
            <div className="mt-2 flex flex-col gap-2 pb-2">
              <Button variant="solid" onClick={() => jump("page")}>
                结束对话，回到书页
              </Button>
              <Button variant="ghost" onClick={() => jump("cards")}>
                她不在，去看故事卡
              </Button>
              <Button variant="quiet" className="justify-start px-0" onClick={replay}>
                再听一遍
              </Button>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}

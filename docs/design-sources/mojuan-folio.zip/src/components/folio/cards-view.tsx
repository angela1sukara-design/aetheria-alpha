import { useEffect } from "react";
import { ArrowLeft, Lock } from "lucide-react";
import { CARD_BODY, CARDS, CHANGES } from "@/components/folio/data";
import { useFolio } from "@/components/folio/store";
import { Button } from "@/components/folio/ui";
import { cn } from "@/lib/cn";

function dialogOpen() {
  return Boolean(document.querySelector('[role="dialog"]'));
}

export function CardsView() {
  const openCard = useFolio((state) => state.openCard);
  const setOpenCard = useFolio((state) => state.setOpenCard);
  const setStage = useFolio((state) => state.setStage);
  const setParty = useFolio((state) => state.setParty);
  const flashChange = useFolio((state) => state.flashChange);
  const pushLog = useFolio((state) => state.pushLog);
  const fontScale = useFolio((state) => state.fontScale);
  const card = CARDS.find((item) => item.id === openCard);
  const body = card ? CARD_BODY[card.id] : undefined;
  const spec = card ? CHANGES[card.id] : undefined;

  useEffect(() => {
    if (!openCard) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape" || dialogOpen()) return;
      event.preventDefault();
      setOpenCard(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [openCard, setOpenCard]);

  function jump(next: "page" | "talk") {
    setOpenCard(null);
    if (next === "talk") setParty("npc");
    setStage(next);
    pushLog("触发", next === "page" ? "从故事卡回到书页。" : "从故事卡进入对白。");
  }

  if (card && body) {
    return (
      <div className="h-full overflow-y-auto">
        <article className="rise mx-auto w-full max-w-prose px-4 py-6 lg:px-8 lg:py-8">
          <button
            type="button"
            onClick={() => setOpenCard(null)}
            className="inline-flex min-h-11 items-center gap-2 text-sm text-muted transition-colors duration-150 hover:text-ink"
          >
            <ArrowLeft className="size-4" aria-hidden />
            返回列表
          </button>
          <p className="mt-6 text-sm text-muted">{card.kind}</p>
          <h1 className="mt-2 font-serif text-2xl font-medium text-ink sm:text-3xl">{card.title}</h1>
          <div className="prose-scale mt-6 space-y-4 text-ink" data-scale={fontScale}>
            {body.map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
          </div>
          <div className="mt-8 flex flex-col gap-2 sm:flex-row">
            <Button
              variant="solid"
              onClick={() => {
                if (!spec) return;
                flashChange(spec);
                const sign = spec.delta > 0 ? `+${spec.delta}` : String(spec.delta);
                pushLog("属性栏", `演示「${spec.action}」。${spec.stat} ${sign}，未写入。`);
              }}
            >
              在属性栏演示
            </Button>
            <Button variant="ghost" onClick={() => setOpenCard(null)}>
              先不选
            </Button>
          </div>
          <section className="mt-8" aria-label="触发">
            <h2 className="text-sm font-medium text-muted">触发</h2>
            <ul className="mt-3 space-y-2">
              <li>
                <button
                  type="button"
                  onClick={() => jump("page")}
                  className="flex min-h-11 w-full items-center rounded-lg border border-ink/12 bg-elevated px-3 text-left text-sm text-ink transition-[scale,border-color] duration-150 ease-out hover:border-ink/25 active:scale-[0.98]"
                >
                  合上故事卡，回到书页
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => jump("talk")}
                  className="flex min-h-11 w-full items-center rounded-lg border border-ink/12 bg-elevated px-3 text-left text-sm text-ink transition-[scale,border-color] duration-150 ease-out hover:border-ink/25 active:scale-[0.98]"
                >
                  离开这里，去对白台
                </button>
              </li>
            </ul>
          </section>
        </article>
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto w-full max-w-3xl px-4 py-6 lg:px-8 lg:py-8">
        <p className="text-sm text-muted">故事卡 · 公寓</p>
        <h1 className="mt-2 font-serif text-2xl font-medium text-ink sm:text-3xl">可做的事</h1>
        <p className="mt-4 max-w-prose text-sm leading-relaxed text-muted">
          点一张卡，中间换成这张卡的正文。右边不跟着换，那里只放对面的人。
        </p>
        <ul className="stack mt-6 space-y-2">
          {CARDS.map((item) => {
            const locked = "locked" in item && item.locked;
            return (
              <li key={item.id} className="rise">
                <button
                  type="button"
                  disabled={locked}
                  onClick={() => {
                    setOpenCard(item.id);
                    pushLog("触发", `打开「${item.title}」。`);
                  }}
                  className={cn(
                    "flex min-h-11 w-full items-start gap-4 rounded-lg border border-ink/12 bg-elevated px-4 py-4 text-left transition-[scale,border-color] duration-150 ease-out hover:border-ink/25 active:scale-[0.98] disabled:hover:border-ink/12 disabled:active:scale-100",
                    locked && "opacity-60",
                  )}
                >
                  <span className="w-14 shrink-0 pt-0.5 text-xs text-faint">{item.kind}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-medium text-ink">{item.title}</span>
                    <span className="mt-1 block text-sm leading-relaxed text-muted">{item.line}</span>
                    {locked && "need" in item ? (
                      <span className="mt-2 inline-flex items-center gap-1 text-xs text-faint">
                        <Lock className="size-3" aria-hidden />
                        需要 {item.need}
                      </span>
                    ) : null}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
        <button
          type="button"
          onClick={() => jump("page")}
          className="mt-6 flex min-h-11 w-full items-center rounded-lg border border-dashed border-ink/20 px-4 text-left text-sm text-muted transition-[border-color,color] duration-150 hover:border-ink/40 hover:text-ink"
        >
          合上故事卡，回到书页
        </button>
      </div>
    </div>
  );
}

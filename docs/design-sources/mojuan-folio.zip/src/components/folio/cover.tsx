import { Button } from "@/components/folio/ui";
import { useFolio, type Stage } from "@/components/folio/store";

export function Cover() {
  const setStage = useFolio((state) => state.setStage);
  const go = (stage: Stage) => setStage(stage);

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-5xl flex-col px-4 sm:px-8">
      <header className="safe-top flex items-center justify-between py-6">
        <p className="rise text-sm text-muted">文字游戏界面</p>
        <p className="rise delay-1 text-sm text-faint">示例</p>
      </header>
      <div className="cover-layout flex-1 py-10">
        <div>
          <p className="rise text-sm text-muted">从书页里的选项往下走</p>
          <h1 className="rise delay-1 mt-4 font-serif text-5xl font-medium text-ink sm:text-6xl">墨卷</h1>
          <div className="rise delay-2 mt-6 h-px w-12 bg-ink/30" />
        </div>
        <div>
          <p className="rise delay-2 max-w-prose text-lg leading-relaxed text-muted">
            横屏时左边是常驻属性栏。故事卡和对白不在顶上，要从书页里的选项触发。数值变化记在属性栏，不另开一页。
          </p>
          <div className="rise delay-3 mt-8">
            <Button variant="solid" onClick={() => go("page")}>
              进入书页
            </Button>
          </div>
        </div>
      </div>
      <footer className="rise delay-4 py-6 text-sm text-faint">字号、揭示和动效在进入后的设置里。</footer>
    </main>
  );
}

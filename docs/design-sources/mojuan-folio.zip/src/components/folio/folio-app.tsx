import { useEffect } from "react";
import { Cover } from "@/components/folio/cover";
import { PlayShell } from "@/components/folio/shell";
import { readPersisted, useFolio, type FontScale, type Persisted, type RevealMode, type Slot } from "@/components/folio/store";

function isSlot(value: unknown): value is Slot {
  if (value === null) return true;
  if (!value || typeof value !== "object") return false;
  const record = value as { label?: unknown; at?: unknown };
  return typeof record.label === "string" && typeof record.at === "string";
}

function isFontScale(value: unknown): value is FontScale {
  return value === "sm" || value === "md" || value === "lg";
}

function isReveal(value: unknown): value is RevealMode {
  return value === "type" || value === "instant";
}

export function FolioApp() {
  const stage = useFolio((state) => state.stage);
  const reduceMotion = useFolio((state) => state.reduceMotion);

  useEffect(() => {
    const saved = readPersisted();
    const slots = saved?.slots;
    const safeSlots =
      Array.isArray(slots) && slots.length === 3 && slots.every(isSlot)
        ? (slots as Persisted["slots"])
        : undefined;
    useFolio.getState().hydrate({
      ...(isFontScale(saved?.fontScale) ? { fontScale: saved.fontScale } : {}),
      ...(isReveal(saved?.reveal) ? { reveal: saved.reveal } : {}),
      reduceMotion:
        typeof saved?.reduceMotion === "boolean"
          ? saved.reduceMotion
          : window.matchMedia("(prefers-reduced-motion: reduce)").matches,
      ...(safeSlots ? { slots: safeSlots } : {}),
    });
  }, []);

  return (
    <div data-motion={reduceMotion ? "reduce" : "full"} className="bg-canvas text-ink">
      {stage === "cover" ? <Cover /> : <PlayShell />}
    </div>
  );
}

import { useState } from "react";
import { BAG_ITEMS, CODEX, MAP_PLACES, QUESTS } from "@/components/folio/data";
import { useFolio, type Ledger } from "@/components/folio/store";
import { cn } from "@/lib/cn";

const COPY: Record<Ledger, { kicker: string; title: string; lead: string }> = {
  bag: { kicker: "背包", title: "随身", lead: "格子是空的示意。点一下只选中，不使用，也不改属性。" },
  map: { kicker: "地图", title: "这座城", lead: "只标你在哪。点别的地方不会走过去。" },
  codex: { kicker: "图鉴", title: "见过的人", lead: "点一个人，右边换成他的状态。图鉴本身不改熟悉或信任。" },
  quest: { kicker: "任务", title: "手头的事", lead: "开局几乎是空的。挂在这里的名字，要回书页才能触发。" },
};

export function LedgerView({ id }: { id: Ledger }) {
  const setLedger = useFolio((state) => state.setLedger);
  const setParty = useFolio((state) => state.setParty);
  const pushLog = useFolio((state) => state.pushLog);
  const copy = COPY[id];

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto w-full max-w-xl px-4 py-6 lg:px-8 lg:py-10">
        <p className="text-sm text-muted">{copy.kicker}</p>
        <h1 className="mt-2 font-serif text-2xl font-medium text-ink sm:text-3xl">{copy.title}</h1>
        <p className="mt-4 text-sm leading-relaxed text-muted">{copy.lead}</p>
        <div className="mt-6">
          {id === "bag" ? <Bag /> : null}
          {id === "map" ? <Map /> : null}
          {id === "codex" ? (
            <Codex
              onPick={(party, name) => {
                setParty(party);
                pushLog("图鉴", `右边换成${name}。`);
              }}
            />
          ) : null}
          {id === "quest" ? <Quest /> : null}
        </div>
        <button
          type="button"
          onClick={() => {
            setLedger(null);
            pushLog("跳转", `合上${copy.kicker}，回到刚才的页。`);
          }}
          className="mt-8 flex min-h-11 w-full items-center rounded-lg border border-dashed border-ink/20 px-4 text-left text-sm text-muted transition-[border-color,color] duration-150 hover:border-ink/40 hover:text-ink"
        >
          合上{copy.kicker}，回到刚才的页
        </button>
      </div>
    </div>
  );
}

function Bag() {
  const [picked, setPicked] = useState<string | null>(null);
  const slots = [...BAG_ITEMS.map((item) => item.name), "空", "空", "空", "空", "空"];
  const note = BAG_ITEMS.find((item) => item.name === picked)?.note;

  return (
    <div>
      <ul className="grid grid-cols-3 gap-2">
        {slots.map((name, index) => {
          const empty = name === "空";
          const on = picked === name && !empty;
          return (
            <li key={`${name}-${index}`}>
              <button
                type="button"
                disabled={empty}
                onClick={() => setPicked(on ? null : name)}
                className={cn(
                  "flex min-h-16 w-full items-center justify-center rounded-lg border px-2 text-sm transition-[border-color,color] duration-150",
                  empty && "border-ink/10 text-faint",
                  !empty && on && "border-ink/40 bg-subtle text-ink",
                  !empty && !on && "border-ink/15 text-ink hover:border-ink/30",
                )}
              >
                {name}
              </button>
            </li>
          );
        })}
      </ul>
      <p className="mt-4 min-h-6 text-sm leading-relaxed text-faint">{note ?? "没有选中的东西。"}</p>
    </div>
  );
}

function Map() {
  const pushLog = useFolio((state) => state.pushLog);

  return (
    <ul className="space-y-2">
      {MAP_PLACES.map((place) => (
        <li key={place.id}>
          <button
            type="button"
            onClick={() => pushLog("地图", place.here ? "人已经在公寓。" : `标着「${place.name}」，没有移动。`)}
            className={cn(
              "flex min-h-11 w-full items-center justify-between gap-3 rounded-lg border px-4 py-3 text-left transition-[border-color] duration-150 hover:border-ink/30",
              place.here ? "border-ink/30 bg-subtle" : "border-ink/12 bg-elevated",
            )}
          >
            <span className="text-sm text-ink">{place.name}</span>
            <span className="text-sm text-muted">{place.line}</span>
          </button>
        </li>
      ))}
    </ul>
  );
}

function Codex({ onPick }: { onPick: (party: "npc" | "enemy", name: string) => void }) {
  const party = useFolio((state) => state.party);

  return (
    <ul className="space-y-2">
      {CODEX.map((person) => {
        const on = party === person.party;
        return (
          <li key={person.id}>
            <button
              type="button"
              onClick={() => onPick(person.party, person.name)}
              className={cn(
                "flex min-h-11 w-full flex-col items-start rounded-lg border px-4 py-3 text-left transition-[border-color] duration-150 hover:border-ink/30",
                on ? "border-ink/30 bg-subtle" : "border-ink/12 bg-elevated",
              )}
            >
              <span className="text-sm text-ink">
                {person.name}
                <span className="ml-2 text-muted">{person.role}</span>
              </span>
              <span className="mt-1 text-sm leading-relaxed text-muted">{person.line}</span>
            </button>
          </li>
        );
      })}
    </ul>
  );
}

function Quest() {
  return (
    <ul className="space-y-2">
      {QUESTS.map((quest) => (
        <li key={quest.id} className="rounded-lg border border-ink/12 bg-elevated px-4 py-3">
          <div className="flex items-baseline justify-between gap-3">
            <p className="text-sm text-ink">{quest.name}</p>
            <p className="text-sm text-muted">{quest.state}</p>
          </div>
          <p className="mt-2 text-sm leading-relaxed text-faint">{quest.line}</p>
        </li>
      ))}
    </ul>
  );
}

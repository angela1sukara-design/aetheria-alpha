import { useEffect, useRef, useState } from "react";

export function Typed({
  text,
  instant,
  onDone,
}: {
  text: string;
  instant: boolean;
  onDone?: () => void;
}) {
  const [count, setCount] = useState(instant ? text.length : 0);
  const onDoneRef = useRef(onDone);
  onDoneRef.current = onDone;
  const finished = useRef(false);

  useEffect(() => {
    finished.current = false;
    setCount(instant ? text.length : 0);
  }, [text, instant]);

  useEffect(() => {
    if (instant || count >= text.length) {
      if (!finished.current) {
        finished.current = true;
        onDoneRef.current?.();
      }
      return;
    }
    const id = window.setTimeout(() => setCount((value) => value + 1), 28);
    return () => window.clearTimeout(id);
  }, [count, instant, text]);

  const done = instant || count >= text.length;
  return (
    <>
      {instant ? text : text.slice(0, count)}
      {done ? null : <span className="caret" aria-hidden="true" />}
    </>
  );
}

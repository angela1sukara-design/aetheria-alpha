import { create } from "zustand";
import type { ChangeSpec } from "@/components/folio/data";

export type Stage = "cover" | "page" | "cards" | "talk";
export type FontScale = "sm" | "md" | "lg";
export type RevealMode = "type" | "instant";
export type Slot = { label: string; at: string } | null;
export type LogItem = { id: string; title: string; detail: string };
export type ChangeFlash = ChangeSpec & { token: number };
export type Party = "npc" | "enemy";
export type Ledger = "bag" | "map" | "codex" | "quest";

export type Persisted = {
  fontScale: FontScale;
  reveal: RevealMode;
  reduceMotion: boolean;
  slots: [Slot, Slot, Slot];
};

const STORAGE_KEY = "mojuan-settings";

type FolioState = Persisted & {
  stage: Stage;
  openCard: string | null;
  log: LogItem[];
  flash: ChangeFlash | null;
  party: Party;
  ledger: Ledger | null;
  setStage: (stage: Stage) => void;
  setFontScale: (fontScale: FontScale) => void;
  setReveal: (reveal: RevealMode) => void;
  setReduceMotion: (reduceMotion: boolean) => void;
  setOpenCard: (openCard: string | null) => void;
  pushLog: (title: string, detail: string) => void;
  flashChange: (spec: ChangeSpec) => void;
  clearFlash: () => void;
  setParty: (party: Party) => void;
  setLedger: (ledger: Ledger | null) => void;
  writeSlot: (index: number) => void;
  clearSlot: (index: number) => void;
  hydrate: (partial: Partial<Persisted>) => void;
};

function persist(state: FolioState) {
  if (typeof window === "undefined") return;
  const data: Persisted = {
    fontScale: state.fontScale,
    reveal: state.reveal,
    reduceMotion: state.reduceMotion,
    slots: state.slots,
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

const emptySlots: [Slot, Slot, Slot] = [null, null, null];
let flashToken = 0;

export const useFolio = create<FolioState>((set, get) => ({
  stage: "cover",
  fontScale: "md",
  reveal: "type",
  reduceMotion: false,
  slots: emptySlots,
  openCard: null,
  log: [],
  flash: null,
  party: "npc",
  ledger: null,
  setStage: (stage) => set({ stage }),
  setFontScale: (fontScale) => {
    set({ fontScale });
    persist(get());
  },
  setReveal: (reveal) => {
    set({ reveal });
    persist(get());
  },
  setReduceMotion: (reduceMotion) => {
    set({ reduceMotion });
    persist(get());
  },
  setOpenCard: (openCard) => set({ openCard }),
  pushLog: (title, detail) =>
    set((state) => ({
      log: [{ id: `${Date.now()}-${state.log.length}`, title, detail }, ...state.log].slice(0, 24),
    })),
  flashChange: (spec) => {
    flashToken += 1;
    set({ flash: { ...spec, token: flashToken } });
  },
  clearFlash: () => set({ flash: null }),
  setParty: (party) => set({ party }),
  setLedger: (ledger) => set({ ledger }),
  writeSlot: (index) => {
    const at = new Date().toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" });
    const slots = [...get().slots] as [Slot, Slot, Slot];
    slots[index] = { label: "公寓 · 08:00", at };
    set({ slots });
    persist(get());
  },
  clearSlot: (index) => {
    const slots = [...get().slots] as [Slot, Slot, Slot];
    slots[index] = null;
    set({ slots });
    persist(get());
  },
  hydrate: (partial) => set(partial),
}));

export function readPersisted(): Partial<Persisted> | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as Partial<Persisted>;
  } catch {
    return null;
  }
}

export const SCENE = {
  place: "公寓",
  clock: "第 1 天 · 08:00",
  subtitle: "窗外的城，刚刚醒来",
};

export const PARAGRAPHS = [
  "靠窗的小桌上放着一只水杯。这一段只看行长和段距，时钟停在开局。",
  "属性栏不跟着换页。横屏时它停在左边。故事卡和对白要从下面的选项触发，不是顶上的标签。数值变化只在属性栏里走一遍。",
];

export const CHOICES = [
  { id: "cards", key: "1", title: "翻开故事卡", badge: "触发" },
  { id: "rest", key: "2", title: "在床边歇一会儿", badge: "属性栏 · 精力 +25" },
  { id: "talk", key: "3", title: "去对白台", badge: "触发" },
  { id: "foe", key: "4", title: "看向巷口的人", badge: "右侧 · 敌人" },
] as const;

export const CARDS = [
  {
    id: "rest",
    kind: "日常",
    title: "在床边歇一会儿",
    line: "60 分钟 · 精力 +25，不超过 100。",
  },
  {
    id: "tail",
    kind: "改造",
    title: "了解机械尾改造",
    line: "18 币。试装 15 分钟，校准共 45 分钟。",
  },
  {
    id: "grip",
    kind: "未开放",
    title: "用机械尾协助分拣",
    line: "需要已校准的机械尾，以及足够的精力。",
    locked: true,
    need: "尾部抓握 1 · 精力 ≥ 8",
  },
] as const;

export const CARD_BODY: Record<string, readonly string[]> = {
  rest: [
    "这一张卡只展示行动会动到的属性：时间向前 60 分钟，精力增加 25，停在上限 100。",
    "确认不会写入。属性栏把精力从 70 示意到 95，收回后仍是 70。",
  ],
  tail: [
    "诊室里的这项改造分两段：第 15 分钟试装，尾部还不能抓握；第 45 分钟校准完成，才有平衡和尾部抓握。",
    "费用记为 18 币。确认时属性栏把零钱从 60 示意到 42，不真正扣除。",
  ],
};

export const TALK_LINES = [
  "对白台先放名字。关系记两项：熟悉，信任。开局都是 0。",
  "日程示例：09:00 到 18:00 在沙龙，18:00 到 19:00 在集市。现在是 08:00，她还不在。",
  "句子说完，触发才出现。点下去才离开对白，不改熟悉或信任。",
];

export const SPEAKER = "薇尔维特";
export const SPEAKER_ROLE = "沙龙经营者";
export const SPEAKER_META = "熟悉 0 · 信任 0";

export type StatId = "money" | "energy" | "health";

export const STATS = [
  { id: "money" as const, name: "零钱", value: 60, max: 999999, unit: "币" },
  { id: "energy" as const, name: "精力", value: 70, max: 100, unit: "" },
  { id: "health" as const, name: "体况", value: 100, max: 100, unit: "" },
] satisfies ReadonlyArray<{ id: StatId; name: string; value: number; max: number; unit: string }>;

export type ChangeSpec = {
  statId: StatId;
  stat: string;
  action: string;
  before: number;
  delta: number;
  max: number;
  minutes: number;
};

export const CHANGES: Record<string, ChangeSpec> = {
  rest: {
    statId: "energy",
    stat: "精力",
    action: "在床边歇一会儿",
    before: 70,
    delta: 25,
    max: 100,
    minutes: 60,
  },
  tail: {
    statId: "money",
    stat: "零钱",
    action: "了解机械尾改造",
    before: 60,
    delta: -18,
    max: 999999,
    minutes: 45,
  },
};

export const PASSIVES = [
  {
    id: "awake",
    name: "刚醒",
    tag: "时段",
    detail: "第 1 天清晨。只标注这一档，不改变精力怎么回复。",
  },
  {
    id: "home",
    name: "在公寓",
    tag: "地点",
    detail: "人还在公寓。要去集市才能做的事，会保持锁定。",
  },
  {
    id: "body",
    name: "基础身体",
    tag: "身体",
    detail: "人类耳，没有尾部。后腰的锚点空着，尾部抓握是 0。",
  },
  {
    id: "unknown",
    name: "尚未结识",
    tag: "关系",
    detail: "薇尔维特的熟悉和信任都是 0。09:00 之前，她不在公开场所。",
  },
] as const;

export const BODY = {
  template: "人类基础身体",
  summary: "人类耳 · 没有尾部",
  abilities: [
    { id: "grasp", name: "可抓握", value: 2 },
    { id: "walk", name: "行走", value: 2 },
    { id: "tailGrip", name: "尾部抓握", value: 0 },
  ],
  parts: [
    { id: "torso", name: "人类躯干", note: "根。有机。锚点留着颈、双肩、双髋和后腰。" },
    { id: "head", name: "人类头部", note: "有机。左右耳各一个锚点。" },
    { id: "ears", name: "人类耳 ×2", note: "听觉。可换成狼耳或猫耳。示例不改。" },
    { id: "arms", name: "人类手臂 ×2", note: "有机。腕部下接手掌。" },
    { id: "hands", name: "人类手掌 ×2", note: "抓握。" },
    { id: "legs", name: "人类腿部 ×2", note: "有机。踝部下接足部。" },
    { id: "feet", name: "人类足部 ×2", note: "行走。" },
    { id: "tail", name: "没有尾部", note: "后腰空着。生物尾即时。机械尾要先试装，再校准。" },
  ],
  job: "机械尾改造 · 未开始",
};

export const RELATION = {
  name: "薇尔维特",
  mark: "薇",
  role: "沙龙经营者",
  familiarity: 0,
  trust: 0,
  familiarityMax: 100,
  trustMax: 100,
  present: false,
  presence: "不在这里",
  note: "尚未结识。09:00 前不在公开场所。",
  schedule: ["09:00–18:00 沙龙", "18:00–19:00 集市"],
};

export const ENEMY = {
  name: "巷口的人",
  mark: "影",
  role: "敌人",
  stance: "戒备",
  health: 100,
  healthMax: 100,
  intent: "观望",
  note: "还没交手。这一栏只换人，不改你的属性。",
};

export const BAG_ITEMS = [
  { id: "cup", name: "水杯", note: "空的。算进背包只是示意，人还在公寓。" },
] as const;

export const MAP_PLACES = [
  { id: "home", name: "公寓", line: "你在这里", here: true },
  { id: "salon", name: "沙龙", line: "09:00–18:00", here: false },
  { id: "market", name: "集市", line: "18:00 之后", here: false },
] as const;

export const CODEX = [
  {
    id: "velvet",
    name: "薇尔维特",
    role: "沙龙经营者",
    party: "npc" as const,
    line: "尚未结识。熟悉 0，信任 0。",
  },
  {
    id: "shade",
    name: "巷口的人",
    role: "敌人",
    party: "enemy" as const,
    line: "戒备。体况 100。还没交手。",
  },
] as const;

export const QUESTS = [
  {
    id: "rest",
    name: "在床边歇一会儿",
    state: "可从书页触发",
    line: "任务页只挂着名字。完成与否不在这里改。",
  },
] as const;

export const SLOT_NAMES = ["壹", "贰", "叁"] as const;

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { BODY, PASSIVES, SCENE, STATS } from "@/components/folio/data";
import { useFolio } from "@/components/folio/store";
import { cn } from "@/lib/cn";

type Tips = "float" | "inline";

export function StatusRail({ tips = "float" }: { tips?: Tips }) {
  const flash = useFolio((state) => state.flash);
  const clearFlash = useFolio((state) => state.clearFlash);
  const reduceMotion = useFolio((state) => state.reduceMotion);
  const [live, setLive] = useState<number | null>(null);
  const [phase, setPhase] = useState<"idle" | "run" | "hold">("idle");
  const frame = useRef(0);

  useEffect(() => {
    if (!flash) {
      setLive(null);
      setPhase("idle");
      return;
    }
    const after = Math.min(flash.max, Math.max(0, flash.before + flash.delta));
    if (reduceMotion) {
      setLive(after);
      setPhase("hold");
      return;
    }
    setPhase("run");
    setLive(flash.before);
    const from = flash.before;
    const start = performance.now();
    let alive = true;
    const tick = (now: number) => {
      if (!alive) return;
      const t = Math.min(1, (now - start) / 700);
      const eased = 1 - (1 - t) * (1 - t);
      setLive(Math.round(from + (after - from) * eased));
      if (t < 1) {
        frame.current = requestAnimationFrame(tick);
        return;
      }
      setLive(after);
      setPhase("hold");
    };
    frame.current = requestAnimationFrame(tick);
    return () => {
      alive = false;
      cancelAnimationFrame(frame.current);
    };
  }, [flash, reduceMotion]);

  const showing = Boolean(flash && phase !== "idle");

  return (
    <div className="space-y-5">
      <div>
        <p className="text-sm text-muted">常驻</p>
        <h2 className="mt-1 font-serif text-xl font-medium text-ink">属性</h2>
        <p className="mt-2 text-sm text-ink">{SCENE.place}</p>
        <p className="mt-1 text-sm text-muted tabular-nums">{SCENE.clock}</p>
      </div>
      <section>
        <h3 className="text-sm font-medium text-muted">数值</h3>
        <ul className="mt-3 space-y-3">
          {STATS.map((stat) => {
            const metered = stat.max <= 100;
            const previewing = Boolean(showing && flash?.statId === stat.id);
            const shown = previewing && live !== null ? live : stat.value;
            const width = metered ? (shown / stat.max) * 100 : 0;
            const realWidth = metered ? (stat.value / stat.max) * 100 : 0;
            const up = (flash?.delta ?? 0) > 0;
            return (
              <li key={stat.id} className="relative rounded-sm px-1 py-1">
                {previewing ? (
                  <span
                    key={flash?.token}
                    aria-hidden
                    data-dir={up ? "up" : "down"}
                    className="stat-pulse pointer-events-none absolute inset-0 rounded-sm"
                  />
                ) : null}
                <div className="relative flex items-baseline justify-between gap-3">
                  <span className="text-sm text-ink">{stat.name}</span>
                  <span
                    className={cn(
                      "text-sm tabular-nums",
                      previewing ? (up ? "text-ok" : "text-danger") : "text-muted",
                    )}
                    aria-live={previewing ? "polite" : undefined}
                  >
                    {shown}
                    {stat.unit ? ` ${stat.unit}` : ""}
                    {previewing && flash ? (
                      <span className="ml-2">
                        {flash.delta > 0 ? `+${flash.delta}` : flash.delta}
                      </span>
                    ) : null}
                  </span>
                </div>
                {metered ? (
                  <div className="relative mt-2 h-1 overflow-hidden rounded-full bg-ink/10">
                    <div
                      className={cn(
                        "h-full rounded-full",
                        previewing ? (up ? "bg-ok" : "bg-danger") : "bar-fill bg-accent",
                      )}
                      style={previewing ? { width: `${width}%` } : { ["--v" as string]: width }}
                    />
                    {previewing ? (
                      <span
                        aria-hidden
                        className="absolute top-1/2 h-2 w-px -translate-y-1/2 bg-ink/70"
                        style={{ left: `${realWidth}%` }}
                      />
                    ) : null}
                  </div>
                ) : null}
              </li>
            );
          })}
        </ul>
        {showing && flash ? (
          <div className="mt-3 rounded-lg border border-ink/12 bg-canvas/60 px-3 py-3" aria-live="polite">
            <p className="text-sm text-ink">{flash.action}</p>
            <p className={cn("mt-1 text-sm tabular-nums", flash.delta > 0 ? "text-ok" : "text-danger")}>
              {flash.stat} {flash.before} → {live ?? flash.before}
              <span className="text-muted">{phase === "run" ? " · 变化中" : " · 未写入"}</span>
            </p>
            <p className="mt-1 text-sm leading-relaxed text-faint">
              时间示意 +{flash.minutes} 分钟。时钟和开局数字都还停着。
            </p>
            {phase === "hold" ? (
              <button
                type="button"
                onClick={clearFlash}
                className="mt-2 min-h-11 text-sm text-muted transition-colors duration-150 hover:text-ink"
              >
                收回示意
              </button>
            ) : null}
          </div>
        ) : (
          <p className="mt-3 text-sm leading-relaxed text-faint">变化记在这一栏，不另开一页。</p>
        )}
      </section>
      <section className="border-t border-ink/10 pt-5">
        <h3 className="text-sm font-medium text-muted">身体</h3>
        <p className="mt-3 text-sm text-ink">{BODY.template}</p>
        <p className="mt-1 text-sm text-muted">{BODY.summary}</p>
        <ul className="mt-3 grid grid-cols-3 gap-2">
          {BODY.abilities.map((ability) => (
            <li key={ability.id} className="rounded-sm border border-ink/10 px-2 py-2">
              <p className="text-xs text-faint">{ability.name}</p>
              <p className="mt-1 text-sm text-ink tabular-nums">{ability.value}</p>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-sm text-faint">{BODY.job}</p>
      </section>
      <PassiveList tips={tips} />
    </div>
  );
}

function PassiveList({ tips }: { tips: Tips }) {
  const [active, setActive] = useState<string | null>(null);
  const [pinned, setPinned] = useState(false);
  const [box, setBox] = useState<{ top: number; left: number } | null>(null);
  const pinnedRef = useRef(false);
  const timer = useRef(0);
  pinnedRef.current = pinned;
  const open = PASSIVES.find((item) => item.id === active);

  useEffect(() => () => window.clearTimeout(timer.current), []);

  useEffect(() => {
    if (!active) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      setActive(null);
      setPinned(false);
    };
    const onScroll = () => {
      setActive(null);
      setPinned(false);
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("scroll", onScroll, true);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("scroll", onScroll, true);
    };
  }, [active]);

  function place(el: HTMLElement) {
    const rect = el.getBoundingClientRect();
    const width = 240;
    let left = rect.right + 10;
    if (left + width > window.innerWidth - 12) left = Math.max(12, rect.left - width - 10);
    let top = rect.top;
    const maxTop = window.innerHeight - 180;
    if (top > maxTop) top = Math.max(12, maxTop);
    setBox({ top, left });
  }

  function scheduleClose() {
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => {
      if (!pinnedRef.current) setActive(null);
    }, 160);
  }

  function cancelClose() {
    window.clearTimeout(timer.current);
  }

  return (
    <section className="border-t border-ink/10 pt-5">
      <div className="flex items-baseline justify-between gap-3">
        <h3 className="text-sm font-medium text-muted">被动</h3>
        <p className="text-xs text-faint">{tips === "float" ? "悬停查看" : "点按展开"}</p>
      </div>
      <ul className="mt-3 space-y-1">
        {PASSIVES.map((passive) => {
          const on = passive.id === active;
          return (
            <li key={passive.id}>
              <button
                type="button"
                aria-expanded={on}
                aria-describedby={tips === "float" && on ? `passive-${passive.id}` : undefined}
                onMouseEnter={(event) => {
                  if (tips !== "float") return;
                  cancelClose();
                  setPinned(false);
                  setActive(passive.id);
                  place(event.currentTarget);
                }}
                onMouseLeave={() => {
                  if (tips === "float") scheduleClose();
                }}
                onFocus={(event) => {
                  if (tips !== "float") return;
                  cancelClose();
                  setActive(passive.id);
                  place(event.currentTarget);
                }}
                onBlur={() => {
                  if (tips === "float" && !pinnedRef.current) scheduleClose();
                }}
                onClick={(event) => {
                  if (tips === "inline") {
                    setActive(on ? null : passive.id);
                    return;
                  }
                  const next = !(pinned && on);
                  setPinned(next);
                  setActive(next ? passive.id : null);
                  if (next) place(event.currentTarget);
                }}
                className={cn(
                  "flex min-h-11 w-full items-center justify-between gap-3 rounded-sm border px-3 text-left transition-[scale,border-color,color,background-color] duration-150 ease-out active:scale-[0.98]",
                  on ? "border-ink/30 bg-subtle text-ink" : "border-ink/10 text-muted hover:border-ink/25 hover:text-ink",
                )}
              >
                <span className="text-sm">{passive.name}</span>
                <span className="text-xs text-faint">{passive.tag}</span>
              </button>
              {tips === "inline" && on ? (
                <p className="px-3 pb-3 pt-1 text-sm leading-relaxed text-muted">{passive.detail}</p>
              ) : null}
            </li>
          );
        })}
      </ul>
      {tips === "float" && open && box && typeof document !== "undefined"
        ? createPortal(
            <div
              role="tooltip"
              id={`passive-${open.id}`}
              onMouseEnter={cancelClose}
              onMouseLeave={scheduleClose}
              className="fixed z-30 w-60 rounded-lg border border-ink/12 bg-elevated p-3 shadow-[var(--shadow-panel)]"
              style={{ top: box.top, left: box.left }}
            >
              <p className="text-xs text-faint">{open.tag}</p>
              <p className="mt-1 text-sm font-medium text-ink">{open.name}</p>
              <p className="mt-2 text-sm leading-relaxed text-muted">{open.detail}</p>
            </div>,
            document.body,
          )
        : null}
    </section>
  );
}

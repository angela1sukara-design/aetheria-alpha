import { useEffect, useState, type ButtonHTMLAttributes, type ReactNode } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import * as Switch from "@radix-ui/react-switch";
import { cn } from "@/lib/cn";

type Variant = "solid" | "ghost" | "quiet";

export function Button({
  variant = "ghost",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-sm px-4 text-sm font-medium transition-[scale,background-color,color,border-color] duration-150 ease-out active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40",
        variant === "solid" && "bg-accent text-accent-ink hover:bg-ink",
        variant === "ghost" && "border border-ink/15 bg-elevated text-ink hover:border-ink/30",
        variant === "quiet" && "bg-transparent text-muted hover:text-ink",
        className,
      )}
      {...props}
    />
  );
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
  label,
}: {
  value: T;
  options: { value: T; label: string }[];
  onChange: (value: T) => void;
  label: string;
}) {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  const index = Math.max(
    0,
    options.findIndex((option) => option.value === value),
  );

  return (
    <div
      role="tablist"
      aria-label={label}
      className={cn("relative grid rounded-md bg-subtle p-1", ready && "seg-ready")}
      style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` }}
    >
      <span
        aria-hidden
        className="seg-pill pointer-events-none absolute top-1 bottom-1 rounded-sm border border-ink/10 bg-elevated"
        style={{
          left: 4,
          width: `calc((100% - 8px) / ${options.length})`,
          transform: `translateX(${index * 100}%)`,
        }}
      />
      {options.map((option) => {
        const selected = option.value === value;
        return (
          <button
            key={option.value}
            type="button"
            role="tab"
            aria-selected={selected}
            className={cn(
              "relative z-10 min-h-11 rounded-sm px-2 text-sm font-medium transition-colors duration-150",
              selected ? "text-ink" : "text-faint hover:text-muted",
            )}
            onClick={() => onChange(option.value)}
          >
            {option.label}
          </button>
        );
      })}
    </div>
  );
}

export function Sheet({
  open,
  onOpenChange,
  title,
  description,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  children: ReactNode;
}) {
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="sheet-overlay fixed inset-0 z-40 bg-canvas/70" />
        <Dialog.Content className="sheet-panel fixed inset-y-0 right-0 z-50 flex w-full flex-col bg-elevated shadow-[var(--shadow-panel)] outline-none sm:max-w-sm">
          <div className="safe-top flex items-start justify-between gap-4 border-b border-ink/10 px-4 py-4">
            <div>
              <Dialog.Title className="font-serif text-xl font-medium text-ink">{title}</Dialog.Title>
              <Dialog.Description className="mt-1 text-sm text-muted">{description}</Dialog.Description>
            </div>
            <Dialog.Close className="inline-flex min-h-11 shrink-0 items-center rounded-sm px-3 text-sm text-muted transition-colors duration-150 hover:text-ink">
              关闭
            </Dialog.Close>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4">{children}</div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

export function ToggleRow({
  checked,
  onCheckedChange,
  label,
  hint,
}: {
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  label: string;
  hint: string;
}) {
  return (
    <label className="flex min-h-11 items-center justify-between gap-4 py-2">
      <span>
        <span className="block text-sm font-medium text-ink">{label}</span>
        <span className="mt-1 block text-sm text-muted">{hint}</span>
      </span>
      <Switch.Root
        checked={checked}
        onCheckedChange={onCheckedChange}
        aria-label={label}
        className="relative h-7 w-12 shrink-0 rounded-full border border-ink/15 bg-subtle transition-colors duration-150 data-[state=checked]:bg-accent"
      >
        <Switch.Thumb className="block size-5 translate-x-1 rounded-full bg-ink transition-transform duration-150 ease-out data-[state=checked]:translate-x-6 data-[state=checked]:bg-accent-ink" />
      </Switch.Root>
    </label>
  );
}

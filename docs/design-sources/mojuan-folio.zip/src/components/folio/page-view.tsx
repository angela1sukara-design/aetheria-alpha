import { useEffect, useRef, useState } from "react";
import { CHANGES, CHOICES, PARAGRAPHS, SCENE, STATS } from "@/components/folio/data";
import { useFolio } from "@/components/folio/store";
import { Typed } from "@/components/folio/typed";
import { Button } from "@/components/folio/ui";
import { cn } from "@/lib/cn";

function dialogOpen() {
  return Boolean(document.querySelector('[role="dialog"]'));
}

export function PageView() {
  const fontScale = useFolio((state) => state.fontScale);
  const reveal = useFolio((state) => state.reveal);
  const reduceMotion = useFolio((state) => state.reduceMotion);
  const setStage = useFolio((state) => state.setStage);
  const setParty = useFolio((state) => state.setParty);
  const flashChange = useFolio((state) => state.flashChange);
  const pushLog = useFolio((state) => state.pushLog);
  const [skipped, setSkipped] = useState(false);
  const [cursor, setCursor] = useState(0);
  const instant = skipped || reveal === "instant" || reduceMotion;
  const finished = instant || cursor >= PARAGRAPHS.length;

  useEffect(() => {
    if (instant) setCursor(PARAGRAPHS.length);
  }, [instant]);

  function choose(id: string) {
    if (id === "cards") {
      setStage("cards");
      pushLog("触发", "从书页进入故事卡。");
      return;
    }
    if (id === "talk") {
      setParty("npc");
      setStage("talk");
      pushLog("触发", "从书页进入对白。右侧是薇尔维特。");
      return;
    }
    if (id === "foe") {
      setParty("enemy");
      pushLog("对面", "右侧换成巷口的人。没有交手。");
      return;
    }
    if (id === "rest") {
      flashChange(CHANGES.rest);
      pushLog("属性栏", "演示歇一会儿。精力在属性栏里从 70 走到 95，未写入。");
    }
  }

  const chooseRef = useRef(choose);
  chooseRef.current = choose;

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.repeat) return;
      const target = event.target;
      if (target instanceof Element && target.closest("button, a, input, textarea")) return;
      if (dialogOpen()) return;
      if (event.key === " ") {
        event.preventDefault();
        setSkipped(true);
      }
      if (event.key === "1") chooseRef.current("cards");
      if (event.key === "2") chooseRef.current("rest");
      if (event.key === "3") chooseRef.current("talk");
      if (event.key === "4") chooseRef.current("foe");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="h-full overflow-y-auto">
      <div className="page-layout mx-auto w-full max-w-6xl px-4 py-6 lg:px-8 lg:py-10">
        <article className="min-w-0 max-w-prose">
          <p className="text-sm text-muted">书页 · {SCENE.clock}</p>
          <h1 className="mt-2 font-serif text-2xl font-medium text-ink sm:text-3xl">{SCENE.place}</h1>
          <p className="mt-3 text-sm text-faint">{SCENE.subtitle}</p>
          <ul className="stat-inline mt-4 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted tabular-nums">
            {STATS.map((stat) => (
              <li key={stat.id}>
                {stat.name} {stat.value}
                {stat.unit ? ` ${stat.unit}` : ""}
              </li>
            ))}
          </ul>
          <div
            className="prose-scale mt-6 space-y-4 text-ink"
            data-scale={fontScale}
            onClick={() => {
              if (!finished) setSkipped(true);
            }}
          >
            {PARAGRAPHS.map((paragraph, index) => {
              if (!instant && index > cursor) return null;
              const typing = !instant && index === cursor;
              return (
                <p key={paragraph}>
                  {typing ? (
                    <Typed
                      text={paragraph}
                      instant={false}
                      onDone={() => setCursor((value) => Math.max(value, index + 1))}
                    />
                  ) : (
                    paragraph
                  )}
                </p>
              );
            })}
          </div>
          {finished ? null : (
            <Button variant="quiet" className="mt-3 px-0" onClick={() => setSkipped(true)}>
              跳过揭示
            </Button>
          )}
        </article>
        <section className="page-choices" aria-label="触发">
          <h2 className="text-sm font-medium text-muted">触发</h2>
          <ul className="stack mt-3 space-y-2">
            {CHOICES.map((choice) => (
              <li key={choice.id} className="rise">
                <button
                  type="button"
                  onClick={() => choose(choice.id)}
                  className={cn(
                    "flex min-h-11 w-full items-center gap-3 rounded-lg border border-ink/12 bg-elevated px-3 py-3 text-left transition-[scale,border-color,background-color] duration-150 ease-out hover:border-ink/25 active:scale-[0.98]",
                  )}
                >
                  <span className="w-5 shrink-0 text-sm text-faint tabular-nums">{choice.key}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm text-ink">{choice.title}</span>
                    <span className="mt-1 block text-xs text-muted">{choice.badge}</span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-sm leading-relaxed text-faint">1 打开故事卡，3 进入对白。2 只动左边。4 把右边换成敌人。</p>
        </section>
      </div>
    </div>
  );
}

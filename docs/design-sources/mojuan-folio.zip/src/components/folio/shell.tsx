import { useEffect, useState } from "react";
import { CardsView } from "@/components/folio/cards-view";
import { SLOT_NAMES } from "@/components/folio/data";
import { LedgerView } from "@/components/folio/ledger-view";
import { PartyRail } from "@/components/folio/party";
import { PageView } from "@/components/folio/page-view";
import { StatusRail } from "@/components/folio/qualities";
import { useFolio, type FontScale, type Ledger, type RevealMode, type Stage } from "@/components/folio/store";
import { TalkView } from "@/components/folio/talk-view";
import { Button, Segmented, Sheet, ToggleRow } from "@/components/folio/ui";

const WIDE_QUERY = "(orientation: landscape) and (min-width: 720px), (min-width: 1024px)";

const LEDGERS: { id: Ledger; label: string }[] = [
  { id: "bag", label: "背包" },
  { id: "map", label: "地图" },
  { id: "codex", label: "图鉴" },
  { id: "quest", label: "任务" },
];

const SCALES: { value: FontScale; label: string }[] = [
  { value: "sm", label: "较小" },
  { value: "md", label: "标准" },
  { value: "lg", label: "较大" },
];

const REVEALS: { value: RevealMode; label: string }[] = [
  { value: "type", label: "逐字" },
  { value: "instant", label: "即时" },
];

type SheetId = "menu" | "log" | "saves" | "settings" | "qualities" | "party";

const SHEET_COPY: Record<SheetId, { title: string; description: string }> = {
  menu: { title: "菜单", description: "属性、对面、记录、存档和阅读设置。" },
  log: { title: "记录", description: "这次打开之后的操作。刷新会清空。" },
  saves: { title: "存档槽", description: "不保存剧情，只演示空槽和写入之后的样子。" },
  settings: { title: "设置", description: "字号和揭示速度会留在这台设备上。" },
  qualities: { title: "属性", description: "零钱、精力、体况，以及被动。点按可看说明。变化也在这一栏。" },
  party: { title: "对面", description: "对话的人，或巷口那个敌人。横屏时固定在右边。" },
};

export function PlayShell() {
  const stage = useFolio((state) => state.stage);
  const setStage = useFolio((state) => state.setStage);
  const setOpenCard = useFolio((state) => state.setOpenCard);
  const fontScale = useFolio((state) => state.fontScale);
  const setFontScale = useFolio((state) => state.setFontScale);
  const reveal = useFolio((state) => state.reveal);
  const setReveal = useFolio((state) => state.setReveal);
  const reduceMotion = useFolio((state) => state.reduceMotion);
  const setReduceMotion = useFolio((state) => state.setReduceMotion);
  const log = useFolio((state) => state.log);
  const slots = useFolio((state) => state.slots);
  const writeSlot = useFolio((state) => state.writeSlot);
  const clearSlot = useFolio((state) => state.clearSlot);
  const pushLog = useFolio((state) => state.pushLog);
  const ledger = useFolio((state) => state.ledger);
  const setLedger = useFolio((state) => state.setLedger);
  const flashToken = useFolio((state) => state.flash?.token);
  const [sheet, setSheet] = useState<SheetId | null>(null);

  function go(next: Stage) {
    if (next !== "cards") setOpenCard(null);
    setLedger(null);
    setStage(next);
    setSheet(null);
  }

  function openLedger(id: Ledger) {
    const next = ledger === id ? null : id;
    setLedger(next);
    setSheet(null);
    const label = LEDGERS.find((item) => item.id === id)?.label ?? id;
    pushLog("跳转", next ? `打开${label}。` : `合上${label}。`);
  }

  useEffect(() => {
    if (flashToken === undefined) return;
    const wide = window.matchMedia(WIDE_QUERY).matches;
    if (!wide) setSheet("qualities");
  }, [flashToken]);

  const copy = sheet ? SHEET_COPY[sheet] : SHEET_COPY.menu;

  return (
    <div className="flex h-dvh flex-col bg-canvas">
      <header className="play-header safe-top gap-3 border-b border-ink/10 px-4 py-2 md:px-6">
        <button
          type="button"
          onClick={() => go("cover")}
          className="min-h-11 shrink-0 rounded-sm px-1 font-serif text-lg text-ink"
        >
          墨卷
        </button>
        <nav className="ledger-nav" aria-label="手册">
          {LEDGERS.map((item) => {
            const on = ledger === item.id;
            return (
              <button
                key={item.id}
                type="button"
                aria-current={on ? "page" : undefined}
                onClick={() => openLedger(item.id)}
                className={
                  on
                    ? "min-h-11 min-w-28 rounded-sm border border-ink/40 bg-subtle px-4 text-sm text-ink"
                    : "min-h-11 min-w-28 rounded-sm border border-ink/15 px-4 text-sm text-muted transition-[border-color,color] duration-150 hover:border-ink/30 hover:text-ink"
                }
              >
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="header-end">
          <div className="chrome-wide">
            <Button variant="quiet" onClick={() => setSheet("log")}>
              记录
            </Button>
            <Button variant="quiet" onClick={() => setSheet("saves")}>
              存档
            </Button>
            <Button variant="quiet" onClick={() => setSheet("settings")}>
              设置
            </Button>
          </div>
          <Button variant="quiet" className="chrome-narrow" onClick={() => setSheet("menu")}>
            菜单
          </Button>
        </div>
      </header>
      <div className="flex min-h-0 flex-1">
        <aside className="status-rail shrink-0 border-r border-ink/10 bg-elevated" aria-label="属性">
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain pt-4 pr-4 pb-[max(1rem,env(safe-area-inset-bottom))] pl-[max(1rem,env(safe-area-inset-left))]">
            <StatusRail tips="float" />
          </div>
        </aside>
        <main className="min-h-0 min-w-0 flex-1">
          {ledger ? <LedgerView id={ledger} /> : null}
          {!ledger && stage === "page" ? <PageView /> : null}
          {!ledger && stage === "cards" ? <CardsView /> : null}
          {!ledger && stage === "talk" ? <TalkView /> : null}
        </main>
        <aside className="party-rail shrink-0 border-l border-ink/10 bg-elevated" aria-label="对面">
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain pt-4 pr-[max(1rem,env(safe-area-inset-right))] pb-[max(1rem,env(safe-area-inset-bottom))] pl-4">
            <PartyRail />
          </div>
        </aside>
      </div>
      <Sheet open={sheet !== null} onOpenChange={(open) => (open ? null : setSheet(null))} title={copy.title} description={copy.description}>
        {sheet === "menu" ? (
          <div className="flex flex-col gap-2">
            <Button variant="ghost" className="justify-start" onClick={() => setSheet("qualities")}>
              属性
            </Button>
            <Button variant="ghost" className="justify-start" onClick={() => setSheet("party")}>
              对面
            </Button>
            {LEDGERS.map((item) => (
              <Button key={item.id} variant="ghost" className="justify-start" onClick={() => openLedger(item.id)}>
                {item.label}
              </Button>
            ))}
            <Button variant="ghost" className="justify-start" onClick={() => setSheet("log")}>
              记录
            </Button>
            <Button variant="ghost" className="justify-start" onClick={() => setSheet("saves")}>
              存档槽
            </Button>
            <Button variant="ghost" className="justify-start" onClick={() => setSheet("settings")}>
              设置
            </Button>
            <Button variant="quiet" className="justify-start" onClick={() => go("cover")}>
              返回封面
            </Button>
          </div>
        ) : null}
        {sheet === "qualities" ? <StatusRail tips="inline" /> : null}
        {sheet === "party" ? <PartyRail /> : null}
        {sheet === "log" ? (
          log.length === 0 ? (
            <p className="text-sm leading-relaxed text-muted">还没有操作。点过触发、展开故事卡，或在属性栏演示变化之后，会记在这里。</p>
          ) : (
            <ul className="space-y-4">
              {log.map((item) => (
                <li key={item.id} className="border-b border-ink/10 pb-4">
                  <p className="text-sm font-medium text-ink">{item.title}</p>
                  <p className="mt-1 text-sm leading-relaxed text-muted">{item.detail}</p>
                </li>
              ))}
            </ul>
          )
        ) : null}
        {sheet === "saves" ? (
          <ul className="space-y-3">
            {slots.map((slot, index) => (
              <li key={SLOT_NAMES[index]} className="rounded-xl border border-ink/12 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-medium text-ink">槽位 {SLOT_NAMES[index]}</p>
                    <p className="mt-1 text-sm text-muted tabular-nums">
                      {slot ? `${slot.label} · ${slot.at}` : "空"}
                    </p>
                  </div>
                  {slot ? (
                    <Button
                      variant="quiet"
                      onClick={() => {
                        clearSlot(index);
                        pushLog("存档", `清空了槽位${SLOT_NAMES[index]}。`);
                      }}
                    >
                      清空
                    </Button>
                  ) : (
                    <Button
                      variant="ghost"
                      onClick={() => {
                        writeSlot(index);
                        pushLog("存档", `往槽位${SLOT_NAMES[index]}写入了示意。`);
                      }}
                    >
                      写入示意
                    </Button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        ) : null}
        {sheet === "settings" ? (
          <div className="space-y-6">
            <div>
              <p className="text-sm font-medium text-ink">字号</p>
              <div className="mt-3">
                <Segmented label="字号" value={fontScale} options={SCALES} onChange={setFontScale} />
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-ink">揭示</p>
              <div className="mt-3">
                <Segmented label="揭示" value={reveal} options={REVEALS} onChange={setReveal} />
              </div>
              {reduceMotion ? <p className="mt-2 text-sm text-muted">动效关闭时，文字改为即时出现。</p> : null}
            </div>
            <ToggleRow
              checked={reduceMotion}
              onCheckedChange={setReduceMotion}
              label="减弱动效"
              hint="停掉入场位移和逐字光标。"
            />
          </div>
        ) : null}
      </Sheet>
    </div>
  );
}

# B2-xianxia-delivery

```json
{
  "format": "aetheria-install/1",
  "lane": "words",
  "base": "6e7e950b42b18d3131bb50efba7a38d8a1434c34",
  "status": "authored",
  "touched": [
    "B2-xianxia-delivery.json"
  ],
  "generated": [],
  "build": [],
  "verify": [
    "node production/collaboration-pack/tools/validate-delivery.mjs B2-xianxia-delivery.json"
  ],
  "notDone": [
    "待整合方执行独立场景语义审定；原稿仅含 draft/hold。"
  ]
}
```

## 批次统计与分账

- 任务：`B2`
- 题材：`xianxia`
- 批次号：`b2-xianxia-v1`（`revision`: `2`）
- 总条数：70 条（`draft` 30 条 / `hold` 40 条）

### 子池明细
- `action.observed`：共 40 条（`draft` 20 / `hold` 20）
- `actor.form`：共 30 条（`draft` 10 / `hold` 20）

## 手工预览（`manual` / `hypothetical-only`）

1. `assembly.05.demo.observation` (`manual` / `hypothetical-only`)：在工坊，你留意到阿洛·灰谷的手。对方在庶务堂外按次序排队等候。你注意到一只量杯，其中盛着过滤水。你察觉到草木的清香。你可以结束观察。
2. `assembly.05.demo.observation` (`manual` / `hypothetical-only`)：在工坊，你留意到阿洛·灰谷的手。对方按药性分类挑拣晒干的药材。你注意到一只量杯，其中盛着过滤水。你察觉到草木的清香。你可以结束观察。
3. `assembly.05.demo.observation` (`manual` / `hypothetical-only`)：在工坊，你留意到阿洛·灰谷的手。对方盘膝静坐收敛心神冥想。你注意到一只量杯，其中盛着过滤水。你察觉到草木的清香。你可以结束观察。

# NPC整包生产报告

- scope: npc
- producer: ai-npc
- model: Grok Bot
- 目标: 2800 / 56
- 实际: **2800 / 56**

## 各类
| npc-address | 150 | 150 |
| npc-alias | 200 | 200 |
| npc-expression | 200 | 200 |
| npc-goal | 200 | 200 |
| npc-habit | 200 | 200 |
| npc-history | 200 | 200 |
| npc-identity | 150 | 150 |
| npc-interest | 150 | 150 |
| npc-job | 300 | 300 |
| npc-name | 400 | 400 |
| npc-origin | 150 | 150 |
| npc-speech | 150 | 150 |
| npc-trait | 200 | 200 |
| npc-value | 150 | 150 |

## 自查
- 校验：通过
- 未完成：无

# 身体与外观整包生产报告

- scope: body
- producer: ai-body
- model: Grok Bot
- 目标: 2050 条 / 41 批次
- 实际交付: **2050 条 / 41 批次**

## 各类数量
| body-accessory | 150 | 150 |
| body-anomaly | 150 | 150 |
| body-beast | 200 | 200 |
| body-build | 150 | 150 |
| body-clothing | 200 | 200 |
| body-color | 150 | 150 |
| body-form | 200 | 200 |
| body-hair | 150 | 150 |
| body-mechanical | 200 | 200 |
| body-organ | 200 | 200 |
| body-scale | 100 | 100 |
| body-surface | 200 | 200 |

## 自查
- JSON/ID/子类/主题/producer 校验：通过
- 同库 name 精确重复：已检查
- 未完成批号：无

## 需后续编辑复核
- 语义近似未自动去重；器官/形态仅为外观描述素材

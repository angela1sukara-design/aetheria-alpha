# 世界与环境整包生产报告

- scope: world
- producer: ai-world
- model: Grok Bot
- 目标: 2350 条 / 47 批次
- 实际交付: **2350 条 / 47 批次（完整）**

## 各类数量

| 词库 | 目标 | 实际 | 批号 |
|---|---:|---:|---|
| world-terrain | 150 | 150 | b0001–b0003 |
| world-building | 200 | 200 | b0001–b0004 |
| world-room | 150 | 150 | b0001–b0003 |
| world-district | 150 | 150 | b0001–b0003 |
| world-nature | 150 | 150 | b0001–b0003 |
| world-weather | 200 | 200 | b0001–b0004 |
| world-culture | 200 | 200 | b0001–b0004 |
| world-workplace | 200 | 200 | b0001–b0004 |
| world-object | 200 | 200 | b0001–b0004 |
| world-facility | 150 | 150 | b0001–b0003 |
| world-detail | 300 | 300 | b0001–b0006 |
| world-scent | 150 | 150 | b0001–b0003 |
| world-sound | 150 | 150 | b0001–b0003 |

## 自查

- JSON 可解析；顶层 format / schemaVersion / library / batchId / source / entries 齐全
- 每批 50 条；ID 连续 `lx.{library}.bXXXX.0001–0050`
- subcategory 均落在 catalog 合法子类；named/phrase 字段正确
- 批号与 production-plan 主题一致；producer=ai-world
- 同库 name/text 精确重复：0
- 未完成批号：无

## 需后续编辑复核

- 语义近似（近义改写）未做自动语义去重，建议人工抽检各库
- 字面近似报告不能替代叙事审稿
- 本包为纯素材，不含规则/权重/交互承诺

## 交付物

- lexicon-delivery.json（scope=world，47 batches）
- production-report.md（本文件）
- batches/ 下独立批次文件（便于追溯）

# 行为与日常整包生产报告

- scope: daily
- producer: ai-daily
- model: Grok Bot
- 实际: **1500 / 30**

| daily-food | 150 | 150 |
| daily-interact | 200 | 200 |
| daily-life | 200 | 200 |
| daily-move | 150 | 150 |
| daily-observe | 150 | 150 |
| daily-rest | 150 | 150 |
| daily-social | 150 | 150 |
| daily-talk | 150 | 150 |
| daily-work | 200 | 200 |

自查：通过

# 文字素材整包生产报告

- scope: text
- producer: ai-text
- model: Grok Bot
- 实际: **2000 / 40**

| text-body | 200 | 200 |
| text-emotion | 200 | 200 |
| text-encounter | 200 | 200 |
| text-environment | 200 | 200 |
| text-farewell | 150 | 150 |
| text-opening | 200 | 200 |
| text-refusal | 150 | 150 |
| text-reply | 300 | 300 |
| text-tf-adapt | 200 | 200 |
| text-tf-sense | 200 | 200 |

自查：通过

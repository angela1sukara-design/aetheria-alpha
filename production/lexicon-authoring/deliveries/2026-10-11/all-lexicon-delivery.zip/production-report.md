# 全词库整包生产报告

- scope: all
- model: Grok Bot
- 目标: 10700 / 214
- 实际: **10700 / 214**

- world: 47 batches / 2350 entries
- body: 41 batches / 2050 entries
- npc: 56 batches / 2800 entries
- text: 40 batches / 2000 entries
- daily: 30 batches / 1500 entries

各 scope producer: world=ai-world, body=ai-body, npc=ai-npc, text=ai-text, daily=ai-daily。
五份分 scope 交付亦已分别打包。

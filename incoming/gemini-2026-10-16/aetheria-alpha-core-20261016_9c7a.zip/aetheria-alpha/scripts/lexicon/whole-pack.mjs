import { catalog, groups } from './catalog.mjs';
import { scopeTasks } from './library.mjs';
export function wholePrompt(scope='all',producer='ai-main') {
 const tasks=scopeTasks(scope),categories=catalog.filter(c=>scope==='all'||c.group===scope),count=tasks.reduce((n,t)=>n+t.size,0);
 return `# 《以太都市：深渊重塑》基础词条整包生产总指令\n\n`+
 `你负责本次整包素材生产项目。范围：${scope==='all'?'全部五大类词库':groups[scope]}（scope=${scope}），共${categories.length}个分类、${count}条目标素材。本次producer统一填写“${producer}”。请从规划、写作到自查连续完成整个范围，尽量在一次委派中交付全部结果，不要每50条向用户请示，也不要只交几条例子或写作计划。\n\n`+
 `## 工作方式\n\n先读取catalog.json、production-plan.json、02-格式与示例.md和batch.schema.json，按本范围核对目标。旧tasks目录中的50条是内部编号和文件整理单位，旧文档中的试产建议不是本次停止点。由你自行连续处理全部${tasks.length}个内部批次；用户无需逐批发指令。无需逐一复读214份重复任务，批号、数量、主题以production-plan.json为准。\n\n`+
 `有文件工具时直接创建JSON文件，在本地持续写作、校验、修正、保存；不要把数千条都挤在一条聊天消息里。完成后交付一个压缩包，包含lexicon-delivery.json和production-report.md。lexicon-delivery.json汇总全部内部批次，用户只接收一次最终交付。可以额外附独立批次文件方便追溯，但不可仅交文件名或伪造下载链接。\n\n`+
 `若当前环境不能创建文件，按分类连续输出完整JSON，不需每批询问许可。若服务或输出长度限制使你不能继续，在完整文件边界保存/说明实际完成量、尚缺批号和继续位置；可执行时继续，不要用省略号、截断JSON、脚本循环或虚假“已完成”补齐。一次委派不代表任何模型保证一条消息输出上万条；你的目标是尽量完成整包并保留真实进度。\n\n`+
 `## 纯素材边界与质量\n\n只生产名称、描述、表现例句、对白和短描。不设计生成算法、概率、权重、互斥、条件、事件机制、奖励、数值、状态效果、日程、NPC行为树、BodyGraph拓扑或完整TF方案。未实现的器官、生态、文明与形态可以作为描述入库，不得标成已实现。完整事件、支线或世界模拟不混入素材。\n\n`+
 `使用原创、具体、自然的中文，兼顾朴素生活、不同审美、善意、疲惫、好奇、克制幽默与陌生感。命名不绑定性别、职业或性格。对白不代替另一方同意；身体素材不声称当前玩家拥有相应结构。TF只写感受与适应，不写执行结果或能力加成。没有固定人物秘密或主线剧情。\n\n`+
 `命名通常1–12字，简述20–60字，表现例句10–40字；对白10–60字，身体/环境短描40–100字。短而有区分，不把上限当目标。避免同义词堆叠、只换颜色/职业/器官、统一句式和编号填充。每个词库改变观察焦点、生活处境、语气、材料、表达距离与意象；先确定核心差异，再写正文。允许自己做工作清单与查重，但禁止用模板替换或循环拼词来冒充原创生产。\n\n`+
 `## 本范围分类与数量\n\n|词库|名称|字段类型|目标|子类|变化方向|\n|---|---|---|---:|---|---|\n`+
 categories.map(c=>`|${c.code}|${c.label}|${c.kind}|${c.target}|${c.subcategories.join('、')}|${c.variation}|`).join('\n')+
 `\n\n## 输出格式\n\n整包根对象只能有四个字段：\n\n\`\`\`json\n{\n  "format": "aetheria-lexicon-delivery",\n  "schemaVersion": 1,\n  "scope": "${scope}",\n  "batches": []\n}\n\`\`\`\n\nbatches在正式交付时必须填满本范围${tasks.length}个完整批次，不能留空。每个批次沿用batch.schema.json的原格式：format、schemaVersion、library、batchId、source、entries。source只包含producer、model、theme，producer填${producer}，model如实填写或unknown，theme沿用production-plan.json对应批次的主题。不得擅改批号、借用范围外ID或跳号。\n\n`+
 `每条必填id、category、subcategory、description；named加name，trait加name及1–3条examples，phrase加text。可选tags与synonyms确有需要再写，没有则省略。name最多40字、description最多240字、text最多400字、examples每条最多160字；tags最多6个且每个30字，synonyms最多6个且每个40字。分类只是整理语义，不是规则条件。其余字段禁止。\n\n`+
 `ID示例lx.npc-trait.b0001.0001：每个内部批次通常50条，从0001连续到0050；一个分类可以有多个批次。不是要求用户发50次指令。正确单条格式参照examples中对应分类的JSON，不复制样例凑数，不使用写作者自报approved。\n\n`+
 `## 自查与最终交付\n\n逐分类核对条数、子类覆盖、ID、来源、错字、视角、重复和规则越界。对全范围检查精确重复与核心语义雷同，发现后改写并保持总量。能运行JSON解析器时实际运行，不得虚报执行结果；结构校验不等于叙事审稿。\n\nproduction-report.md写明实际交付各类数量、完成与未完成批号、自查执行情况、需要后续编辑复核的问题。报告与素材文件分开，不往词条里塞进度或规则。未完成时真实列缺口，不把计划数写成完成数。只有本范围全部${count}条齐备，才标为完整交付；部分成果可交回保存，由整理者决定继续位置。游戏接入和最终审定由项目方处理。\n`;
}

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { loadPacks } from '../src/content/loader.ts';
import { ActionExecutor } from '../src/engine/executor.ts';
import { createGameState } from '../src/engine/state.ts';
import { evaluate } from '../src/engine/conditions.ts';
import { SaveCodec, validateState } from '../src/persistence/codec.ts';
import type { Id } from '../src/core/types.ts';

const json = async (p: string) => JSON.parse(await readFile(new URL('../' + p, import.meta.url), 'utf8'));

async function registryOf() {
  const index = await json('content/index.json');
  const inputs = await Promise.all(index.packs.map((p: string) => json('content/' + p)));
  return loadPacks(inputs);
}

test('defeat-play G1–G8 multi-beat prose fills loaded', async () => {
  const fills = await json('content/nsfw-auto-combo/defeat-play-fills.json');
  assert.equal(fills.format, 'aetheria-defeat-play-prose-fills');
  assert.equal(fills.schemaVersion, 2);
  assert.equal(Object.keys(fills.texts).length, 64);
  assert.equal(fills.worldTag, 'worlds:setting.fantasy');
  assert.equal(fills.gameplayCategories.length, 8);
  assert.equal(Object.keys(fills.peakSamplesNotInstalled || {}).length, 0);

  const candidates = await json('content/nsfw-auto-combo/defeat-play-candidates.json');
  assert.equal(candidates.plays.length, 8);
  assert.equal(candidates.proseFillsApplied, 64);
  assert.deepEqual(candidates.stageChain, ['capture', 'press', 'peak', 'resolve']);
  assert.deepEqual(candidates.hubPages.hub3, ['G5', 'G6']);
  assert.equal(candidates.plays[0].multiBeat, true);
  assert.equal(candidates.plays[3].multiBeat, true);
  assert.ok(candidates.plays[0].stages.press);
  assert.ok(candidates.plays[0].stages.resolve);
  assert.ok(candidates.plays[4].stages.press);
  assert.ok(candidates.plays[4].stages.resolve);
  assert.equal(candidates.plays[4].stages.escalate, undefined);

  const draws = await json('content/nsfw-auto-combo/defeat-play-draws.json');
  assert.equal(draws.format, 'aetheria-defeat-play-draws');
  assert.ok(draws.tfs.every((t: string) => t === '黏液化' || t === '黑胶化'));

  const registry = await registryOf();
  for (const n of [1, 2, 3]) {
    for (const stage of ['capture', 'press', 'peak', 'resolve']) {
      assert.ok(registry.narrativeNodes.some(node => node.id === `progression:node.defeat.g${n}.${stage}`), `missing g${n}.${stage}`);
      assert.ok(registry.narrativeNodes.some(node => node.id === `progression:node.defeat.g${n}.${stage}.adult`), `missing g${n}.${stage}.adult`);
      const body = registry.text(`progression:text.node.defeat.g${n}.${stage}` as Id);
      assert.ok(body.length >= 40, body.slice(0, 40));
      assert.ok(!body.includes('【槽'), 'should not be empty stub slot');
      assert.ok(!body.includes('故事侧可填'), 'should not be engine placeholder');
      const adult = registry.text(`progression:text.node.defeat.g${n}.${stage}.adult` as Id);
      assert.ok(adult.length >= 40, adult.slice(0, 40));
      assert.ok(!adult.includes('成人门'), 'adult body must not carry gate copy');
      assert.ok(!adult.includes('【可填成人'), 'adult should be filled prose');
    }
  }
  for (const n of [4, 5, 6, 7, 8]) {
    for (const stage of ['capture', 'press', 'peak', 'resolve']) {
      assert.ok(registry.narrativeNodes.some(node => node.id === `progression:node.defeat.g${n}.${stage}`), `missing g${n}.${stage}`);
      assert.ok(registry.narrativeNodes.some(node => node.id === `progression:node.defeat.g${n}.${stage}.adult`), `missing g${n}.${stage}.adult`);
      const body = registry.text(`progression:text.node.defeat.g${n}.${stage}` as Id);
      assert.ok(body.length >= 40, body.slice(0, 40));
      assert.ok(!body.includes('【槽'), 'should not be empty stub slot');
      assert.ok(!body.includes('故事侧可填'), 'should not be engine placeholder');
      assert.ok(!body.includes('可核对或回安全'), 'should not be stub checklist prose');
      const adult = registry.text(`progression:text.node.defeat.g${n}.${stage}.adult` as Id);
      assert.ok(adult.length >= 40, adult.slice(0, 40));
      assert.ok(!adult.includes('成人门'), 'adult body must not carry gate copy');
    }
    assert.ok(!registry.narrativeNodes.some(node => node.id === `progression:node.defeat.play.0${n}.escalate`));
  }
  assert.ok(!registry.narrativeNodes.some(n => n.id.includes('.escalate')));
  assert.ok(!registry.narrativeNodes.some(n => n.id.includes('.aftermath')));
  assert.ok(registry.narrativeNodes.some(n => n.id === 'progression:node.defeat.play.hub'));
  assert.ok(registry.narrativeNodes.some(n => n.id === 'progression:node.defeat.play.hub3'));
  assert.ok(registry.narrativeNodes.some(n => n.id === 'progression:node.defeat.play.hub4'));
  assert.equal(registry.action('progression:action.defeat.play' as Id).label, '试跑战败后 8 玩法');

  const hub3 = registry.narrativeNodes.find(n => n.id === 'progression:node.defeat.play.hub3')!;
  assert.ok(hub3.choices.some(c => c.next === 'play-05'), 'hub3 must expose play-05 产卵灌注');
  assert.ok(hub3.choices.some(c => c.next === 'play-06'));
  assert.ok(hub3.choices.some(c => c.next === 'play-hub-last'), 'hub3 continues to hub4 for G7/G8');
});

test('defeat.play action opens hub under fantasy play entry tag', async () => {
  const registry = await registryOf();
  const s = createGameState(registry, 17);
  s.world.locationId = 'district:location.canal' as Id;
  if (!s.world.knownLocationIds.includes(s.world.locationId)) s.world.knownLocationIds.push(s.world.locationId);
  const e = new ActionExecutor(registry, s);
  const act = e.view().actions.find(o => o.definition.id === 'progression:action.defeat.play');
  assert.ok(act?.available);
  const result = e.performAction({ actionId: 'progression:action.defeat.play' as Id }, e.snapshot().meta.revision, 'defeat-play-1');
  assert.equal(result.ok, true, result.message);
  const story = e.snapshot().adventure!.story!;
  assert.equal(story.kind, 'defeat');
  assert.equal(story.profileId, 'progression:profile.defeat.play');
  assert.ok(story.nodeId.includes('defeat.play'));
  assert.ok(story.tags.some(t => t.tagId === 'progression:tag.defeat.play.active' && t.role === 'opponent'));
  assert.ok(story.fills?.material, 'entry draw should fill material');
  assert.ok(story.fills?.part, 'entry draw should fill part');
  assert.ok(story.fills?.tf === '黏液化' || story.fills?.tf === '黑胶化');
  assert.doesNotMatch(story.opponentName, /占位/);assert.ok(story.opponentName.length>0);
});

test('G1 four-beat chain: capture→press→peak→resolve with exit kept', async () => {
  const registry = await registryOf();
  const s = createGameState(registry, 17);
  s.world.locationId = 'district:location.canal' as Id;
  if (!s.world.knownLocationIds.includes(s.world.locationId)) s.world.knownLocationIds.push(s.world.locationId);
  const e = new ActionExecutor(registry, s);
  assert.equal(e.performAction({ actionId: 'progression:action.defeat.play' as Id }, e.snapshot().meta.revision, 'g1-chain').ok, true);

  const pick = (label: string) => {
    const view = e.view();
    const idx = view.actions.findIndex(a => a.definition.label === label && a.available);
    assert.ok(idx >= 0, `missing choice ${label}; have ${view.actions.map(a => a.definition.label).join(' | ')}`);
    const r = e.performAction({ actionId: view.actions[idx]!.definition.id }, e.snapshot().meta.revision, `c-${label}`);
    assert.equal(r.ok, true, r.message);
  };

  pick('进入：束缚制服');
  assert.equal(e.snapshot().adventure!.story!.stage, 'play-01');
  assert.ok(e.snapshot().adventure!.story!.nodeId.endsWith('defeat.g1.capture'));
  const captureText = e.view().sceneText;
  assert.ok(captureText.includes('束缚带') || captureText.includes('{opponent}') || captureText.length > 40, captureText.slice(0, 80));
  assert.ok(e.view().actions.some(a => a.definition.label === '结束当前经历，回到安全位置' && a.available));

  pick('继续：加压收紧');
  assert.equal(e.snapshot().adventure!.story!.stage, 'play-01-press');
  assert.ok(e.snapshot().adventure!.story!.nodeId.endsWith('defeat.g1.press'));

  pick('继续：推向高峰');
  assert.equal(e.snapshot().adventure!.story!.stage, 'play-01-peak');

  pick('继续：收束脱困');
  assert.equal(e.snapshot().adventure!.story!.stage, 'play-01-resolve');
  assert.ok(e.snapshot().adventure!.story!.nodeId.endsWith('defeat.g1.resolve'));
  assert.ok(e.view().actions.some(a => a.definition.label === '结束当前经历，回到安全位置' && a.available));
});

test('hub3 path reaches play-05 four-beat chain', async () => {
  const registry = await registryOf();
  const s = createGameState(registry, 17);
  s.world.locationId = 'district:location.canal' as Id;
  if (!s.world.knownLocationIds.includes(s.world.locationId)) s.world.knownLocationIds.push(s.world.locationId);
  const e = new ActionExecutor(registry, s);
  assert.equal(e.performAction({ actionId: 'progression:action.defeat.play' as Id }, e.snapshot().meta.revision, 'hub3-path').ok, true);

  const pick = (label: string) => {
    const view = e.view();
    const idx = view.actions.findIndex(a => a.definition.label === label && a.available);
    assert.ok(idx >= 0, `missing choice ${label}; have ${view.actions.map(a => a.definition.label).join(' | ')}`);
    const r = e.performAction({ actionId: view.actions[idx]!.definition.id }, e.snapshot().meta.revision, `c-${label}`);
    assert.equal(r.ok, true, r.message);
  };
  pick('查看更多玩法…');
  pick('查看其余玩法…');
  assert.equal(e.snapshot().adventure!.story!.stage, 'play-hub-rest');
  pick('进入：产卵灌注');
  const story = e.snapshot().adventure!.story!;
  assert.equal(story.stage, 'play-05');
  assert.ok(story.nodeId.endsWith('defeat.g5.capture'));
  assert.ok(e.view().actions.some(a => a.definition.label === '继续：加压收紧' && a.available));
  assert.ok(e.view().actions.some(a => a.definition.label === '结束当前经历，回到安全位置' && a.available));
  pick('继续：加压收紧');
  assert.equal(e.snapshot().adventure!.story!.stage, 'play-05-press');
  pick('继续：推向高峰');
  assert.equal(e.snapshot().adventure!.story!.stage, 'play-05-peak');
  pick('继续：收束脱困');
  assert.equal(e.snapshot().adventure!.story!.stage, 'play-05-resolve');
  assert.ok(e.snapshot().adventure!.story!.nodeId.endsWith('defeat.g5.resolve'));
  assert.ok(e.view().actions.some(a => a.definition.label === '结束当前经历，回到安全位置' && a.available));
});

test('two seeds (or redraws) produce different defeat-play fillings', async () => {
  const registry = await registryOf();
  const run = (seed: number, tx: string) => {
    const s = createGameState(registry, seed);
    s.world.locationId = 'district:location.canal' as Id;
    if (!s.world.knownLocationIds.includes(s.world.locationId)) s.world.knownLocationIds.push(s.world.locationId);
    const e = new ActionExecutor(registry, s);
    assert.equal(e.performAction({ actionId: 'progression:action.defeat.play' as Id }, e.snapshot().meta.revision, tx).ok, true);
    const story = e.snapshot().adventure!.story!;
    const visible = `${story.opponentName}|${story.fills!.material}|${story.fills!.part}|${story.fills!.tf}|${story.fills!.comboSample}`;
    return visible;
  };
  const a = run(17, 'draw-a');
  const b = run(99, 'draw-b');
  const c = run(17, 'draw-a'); // same seed+tx → same
  assert.equal(a, c, 'same seed+transactionId should redraw identically');
  assert.notEqual(a, b, `expected different fills: ${a} vs ${b}`);
});

test('gel defeat chain nodes remain untouched', async () => {
  const registry = await registryOf();
  assert.ok(registry.narrativeNodes.some(n => n.id === 'progression:node.defeat.control'));
  assert.ok(registry.narrativeNodes.some(n => n.id === 'progression:node.defeat.coat'));
  assert.ok(registry.narrativeProfiles.some(p => p.id === 'progression:profile.gel'));
  assert.equal(registry.event('progression:event.defeat' as Id).id, 'progression:event.defeat');
  const gel = registry.narrativeProfiles.find(p => p.id === 'progression:profile.gel')!;
  assert.ok(gel.defeatTags?.some(t => t.tagId === 'progression:tag.coat.stuck'));
});

test('wild enemies, attributeTags, fetishTags, opponent.matches, multi-branch endings, and generic TF pipeline work end-to-end', async () => {
  const registry = await registryOf();
  const wildIds = [
    'progression:enemy.saliva-wolf',
    'progression:enemy.slug-beast',
    'progression:enemy.tentacle-vine',
    'progression:enemy.mire-slime',
    'progression:enemy.hive-crawler',
    'progression:enemy.latex-warden',
  ] as Id[];
  for (const wid of wildIds) {
    const enemy = registry.enemies.find(e => e.id === wid);
    assert.ok(enemy, `missing wild enemy ${wid}`);
    assert.ok(enemy!.speciesKind, `missing speciesKind on ${wid}`);
    assert.ok((enemy!.attributeTags?.length ?? 0) >= 1, `missing attributeTags on ${wid}`);
    assert.ok((enemy!.fetishTags?.length ?? 0) >= 1, `missing fetishTags on ${wid}`);
    assert.ok((enemy!.fetishTendencies?.length ?? 0) >= 1, `missing fetishTendencies on ${wid}`);
    assert.equal(enemy!.defeatCombo?.autoCombo, true, `missing autoCombo on ${wid}`);
  }

  // At aetheria:location.street (commons + theme.exploration), combat.encounter matches wild enemies
  const s = createGameState(registry, 23);
  s.world.locationId = 'aetheria:location.street' as Id;
  if (!s.world.knownLocationIds.includes(s.world.locationId)) s.world.knownLocationIds.push(s.world.locationId);
  const e = new ActionExecutor(registry, s);
  assert.equal(e.performAction({ actionId: 'progression:action.encounter.env' as Id }, e.snapshot().meta.revision, 'wild-enc-1').ok, true);
  const combat = e.snapshot().district!.combat!;
  assert.ok(wildIds.includes(combat.enemyId), `expected wild enemy at street, got ${combat.enemyId}`);

  // Surrender to trigger wild enemy defeat narrative with autoCombo fills and opponent.matches
  assert.equal(e.performAction({ actionId: 'progression:action.combat.surrender' as Id }, e.snapshot().meta.revision, 'wild-surrender-1').ok, true);
  // Note: surrender enters 'defeat.surrender' (priority 30); let's test direct HP=0 defeat too!
  const s2 = createGameState(registry, 23);
  s2.world.locationId = 'aetheria:location.street' as Id;
  if (!s2.world.knownLocationIds.includes(s2.world.locationId)) s2.world.knownLocationIds.push(s2.world.locationId);
  s2.player.variables['core:health'] = 1;
  s2.player.variables['core:defense'] = 0;
  s2.player.variables['core:evasion'] = 0;
  const e2 = new ActionExecutor(registry, s2);
  assert.equal(e2.performAction({ actionId: 'progression:action.encounter.env' as Id }, e2.snapshot().meta.revision, 'wild-enc-2').ok, true);
  const foughtEnemyId = e2.snapshot().district!.combat!.enemyId;
  const foughtEnemy = registry.enemies.find(x => x.id === foughtEnemyId)!;
  for (let i = 0; i < 10 && e2.snapshot().district!.combat; i++) {
    e2.performAction({ actionId: 'district:action.combat.guard' as Id }, e2.snapshot().meta.revision, 'wild-guard-' + i);
  }
  const story = e2.snapshot().adventure!.story!;
  assert.ok(story, 'should enter defeat story');
  assert.equal(story.opponentName, foughtEnemy.name);
  assert.ok(story.nodeId.startsWith('progression:node.defeat.wild.'), `expected wild start node, got ${story.nodeId}`);
  assert.ok(story.fills?.materialKey && foughtEnemy.defeatCombo!.materials!.includes(story.fills.materialKey as any));
  assert.ok(story.fills?.tf && foughtEnemy.defeatCombo!.tfs!.includes(story.fills.tf as any));

  // Verify opponent.matches condition evaluation
  assert.equal(evaluate({ op: 'opponent.matches', enemyId: foughtEnemyId }, e2.snapshot(), registry).pass, true);
  assert.equal(evaluate({ op: 'opponent.matches', speciesKind: foughtEnemy.speciesKind }, e2.snapshot(), registry).pass, true);
  assert.equal(evaluate({ op: 'opponent.matches', attributeTag: foughtEnemy.attributeTags![0] }, e2.snapshot(), registry).pass, true);
  assert.equal(evaluate({ op: 'opponent.matches', fetishTag: foughtEnemy.fetishTags![0] }, e2.snapshot(), registry).pass, true);

  // Branch A: test multi-branch escape resolution from peak
  const pick2 = (labelSubstr: string, tx: string) => {
    const view = e2.view();
    const act = view.actions.find(a => a.definition.label.includes(labelSubstr) && a.available);
    assert.ok(act, `missing choice ${labelSubstr}; have ${view.actions.map(a => a.definition.label).join(' | ')}`);
    const res = e2.performAction({ actionId: act!.definition.id }, e2.snapshot().meta.revision, tx);
    assert.equal(res.ok, true, res.message);
  };
  pick2('应对主导压制', 'wild-to-capture');
  pick2('继续：加压收紧', 'wild-to-press');
  pick2('继续：推向高峰', 'wild-to-peak');
  // At peak, test both escape branch and TF branch on cloned states
  const peakSnap = e2.snapshot();
  const branchEscape = new ActionExecutor(registry, structuredClone(peakSnap));
  const escChoice = branchEscape.view().actions.find(a => a.definition.label === '借力挣脱反制' && a.available);
  assert.ok(escChoice, 'player with grasp capability should see 借力挣脱反制 at peak');
  assert.equal(branchEscape.performAction({ actionId: escChoice!.definition.id }, branchEscape.snapshot().meta.revision, 'peak-escape').ok, true);
  assert.ok(branchEscape.snapshot().adventure!.story!.nodeId.endsWith('.resolve.escape'));

  // Branch B: advance to resolve -> resolve-tf -> enqueue generic slime-coating TF -> complete stages -> cleanse
  pick2('继续：收束脱困', 'wild-to-resolve');
  pick2('检视体表覆层与转化感应', 'wild-to-resolve-tf');
  assert.ok(e2.snapshot().adventure!.story!.nodeId.endsWith('.resolve.tf'));
  pick2('接纳黏液化覆层转化', 'wild-enqueue-slime-tf');
  assert.equal(e2.snapshot().adventure!.story, null, 'resolve.tf choice exits story');
  assert.equal(e2.snapshot().player.flags['district:flag.injury'], true, 'aftermath mark set for optional B-chain');
  assert.ok(e2.snapshot().tfQueues.some(j => j.definitionId === 'progression:tf.slime-coating' && j.status === 'active'));

  // Advance time via rest (2x 30 min = 60 min) to complete all 3 stages of progression:tf.slime-coating
  assert.equal(e2.performAction({ actionId: 'progression:action.rest' as Id }, e2.snapshot().meta.revision, 'tf-rest-1').ok, true);
  assert.equal(e2.performAction({ actionId: 'progression:action.rest' as Id }, e2.snapshot().meta.revision, 'tf-rest-2').ok, true);
  const slimeJob = e2.snapshot().tfQueues.find(j => j.definitionId === 'progression:tf.slime-coating')!;
  assert.equal(slimeJob.status, 'completed');
  const leftArm = e2.snapshot().player.body!.parts.find(p => p.instanceId === 'arm.left')!;
  assert.equal(leftArm.overrides?.materialId, 'progression:material.slime-mucus');

  // Verify SaveCodec round-trip with completed TF and aftermath flag
  validateState(e2.snapshot(), registry);
  const codec = new SaveCodec(registry);
  const decoded = await codec.decode(await codec.encode(e2.snapshot()));
  assert.equal(decoded.status, 'ready');

  // Verify body cleanse action restores normal skin and clears aftermath mark
  const cleanseAct = e2.view().actions.find(a => a.definition.id === 'progression:action.tf.cleanse-coatings' && a.available);
  assert.ok(cleanseAct, 'cleanse coatings action should be available when coated');
  assert.equal(e2.performAction({ actionId: 'progression:action.tf.cleanse-coatings' as Id }, e2.snapshot().meta.revision, 'tf-cleanse').ok, true);
  assert.equal(e2.snapshot().player.body!.parts.find(p => p.instanceId === 'arm.left')!.overrides?.materialId, undefined);
  assert.equal(e2.snapshot().player.flags['district:flag.injury'], false);
});

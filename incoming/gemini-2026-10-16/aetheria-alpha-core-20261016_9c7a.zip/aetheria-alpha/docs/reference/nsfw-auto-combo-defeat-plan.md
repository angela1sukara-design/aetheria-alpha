```json
{
  "spec": "aetheria-install/1",
  "lane": "mechanism",
  "base": "1d34db4add48c93134b3dc3c79f1cc1b6381870b",
  "summary": "NSFW 自动组合战败：敌方属性Tag、性癖倾向接口、opponent.matches 条件、多结局分流与通用 TF 全链路实装",
  "status": "checked",
  "files": [
    "src/core/district-types.ts",
    "src/core/adventure-types.ts",
    "src/content/district-schema.ts",
    "src/content/adventure-schema.ts",
    "src/content/schema.ts",
    "src/content/loader.ts",
    "src/engine/conditions.ts",
    "src/engine/defeat-play-draws.ts",
    "src/engine/narrative.ts",
    "src/engine/district-effects.ts",
    "scripts/build-adventure-content.mjs",
    "content/adventure/pack.json",
    "content/nsfw-auto-combo/defeat-play-candidates.json",
    "content/nsfw-auto-combo/defeat-play-draws.json",
    "tests/defeat-play.test.ts",
    "docs/reference/nsfw-auto-combo-defeat-plan.md"
  ],
  "verify": [
    "node scripts/build-adventure-content.mjs",
    "node --test tests/defeat-play.test.ts tests/nsfw-auto-combo.test.ts tests/environment-enemies.test.ts",
    "node --test tests/adventure.test.ts tests/procedural-ux.test.ts tests/a-templates.test.ts tests/foundation.test.ts tests/body-tf.test.ts tests/save.test.ts",
    "node scripts/build.mjs && node scripts/check-dist.mjs && node scripts/build-standalone.mjs"
  ],
  "notDone": []
}
```

# NSFW 自动组合战败：底层接口、敌方属性/性癖系统与通用 TF 实装说明

> **说明**：针对此前其他 AI 拒绝在源码中添加底层类型与 Schema 接口、导致敌方属性 Tag、性癖倾向与身体转化（TF）无法落地的问题，我已在工作区源码中**直接完成了 `mechanism` 四件套（类型 + Schema + 引擎 + 存档兼容）与 `content`（野外六敌 + G1–G8 多结局分流 + 6 套新 TF 与身体覆层材质）的全链路实装与测试验证**。

---

## 1. 已直接实装的源码接口清单（`mechanism` 车道四件套同步）

### 1.1 敌方物种、属性 Tag、性癖倾向与组合池接口（`src/core/district-types.ts` & `src/core/adventure-types.ts`）

在 `EnemyDef`、`NarrativeProfile` 与 `EnvironmentEnemyRule` 三处同步开放了以下一等公民字段（全部通过 `district-schema.ts`、`adventure-schema.ts` 与 `loader.ts` 严格校验，且保持向后兼容）：

```ts
export const ENEMY_SPECIES_KINDS = ['human', 'beast', 'monster', 'plant', 'slime', 'insect', 'construct'] as const;
export type EnemySpeciesKind = typeof ENEMY_SPECIES_KINDS[number];
export const DEFEAT_MATERIAL_KEYS = ['M1', 'M2', 'M3', 'M4', 'M5', 'M6'] as const;
export type DefeatMaterialKey = typeof DEFEAT_MATERIAL_KEYS[number];
export const DEFEAT_PLAY_KEYS = ['G1', 'G2', 'G3', 'G4', 'G5', 'G6', 'G7', 'G8'] as const;
export type DefeatPlayKey = typeof DEFEAT_PLAY_KEYS[number];
export const GENERIC_TF_ATOMS = ['黏液化', '黑胶化'] as const;
export type GenericTfAtom = typeof GENERIC_TF_ATOMS[number];

export interface EnemyFetishTendency {
  /** 已注册的性癖/玩法倾向 Tag ID（如 progression:tag.fetish.restraint / coating / oviposition 等） */
  tagId: Id;
  /** 倾向权重（0–100），用于战败节点与玩法抽选加权 */
  weight: number;
}

export interface EnemyDefeatComboConfig {
  /** 允许抽取的定词挂前材质键（M1–M6） */
  materials?: DefeatMaterialKey[];
  /** 允许抽取的目标部位名称 */
  parts?: string[];
  /** 偏好的战败玩法大类（G1–G8） */
  plays?: DefeatPlayKey[];
  /** 允许抽取的通用转化原子（仅限通用黏液化/黑胶化，禁止物种专条） */
  tfs?: GenericTfAtom[];
  /** 战败进入叙事时是否自动抽取组合槽位（fills） */
  autoCombo?: boolean;
}
```

### 1.2 新增 `opponent.matches` 对手条件 Opcode（`src/core/adventure-types.ts` & `src/content/schema.ts` & `src/engine/conditions.ts`）

解决了原先 `Condition` 无法查询战斗敌人属性、物种或性癖倾向的问题。现在任何叙事节点（`NarrativeNode`）或选项（`NarrativeChoice`）均可直接使用 `opponent.matches` 与玩家 `body.hasCapability` / `body.matches` 组合出双方属性对偶检定：

```ts
export type OpponentMatchCondition = {
  op: 'opponent.matches';
  enemyId?: Id;                 // 匹配当前敌人 ID
  speciesKind?: EnemySpeciesKind; // 匹配物种大类（human/beast/monster/plant/slime/insect/construct）
  attributeTag?: Id;            // 匹配敌方身体/材质/生态属性 Tag（如黏液、触手、藤蔓、甲壳、信息素）
  fetishTag?: Id;               // 匹配敌方性癖/支配倾向 Tag（如束缚、覆层、侵入、产卵寄宿、调教）
  materialKey?: DefeatMaterialKey; // 匹配当前抽中的定词材质 M1–M6
  playKey?: DefeatPlayKey;      // 匹配当前玩法大类 G1–G8
  tf?: GenericTfAtom;           // 匹配当前抽中的通用转化（黏液化 / 黑胶化）
};
```

### 1.3 引擎战败自动抽选与倾向加权（`src/engine/defeat-play-draws.ts` & `src/engine/narrative.ts` & `src/engine/district-effects.ts`）

1. **按敌方专属池抽选 `story.fills`**：当敌方 `EnemyDef` 或 `NarrativeProfile` 配置了 `defeatCombo.autoCombo: true` 时，战败进入 `startNarrative` 会自动从该敌人的允许材质池（`materials`）、目标部位池（`parts`）、偏好玩法池（`plays`）与通用转化池（`tfs`）中确定性抽取 `{opponentKind, materialKey, material, materialBase, dingci, part, tf, comboSample, playKey}`，并使用真实敌人名称作为 `{opponent}`（不再显示占位名）。
2. **敌方属性与性癖 Tag 自动注入**：战斗面板（`districtText`）与战败故事状态（`story.tags`）自动挂载敌人的 `attributeTags` 与 `fetishTags`（`role: 'opponent'`），且 `nodeWeight()` 会根据敌人的 `fetishTendencies` 自动提高对应性癖玩法节点的抽中权重。

---

## 2. 已实装的敌方属性 Tag、性癖倾向库与野外六敌（`scripts/build-adventure-content.mjs`）

### 2.1 敌方属性 Tag（`attributeTags`）与性癖倾向 Tag（`fetishTags`）

| 类别 | Tag ID | 中文名称 | 作用说明 |
| :--- | :--- | :--- | :--- |
| **敌方属性** | `progression:tag.attr.mucus` | 黏液分泌 | 体表或腺体持续分泌高粘度生物黏液 |
| **敌方属性** | `progression:tag.attr.tentacle` | 触手附肢 | 具备柔韧可延展的触手或软体附肢 |
| **敌方属性** | `progression:tag.attr.vine` | 藤蔓缠卷 | 具备植物藤蔓、气根与湿润叶膜结构 |
| **敌方属性** | `progression:tag.attr.gel-body` | 流体胶质躯体 | 由半透明史莱姆或活体黑胶构成的流体躯干 |
| **敌方属性** | `progression:tag.attr.chitin` | 甲壳外骨骼 | 覆盖节肢甲片与细密刚毛的虫巢躯体 |
| **敌方属性** | `progression:tag.attr.pheromone` | 感官干扰气息 | 散发干扰感官与注意力的甜腥气雾或低频共鸣（不视为自愿同意） |
| **敌方属性** | `progression:tag.attr.pack` | 群聚围猎 | 习惯多体协同包抄、轮番消耗猎物体力 |
| **敌方属性** | `progression:tag.attr.warm-saliva` | 温热涎液 | 口腔分泌大量滑腻温热的垂涎 |
| **性癖倾向** | `progression:tag.fetish.restraint` | 束缚拘禁倾向 | 对应 G1「束缚制服」 |
| **性癖倾向** | `progression:tag.fetish.coating` | 材质覆层倾向 | 对应 G2「材质覆层转化」 |
| **性癖倾向** | `progression:tag.fetish.penetration` | 贴身侵入倾向 | 对应 G3「侵犯插入」 |
| **性癖倾向** | `progression:tag.fetish.sensory-deprivation` | 感官封夺倾向 | 对应 G4「口封感官剥夺」 |
| **性癖倾向** | `progression:tag.fetish.oviposition` | 温床寄宿倾向 | 对应 G5「产卵灌注」 |
| **性癖倾向** | `progression:tag.fetish.humiliation` | 失态展示倾向 | 对应 G6「公开羞辱」 |
| **性癖倾向** | `progression:tag.fetish.domination` | 支配驯服倾向 | 对应 G7「主从调教」 |
| **性癖倾向** | `progression:tag.fetish.swarm` | 多体合围倾向 | 对应 G8「多体围攻」 |

### 2.2 野外六敌完整实装表

| 敌人 ID | 名称 | 物种 (`speciesKind`) | 固有属性 (`attributeTags`) | 性癖倾向 (`fetishTags`) | 专属组合池 (`defeatCombo`) |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `progression:enemy.saliva-wolf` | **涎狼** | `beast` | `warm-saliva`, `pack` | `restraint` (85), `coating` (70) | 材质 `M1/M4` · 部位 `脖颈/手腕/脚踝` · 玩法 `G1/G2` · `黏液化` |
| `progression:enemy.slug-beast` | **林缘蛞蝓兽** | `slime` | `mucus`, `gel-body` | `coating` (95), `sensory-deprivation` (65) | 材质 `M1/M6` · 部位 `脚踝/腰侧/大腿内侧` · 玩法 `G2/G4` · `黏液化` |
| `progression:enemy.tentacle-vine` | **兽径触手藤** | `plant` | `vine`, `tentacle`, `mucus` | `restraint` (95), `penetration` (80), `humiliation` (65) | 材质 `M2/M6` · 部位 `手腕/脚踝/大腿内侧/腰侧` · 玩法 `G1/G3/G6` · `黏液化` |
| `progression:enemy.mire-slime` | **泥沼史莱姆** | `slime` | `gel-body`, `mucus`, `pack` | `coating` (95), `swarm` (85), `sensory-deprivation` (70) | 材质 `M4/M6` · 部位 `腰侧/大腿内侧/嘴唇/锁骨窝` · 玩法 `G2/G8/G4` · `黏液化` |
| `progression:enemy.hive-crawler` | **虫巢爬者** | `insect` | `chitin`, `mucus`, `pack` | `oviposition` (95), `swarm` (85), `restraint` (70) | 材质 `M3/M6` · 部位 `腰侧/大腿内侧/手腕` · 玩法 `G5/G8/G1` · `黏液化` |
| `progression:enemy.latex-warden` | **黑胶林地看守** | `monster` | `gel-body`, `pheromone`, `tentacle` | `domination` (95), `coating` (90), `restraint` (75) | 材质 `M5/M6` · 部位 `脖颈/锁骨窝/手腕/大腿内侧` · 玩法 `G7/G2/G1` · `黑胶化` |

---

## 3. 已实装的身体转化（TF）体系与多分支结局（`scripts/build-adventure-content.mjs`）

### 3.1 新增身体覆层材质、形态、派生 Tag 与 6 套完整 Transformation

1. **4 种新增身体材质（`p.materials`）与形态（`p.morphologies`）**：
   - `progression:material.slime-mucus`（`生物黏液覆层`）+ `progression:morphology.slime-coated`（`黏液包裹态`）
   - `progression:material.living-latex`（`活体黑胶覆层`）+ `progression:morphology.latex-sheathed`（`黑胶紧缚态`）
   - `progression:material.chitin-carapace`（`虫巢甲质层`）+ `progression:morphology.chitin-plated`（`甲质覆层态`）
   - `progression:material.vine-symbiont`（`共生藤膜`）+ `progression:morphology.vine-twined`（`藤蔓缠附态`）
2. **5 条自动派生身体语义 Tag（`p.derivedTags`）**：
   - `progression:tag.body.slime-coated`（`黏液化体表`）
   - `progression:tag.body.latex-sheathed`（`黑胶化体表`）
   - `progression:tag.body.chitin-plated`（`甲质化体表`）
   - `progression:tag.body.vine-twined`（`藤膜共生体表`）
   - `progression:tag.body.wolf-ears`（`狼耳特征`）
3. **6 套新增 `Transformation` 定义（`p.transformations`）**：
   - `progression:tf.slime-coating`（`通用黏液化浸染`，3 阶段 `story` 渐进转化：10 分钟前兆 → 25 分钟下肢覆层 → 45 分钟四肢完成）
   - `progression:tf.latex-coating`（`通用黑胶化包覆`，3 阶段 `story` 渐进转化：10 分钟前兆 → 25 分钟下肢包覆 → 45 分钟四肢完成）
   - `progression:tf.chitin-carapace`（`虫巢甲质化覆层`，2 阶段 `story` 渐进转化）
   - `progression:tf.vine-symbiosis`（`共生藤膜缠附`，2 阶段 `story` 渐进转化）
   - `progression:tf.beast-tail-growth`（`兽化长尾萌发`，2 阶段 `story` 渐进转化，在后腰长出真实生物尾部件）
   - `progression:tf.cleanse-coatings`（`洗净体表异质覆层`，0 分钟即时 `free` 恢复，绑定身体面板动作 `progression:action.tf.cleanse-coatings`，随时可洗去四肢异质覆层）

### 3.2 G1–G8 真实三结局分流与「战败 A 链 / 事后 B 链」分账

- **在 `G1`–`G8` 的 `peak` 拍与 `resolve` 拍实装 3 条独立结局路径**：
  1. **挣脱抽身结局（`node.defeat.gN.resolve.escape`）**：当玩家具备抓握能力（`grasp`）、尾部抓握（`tailGrip`）或充足体力时，可在 `peak` 拍选择「借力挣脱反制」，直接进入 `resolve.escape` 节点清爽脱身，不留战后残迹。
  2. **留痕脱困结局（`node.defeat.gN.resolve`）**：常规收束脱困，玩家可选择免费安全退出，或带着残迹退回安全位置（写入战后残迹标记）。
  3. **覆层浸染与转化结局（`node.defeat.gN.resolve.tf`）**：进入 `resolve.tf` 节点，玩家可选择当场接纳 `通用黏液化浸染`（`tf.slime-coating`）或 `通用黑胶化包覆`（`tf.latex-coating`），或暂且压下感应带痕离开。
- **独立事后余韵与深度转化支线（B 链：`progression:action.residue.trace`）**：
  - 当玩家在战败后留下残迹标记时，回到安全地点会解锁可选行动「处理战后残迹与感应」。
  - 玩家可自主选择**「彻底清理残迹，平复身心」**（清除残迹并恢复生命/理智），或选择**「顺应残留感应，引导深度转化」**进入 `node.transformation.residue.deepen`，自主开启虫巢甲质化、共生藤膜或兽化长尾萌发。

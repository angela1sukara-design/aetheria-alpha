import { activityEligibility } from '../world/adaptation.ts';
import { entityBody } from './query.ts';
import type { ActionDef, ActionOption, GameState, GameView, Id } from '../core/types.ts';
import { clone, freeze } from '../core/types.ts';
import type { Registry } from '../content/registry.ts';
import { evaluate } from './conditions.ts';
import { transformationCheck } from './transformations.ts';
import { eventNode } from './events.ts';
import { npcPresent } from './npc.ts';
import { residentPresent } from './resident-quests.ts';
import { districtOptions, districtText } from './district-effects.ts';
import { directResourceCheck } from './resource-check.ts';
import type { TextLibrary } from '../content/text-variants.ts';
import { routeDistanceTier, routeStaminaCost, staminaGate, STAMINA_COST } from './numerics.ts';
import { narrativeActions, narrativeText, publicActionEffects,conversationEntryAction } from './narrative.ts';
import { progressionCheck } from './progression.ts';
import { describeResidentAction, functionKey, requiredFunction, selectedResident, serviceAvailable, usesFunctions } from './entity-functions.ts';

const STAMINA_ID = 'core:stamina' as Id;

/** 所有可执行入口同一个选择器：UI 可见动作与引擎授权集合完全一致。 */
export function actionOptions(state: GameState, registry: Registry): ActionOption[] {
  const current = eventNode(state, registry);
  const storyActions=narrativeActions(state,registry);
  const actions: ActionDef[] = storyActions??(current ? current.node.actionIds.map(id => registry.action(id)).filter(x => x.context?.eventId === current.event.definitionId && x.context.nodeId === current.node.id) : registry.actionsAt(state.world.locationId).filter(x => !x.context));
  const topics = current ? [] : registry.npcs.filter(n => npcPresent(state, registry, n.id)).flatMap(n => registry.actionsForHook(n.topicHook));
  // Snapshot-based observation may remain open while the player uses the body
  // panel. Expose only player TF controls; other narrative kinds stay isolated.
  const observing=!!state.adventure?.story?.prose;
  const observationBody=observing?registry.globalActions().filter(a=>a.surface==='body'&&a.effects.length&&a.effects.every(e=>['tf.apply','tf.pause','tf.resume','tf.cancel'].includes(e.op)&&(!('target'in e)||!e.target||e.target.kind==='player'))):[];
  const allActions = [...new Map([...actions, ...(storyActions?[]:topics), ...(storyActions?observationBody:registry.globalActions())].map(a => [a.id, a])).values()];
  const stamina = state.player.variables[STAMINA_ID] ?? 100;
  const gate = staminaGate(stamina);
  const strict=usesFunctions(state,registry), supported=districtOptions(state,registry,allActions).filter(a=>{
    if(a.conditions.some(c=>c.op==='service.available'&&!serviceAvailable(state,registry,c)))return false;
    const need=requiredFunction(a,publicActionEffects(a,state,registry));
    return !strict||!!a.context||!need||serviceAvailable(state,registry,need);
  });
  const preferred=new Map<string,ActionDef>();
  const score=(a:ActionDef)=>a.effects.some(e=>e.op==='resident.help'||e.op==='resident.talk')?1000:a.effects.reduce((n,e)=>n+(e.op==='var.change'&&e.amount>0&&['core:energy','core:stamina','core:health'].includes(e.id)?e.amount*10:e.op==='clock.advance'?-e.minutes:0),0);
  if(strict)for(const a of supported){const need=requiredFunction(a,publicActionEffects(a,state,registry)),key=need&&functionKey(need);if(key&&!a.context&&!a.effects.some(e=>e.op==='narrative.choose')){const old=preferred.get(key);if(!old||score(a)>score(old))preferred.set(key,a);}}
  return supported.filter(a=>{if(!strict||a.context||a.effects.some(e=>e.op==='narrative.choose'))return true;const need=requiredFunction(a,publicActionEffects(a,state,registry)),key=need&&functionKey(need);return !key||preferred.get(key)===a;}).map(source => {
    const need=strict&&!source.context?requiredFunction(source,publicActionEffects(source,state,registry)):undefined;
    const decorated=conversationEntryAction(describeResidentAction(source,state,registry),state,registry);
    const definition=need?{...decorated,conditions:[...decorated.conditions,{op:'service.available' as const,...need}]}:decorated;
    const checks = definition.conditions.map(c => evaluate(c, state, registry));
    const effects=publicActionEffects(definition,state,registry);
    for (const e of effects) {
      if(e.op==='combat.start'||e.op==='combat.encounter')checks.push({pass:(state.player.variables['core:health']??0)>=1,reason:'需要先休息恢复，再开始交锋。'});
      if(e.op==='progression.act')checks.push(progressionCheck(state,registry,e.move,e.id));
      if (e.op === 'resident.help') {
        const resident = state.district?.residents.find(n => n.id === state.district?.currentResidentId), t = registry.residentTemplates.find(t => t.id === resident?.templateId);
        if (resident && t) checks.push(activityEligibility(resident.body, t, registry));
        if(strict)checks.push({pass:!selectedResident(state)?.memories.includes(`help:${Math.floor(state.clock.totalMinutes/1440)}`),reason:'今天的协助已完成，明天再来。'});
        checks.push({ pass: gate.allowLabor && stamina >= STAMINA_COST.labor, reason: stamina < STAMINA_COST.labor ? `体力不足：当前 ${stamina}，本次需要 ${STAMINA_COST.labor}。` : '体力过低，无法从事体力劳动。' });
      }
      if (e.op === 'scene.start') checks.push({ pass: !!state.district?.profile.created, reason: '先在公寓签下租约，确认成年角色身份。' });
      if (e.op === 'combat.turn' && (e.move === 'attack'||e.move==='skill')) {
        checks.push({ pass: gate.allowAttack && stamina >= STAMINA_COST.attack, reason: gate.combatOnlyGuardOrFlee || !gate.allowAttack ? '体力过低，本回合只能防守或撤离。' : `进攻需要${STAMINA_COST.attack}点体力。` });
      }
      if (e.op === 'combat.turn' && e.move === 'recover') {
        checks.push({ pass: !gate.combatOnlyGuardOrFlee && stamina >= STAMINA_COST.recover, reason: gate.combatOnlyGuardOrFlee ? '体力耗尽，只能防守或撤离。' : `临时包扎需要${STAMINA_COST.recover}点体力。` });
      }
      if(e.op==='combat.turn'&&e.move==='skill')checks.push({pass:(state.player.variables['core:skillResource']??0)>=15&&stamina>=4,reason:'技能击需要技能资源15和体力4。'});
      if(e.op==='equipment.wear'&&e.id.startsWith('progression:'))checks.push({pass:!!state.district?.inventory.includes(e.id),reason:'先购买这件装备。'});
      if(e.op==='item.use')checks.push({pass:(state.adventure?.items?.[e.id]??0)>=1,reason:'补给袋中没有这件消耗品。'});
      if(e.op==='combat.turn'&&e.move==='item'&&e.id)checks.push({pass:(state.adventure?.items?.[e.id]??0)>=1&&!!registry.items.find(i=>i.id===e.id)?.usableInCombat,reason:'战内没有可用的这件消耗品。'});
      if (e.op === 'combat.turn' && e.move === 'flee') {
        // Emergency withdrawal remains available even after an enemy drains the last point.
        checks.push({ pass: true, reason: '' });
      }
      if (e.op === 'combat.turn' && e.move === 'guard') {
        checks.push({ pass: stamina >= STAMINA_COST.guard, reason: '防守需要1点体力。' });
      }
      if (e.op === 'location.move') {
        const route = registry.route(e.routeId);
        const tier = routeDistanceTier(route);
        const cost = routeStaminaCost(route);
        checks.push({ pass: stamina >= cost, reason: `体力不足：当前 ${stamina}，本次移动需要 ${cost}。` });
        if (tier !== 'adjacent' && !gate.allowFarMove) {
          checks.push({ pass: false, reason: '体力不足，无法走远路/跨区' });
        }
      }
      if (e.op === 'scene.act' && e.move === 'contact') {
        const scene = state.district?.scene, def = registry.interactions.find(i => i.id === scene?.definitionId), pose = def?.poses.find(p => p.id === scene?.poseId);
        checks.push({ pass: pose?.facing === 'front' && pose.zone === 'near', reason: '面对面坐近后才可建立接触。' });
        checks.push({ pass: !!state.player.body?.parts.some(p => registry.bodyPart(p.definitionId).kind === 'hand' && !scene?.contacts.some(c => c.playerPartId === p.instanceId)), reason: '没有空闲的手部资源，先释放接触。' });
      }
    }
    for (const e of definition.effects) if (e.op === 'scene.act' && e.move === 'contact') {
      const scene = state.district?.scene;
      if (scene) {
        const b = entityBody(state, scene.actors[1]!.entity ?? { kind: 'npc', id: scene.actors[1]!.id as Id });
        checks.push({ pass: b.known && b.value.parts.some(p => registry.bodyPart(p.definitionId).kind === 'hand' && registry.bodyPart(p.definitionId).capabilities.includes('grasp') && !scene.contacts.some(c => c.npcPartId === p.instanceId)), reason: '对方没有空闲的抓握部位。' });
      }
    }
    checks.push(directResourceCheck(effects, state, registry));
    for (const e of effects) if (e.op === 'tf.apply' || e.op === 'tf.enqueue' || e.op === 'tf.pause' || e.op === 'tf.resume' || e.op === 'tf.cancel') checks.push(transformationCheck(state, registry, e.id, e.op, e.target));
    for (const e of definition.effects) if (e.op === 'event.start') for (const npcId of registry.event(e.id).participantIds ?? []) checks.push({ pass: npcPresent(state, registry, npcId), reason: `${registry.npc(npcId).name}此刻不在这里。` });
    for (const e of definition.effects) if (e.op === 'event.start') for (const residentId of registry.event(e.id).residentIds ?? []) checks.push({ pass: residentPresent(state, residentId), reason: '约定的居民此刻不在这里。' });
    const failed = checks.find(x => !x.pass);
    return { definition, available: !failed, reason: failed?.reason ?? '' };
  });
}
export function selectGameView(state: GameState, registry: Registry, texts?: TextLibrary): GameView {
  const current = eventNode(state, registry); const location = registry.location(state.world.locationId);
  const slot = current ? registry.textSlots.find(s => s.owner.eventId === current.event.definitionId && s.owner.nodeId === current.node.id) : undefined;
  const base = narrativeText(state,registry)??(slot && texts ? texts.resolve(slot.id, state, registry) : current ? registry.text(current.event.textByNode[current.node.id]) : registry.text(location.textKey));
  return freeze({
    location, state: clone(state), actions: actionOptions(state, registry),
    sceneText: districtText(state, registry, base),
    ...(current||state.adventure?.story ? { eventTitle: '正在发生' } : {}),
  });
}

import { buildPersonalityContent } from './build-personality-content.mjs';
import {proseProblem} from '../src/content/player-prose.ts';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import { loadAtoms, sampleCombos, toEncounterCandidate } from './nsfw-auto-combo/combiner.mjs';
const json=async p=>JSON.parse(await readFile(p,'utf8'));
const index=await json('content/index.json'),base=await Promise.all(index.packs.filter(p=>!p.includes('/adventure/')).map(p=>json('content/'+p)));
const id=s=>'progression:'+s,tag=s=>id('tag.'+s),scoped=(role,s)=>({role,tagId:tag(s)}),has=(role,s,value=true)=>({op:'narrative.tag',role,id:tag(s),value});
const p={manifest:{id:'aetheria/adventure',namespace:'progression',version:'1.0.0',schemaVersion:2,engineApiVersion:'0.1',author:'Aetheria',status:'draft',dependencies:base.map(p=>({id:p.manifest.id,version:p.manifest.version,optional:false})),requiresCapabilities:['foundation.v2','adventure.v1','condition.v1','effect.v1','hook.global.v1','district.v1','body.graph.v1','tf.pipeline.v1'],migrations:[]},variables:[],flags:[],hooks:[{id:id('hook.runtime'),accepts:'action',visibility:'public'}],locations:[],routes:[],actions:[],events:[],texts:{},contributions:[],globalActionHooks:[id('hook.runtime')],tags:[],narrativeNodes:[],narrativeProfiles:[],environmentEnemyRules:[],equipment:[],items:[],enemies:[],locationProfiles:[],bodyPatches:[],transformations:[]};
for(const [key,label,definition]of [
 ['control','控制倾向','偏爱先稳定现场和限制危险行动的行为倾向，不授予身体能力。'],['direct','直接倾向','偏爱尽快结束当前事务的行为倾向。'],['repair','改造与修理倾向','偏爱提出检查与改装方案，不代表实际执行或取得同意。'],['cautious','谨慎','优先核对条件和风险的倾向；对应离线概念general-taxonomy:disposition.caution。'],['tools','携带维护工具','行为档案确认对方携带维护工具，工具不替代玩家的选择。'],['goal.control','控制现场目标','本次主要目标为稳定现场。'],['goal.leave','结束接触目标','本次主要目标为结束接触并离开。'],['goal.repair','检查改装目标','本次主要目标为提出检查或修理方案。'],['coat.stuck','外衣黏附','战败结算明确写入的玩家外衣暂时黏附事实，不等于身体黑胶化。'],['hands.restricted','双手受限','故事局部事实：玩家双手暂时不便取用工具，不移除BodyGraph中的手。'],['clear','保持清醒','当前战败规则确认玩家仍可清楚回应。'],['injured','伤后乏力','战败结算留下的局部状态。'],['signal','已发出求助','实际选择求助后记录的本次信号事实。'],['assessed','已检查处境','玩家已通过选择检查现场。'],['aid','公共协作','发生的公共协作行动题材。'],['route','路线发现','本次探索确认了可使用的通道信息。'],['repair.accepted','接受本次修理','本次选择明确接受指定修理，不能用于其他范围。']])p.tags.push({id:tag(key),label,definition,facets:['context'],status:'active',aliases:[]});
const profiles=[['gel','district:enemy.gel',['control'],['goal.control'],[['control',80],['cautious',30]],[scoped('player','coat.stuck')]],['collector','district:enemy.collector',['direct'],['goal.leave'],[['direct',90]],[]],['scavenger','district:enemy.scavenger',['repair','tools'],['goal.repair'],[['repair',80],['cautious',50]],[]],['raider',id('enemy.raider'),['direct'],['goal.leave'],[['direct',70]],[]],['sentinel',id('enemy.sentinel'),['control'],['goal.control'],[['control',85]],[scoped('player','hands.restricted')]],['overseer',id('enemy.overseer'),['repair','tools'],['goal.repair'],[['repair',90],['control',30]],[]]];
for(const [name,enemyId,tags,goals,tendencies,defeatTags]of profiles)p.narrativeProfiles.push({id:id('profile.'+name),enemyId,tags:tags.map(tag),goals:goals.map(tag),tendencies:tendencies.map(([s,weight])=>({tagId:tag(s),weight})),defeatTags:[scoped('player','clear'),scoped('player','injured'),...defeatTags]});
const action=(name,label,effects,conditions=[],hint='按当前条件执行',group='daily')=>{const aid=id('action.'+name),textKey=id('text.action.'+name);p.texts[textKey]=label+'。';p.actions.push({id:aid,label,hint,group,conditions,effects,resultText:textKey});p.contributions.push({hookId:id('hook.runtime'),actionIds:[aid]});return aid;};
for(let i=0;i<4;i++)action('story.'+i,'继续当前经历',[{op:'narrative.choose',index:i}]);
const choice=(label,result,next=null,effects=[],conditions=[],setTags=[],unsetTags=[])=>{const resultText=id('text.choice.'+Object.keys(p.texts).length);p.texts[resultText]=result;return{label,resultText,next,effects,conditions,setTags,unsetTags};};
const exit=()=>choice('结束当前经历，回到安全位置','你停止这次接触，回到可以继续行动的位置。');
const node=(name,kind,stage,title,text,choices,extra={})=>{const nid=id('node.'+name),textKey=id('text.node.'+name);p.texts[textKey]=text;p.narrativeNodes.push({id:nid,kind,stage,title,textKey,requiresTags:[],excludesTags:[],conditions:[],tendencies:[],weight:10,priority:0,maxVisits:1,choices:[...choices,exit()],...extra});};
const time=minutes=>({op:'clock.advance',minutes}),health=amount=>({op:'var.change',id:'core:health',amount}),change=(field,amount)=>({op:'adventure.change',field,amount}),grasp={op:'body.hasCapability',capability:'grasp',count:1};
node('defeat.start','defeat','start','交锋之后','你已经失去继续交锋的力气，但仍能辨认周围的声音。你先稳住身体，判断怎样离开眼前的处境。',[choice('检查还能怎样活动','你停下无效的挣扎，检查可活动部位。','assess',[],[],[scoped('player','assessed')])]);
node('defeat.control','defeat','start','被留在原处','{opponent}先收拢现场，阻止你再次贸然行动。你仍保持清醒，可以检查限制的位置，或发声请求协助。',[choice('检查限制位置','你确认了限制所在。','assess',[],[],[scoped('player','assessed')]),choice('发声请求协助','你向公共通道清楚地发出求助。','help',[time(5)],[],[scoped('player','signal')])],{priority:5,requiresTags:[scoped('opponent','goal.control')],tendencies:[{tagId:tag('control'),weight:1}]});
node('defeat.direct','defeat','start','冲突已经结束','{opponent}确认你无法继续交锋，便结束了这次接触。你留在原地喘息，先检查伤势，再决定是否需要协助。',[choice('缓慢检查并处理擦伤','你确认伤处并完成简单处理，随后回到安全通道。',null,[time(15),health(8)]),choice('请求值班协助','你说明自己需要协助。','help',[time(5)],[],[scoped('player','signal')])],{priority:5,requiresTags:[scoped('opponent','goal.leave')],tendencies:[{tagId:tag('direct'),weight:1}]});
node('defeat.repair','defeat','start','提出检查方案','{opponent}停下攻势，把随身维护工具放到一旁，提出替你检修受损装备。你随时可以拒绝离开，也可以先听听对方打算检查哪些部位。',[choice('先听检查范围','对方说明检查范围，等待你的下一步决定。','repair'),choice('拒绝检查，请求离开','你拒绝这次检查，停止接触并离开。')],{priority:5,requiresTags:[scoped('opponent','goal.repair'),scoped('opponent','tools')],tendencies:[{tagId:tag('repair'),weight:1}]});
node('defeat.assess','defeat','assess','检查处境','你定下心神活动了一下手脚，确认四肢并无大碍，只是眼前的牵制还需设法解开。你可以出声唤人协助，也可以顺着安全通道慢慢退开。',[choice('发声请求协助','你发出求助信号。','help',[time(5)],[],[scoped('player','signal')]),choice('沿安全路线缓慢离开','你沿安全路线离开危险位置，休息后再决定下一步。',null,[time(20),health(5)])]);
node('defeat.coat','defeat','assess','找到黏附位置','外衣的下摆粘在低处【外衣黏附】，身体本身没有因此变成黑胶。你确认手边仍有可用的抓握部位，可以尝试松开外衣，或请求协助。',[choice('松开被牵住的外衣','你松开外衣的牵扯，沿台阶回到安全位置。',null,[time(15),health(5)],[grasp],[],[scoped('player','coat.stuck')]),choice('发声请求协助','你报出所在位置，请求协助。','help',[time(5)],[],[scoped('player','signal')])],{priority:5,requiresTags:[scoped('player','coat.stuck')],conditions:[grasp]});
node('defeat.hands','defeat','assess','双手暂时受限','你发现双手暂时不便取用工具。你不再强行够取物件，转而用声音说明自己所在的位置。',[choice('清楚报出位置并等待协助','你清楚报出位置。','help',[time(5)],[],[scoped('player','signal')])],{priority:6,requiresTags:[scoped('player','hands.restricted')]});
node('defeat.help','defeat','help','回应来自通道','通道里传来回应。值班人员根据你刚才报出的信息找到现场，先确认你的意识与伤处，再询问你希望接受哪些帮助。',[choice('接受脱困与基础护理','对方帮助你脱离现场，并处理了擦伤。事故情况已经记入本次经历。',null,[time(20),health(12),change('safety',1)]),choice('只请求离开危险位置','对方协助你离开危险位置，你保留之后自行处理伤势的选择。',null,[time(10),health(3)])],{requiresTags:[scoped('player','signal')]});
node('defeat.repair.scope','defeat','repair','保留自己的决定','对方把检修的步骤与界限一五一十地讲明。你可以就此打住，或者让对方先把周围散落的障碍清理干净。',[choice('先处理现场安全','现场得到整理，你离开危险位置。',null,[time(10),health(3),change('safety',1)])]);
node('defeat.repair.tail','defeat','repair','机械尾的维护提议','对方注意到你身后的机械尾节，提议花一刻钟将尾部外伸长度校准到650毫米，以改善转身时的配重平衡。是否动手全凭你一句话。',[choice('接受这一次长度调整','你明确接受本次长度调整；维护完成，尾部的真实长度记录为650毫米。',null,[{op:'tf.enqueue',id:id('tf.tail-maintenance')},time(15),health(5)],[],[scoped('player','repair.accepted')]),choice('拒绝改装，离开现场','你拒绝改装，沿安全路线离开。',null,[time(10),health(3)])],{priority:6,requiresTags:[{role:'player',tagId:'foundation:body.mechanical-tail'},scoped('opponent','tools')],conditions:[{op:'body.matches',target:{kind:'player'},part:{kind:'tail',materialFamily:'mechanical'}},{op:'tf.state',id:id('tf.tail-maintenance'),state:'idle'},{op:'not',condition:{op:'body.matches',target:{kind:'player'},part:{kind:'tail',lengthMm:650}}}]});
p.tags.push(...['surrender','giveup'].map(key=>({id:tag(key),label:key==='surrender'?'主动投降':'放弃抵抗',definition:'本次交锋主动结束时记录的应对方式。',facets:['context'],status:'active',aliases:[]})));
node('defeat.surrender','defeat','start','你选择投降','你向{opponent}示意不再交战，收起进攻的动作。对方停在你面前，等你说明接下来的打算。你仍可以开口求助，或结束这段接触。',[
 choice('等待对方回应','你停下争辩，等待{opponent}处理眼前的局面。','yielded',[time(5)]),
 choice('发声请求协助','你报出{place}的位置，请求协助。','help',[],[],[scoped('player','signal')]),
],{priority:30,requiresTags:[scoped('player','surrender')]});
node('defeat.giveup','defeat','start','停止抵抗','你放下防备，不再尝试反击或挣脱。{opponent}看见你停下，开始接手处理现场。你留在原处，等待事态继续。',[
 choice('不再干预，等待后续','你不再与{opponent}争执，任由对方接手眼前的安排。','yielded',[time(5)]),
],{priority:30,requiresTags:[scoped('player','giveup')]});
node('defeat.yielded','defeat','yielded','交锋后的安排','{opponent}把冲突留在原处，为你让出离开的位置。通道里恢复了走动声，你可以先去休息。',[
 choice('沿通道离开','你离开{place}的冲突现场，在公共通道停下来喘息。',null,[time(10)]),
]);
node('defeat.yielded.control','defeat','yielded','对方接手现场','{opponent}先把现场稳住，阻止冲突继续扩大，随后带你走向公共通道。你没有再次抵抗。',[
 choice('跟随安排，离开冲突','你随{opponent}离开冲突所在的位置，回到能够休息的通道。',null,[time(10)]),
],{priority:5,requiresTags:[scoped('opponent','goal.control')]});
node('defeat.yielded.repair','defeat','yielded','处理受损的装备','{opponent}收起工具，先查看现场有没有松脱的物件，随后把能带走的装备放在你手边。',[
 choice('等对方收拾完，再离开','你等待{opponent}清理完现场，带着自己的物品回到公共通道。',null,[time(10)]),
],{priority:5,requiresTags:[scoped('opponent','goal.repair')]});
for(const kind of ['encounter','exploration','daily','conversation','quest','transformation','ending']){
 const messages={encounter:['眼前的遭遇','你在{place}停下，留意眼前正在发生的小事。先观察当前处境，再决定是否参与。'],exploration:['查看周围','你沿{place}的可见通道查看路面与告示。已经走过的路线可以核对，尚未进入的地方仍保留未知。'],daily:['安排一段日常','你在{place}检查手边的事情，衡量当前体力与精力。可以选择一段公共协作，也可以留出时间休息。'],conversation:['与眼前的人交谈','你与已经在场的{opponent}谈起眼前的事务。你先听对方把话说完，再决定是否参与。'],quest:['核对当前事务','你把已经发生的进展与眼前的安排核对。需要进一步处理的事项仍要通过实际行动完成。'],transformation:['适应当前身体','你放慢动作，检查身体目前的支撑与活动方式。已经完成的变化以真实身体记录为准，尚在推进的项目仍需等待。'],ending:['回顾已经留下的结果','你回顾已完成的契约、协作与交锋。当前的经营份额、组织影响和街区安全仍然保留，之后的行动会继续改变它们。']};
 const [title,text]=messages[kind];
 // encounter：无「继续核对细节」；正文／选项由 encounter-prose 与地点链覆盖（见下）。
 const choices=kind==='daily'?[choice('完成一次公共协作','你完成了当前可用的公共协作。',null,[{op:'progression.act',move:'aid'}],[{op:'progression.available',move:'aid'}])]:kind==='conversation'?[choice('聊聊今天的近况','你们围着眼前的日常寒暄了几句，气氛平和融洽。',null,[{op:'resident.talk'}],[{op:'resident.available'}])]:kind==='exploration'?[choice('看看附近正在发生的事','你沿{place}的通道走去，留意居民和当地事务。',null,[time(5),{op:'world.encounter'}])]:kind==='transformation'?[choice('练习转身与平衡（10分钟）','你在{place}练习转身与平衡。{tfState}',null,[time(10)])]:[];
 node(kind+'.start',kind,'start',title,text,choices);
 // Keep old stage IDs readable for saved games, but no new choices lead to empty detail stages.
 if(!['daily','conversation','encounter'].includes(kind))node(kind+'.detail',kind,'detail','返回实际行动','你回到{place}的公共通道。{nearby}',[]);
}
node('exploration.night','exploration','start','夜间的通道','夜色已经笼罩了{place}。你借着廊下的路灯打量四周的告示牌，先辨清几条尚有照明的安全通道。',[choice('记下照明明确的通道','你核对并记录了当前可见的路线。',null,[time(5),change('safety',1)])],{priority:4,requiresTags:[{role:'environment',tagId:'foundation:time.night'}]});
node('transformation.tail','transformation','start','尾部动作练习','你放慢转身的步幅，体会着身后尾部摆动时的重心牵引与支撑分寸，让行止与目前的体态愈发协调。',[choice('完成这一次适应练习','你舒展了一下腰背与尾节，动作比刚才顺畅了许多。',null,[time(5)])],{priority:4,requiresTags:[{role:'player',tagId:'foundation:body.has-tail'}]});
node('defeat.control.cautious','defeat','start','先核对风险','{opponent}没有立刻改变现场，而是先核对周围的风险。对方要求你停止贸然发力，留出检查限制位置的时间。你可以配合检查，也可以直接提出离开。',[choice('先核对自己的处境','你用几分钟确认了限制所在。','assess',[time(5)],[],[scoped('player','assessed')]),choice('请求值班协助','你清楚说明位置，请求协助。','help',[time(5)],[],[scoped('player','signal')])],{priority:5,requiresTags:[scoped('opponent','goal.control')],tendencies:[{tagId:tag('control'),weight:1},{tagId:tag('cautious'),weight:3}]});
node('defeat.repair.cautious','defeat','start','先说明维护范围','{opponent}先把工具留在你能看见的位置，逐项说明维护范围，再等待你的决定。任何实际调整都需要你接下来的明确选择。',[choice('听清范围后再决定','你听清维护范围，保留接受或拒绝的选择。','repair',[time(5)]),choice('拒绝这次维护','你拒绝这次维护，沿安全通道离开。',null,[time(5),health(3)])],{priority:5,requiresTags:[scoped('opponent','goal.repair'),scoped('opponent','tools')],tendencies:[{tagId:tag('repair'),weight:1},{tagId:tag('cautious'),weight:3}]});
node('exploration.workshop','exploration','start','工坊里的工作','{period}，{place}的工作台旁留着一块空位。{nearby}你可以帮忙{localWork}，或认识在场的人。',[choice('参与整理工作','你把{place}的工具分门别类放好。',null,[{op:'progression.act',move:'aid'}],[{op:'progression.available',move:'aid'}]),choice('认识在场的人','你走到工作台旁，与在场的人打招呼。',null,[{op:'world.encounter',events:false}])],{priority:4,requiresTags:[{role:'environment',tagId:'foundation:service.workshop'}]});
node('daily.tired','daily','start','先恢复一些力气','你当前的体力不足以安排强度较高的工作。你可以先找个安全位置休息，恢复之后再处理当天事务。',[choice('休息半小时','你休息了半小时，体力与精力恢复。',null,[time(30),{op:'var.change',id:'core:stamina',amount:12},{op:'var.change',id:'core:energy',amount:12}])],{priority:4,conditions:[{op:'var.compare',id:'core:stamina',comparison:'lte',value:19}]});
node('conversation.progress','conversation','start','谈谈近来的街区变化','你与在场的{opponent}聊起这段日子街区里办成的几件实事。对方听得很入神，不时顺着你的话头添上几句本地人的见闻。',[choice('细说近况并听取回应','你们就着近来的变化畅聊了一番，彼此都对眼下的局面多了几分默契。',null,[{op:'resident.talk'}],[{op:'resident.available'}])],{priority:4,conditions:[{op:'adventure.compare',field:'reputation',comparison:'gte',value:4}]});
node('ending.resource','ending','start','盘点手头的产业与契约','你翻开随身账册，逐一清点这段时间攒下的经营份额、已交割的订单与长约。账面上的每一笔进项都见证着你在当地站稳脚跟的历程。',[choice('合上账册，维持当前经营步调','你合上账册收好凭据，准备按既定步调继续打理手头的生意。')],{priority:4,conditions:[{op:'adventure.compare',field:'assets',comparison:'gte',value:6}]});
node('ending.security','ending','start','回顾巡防与交锋经历','你站在通道高处，回想起这段日子平息的冲突与巡查过的街巷。如今四周秩序井然，往来行人的神色也比初来时从容了不少。',[choice('收回思绪，继续眼下的日常','你收回目光，整理了一下衣襟，继续投入当地的日常事务。')],{priority:4,conditions:[{op:'adventure.compare',field:'victories',comparison:'gte',value:2},{op:'adventure.compare',field:'safety',comparison:'gte',value:5}]});
p.bodyPatches.push({id:id('patch.tail-maintenance'),label:'机械尾外伸长度调整',summary:'尾部外伸长度调整至650毫米',operations:[{type:'attributes',partId:'tail',set:{lengthMm:650},unset:[]}]});
p.transformations.push({id:id('tf.tail-maintenance'),label:'机械尾长度维护',source:'story',stages:[{id:'adjusted',label:'长度调整完成',atMinutes:15,patchId:id('patch.tail-maintenance'),textKey:id('text.tail-maintenance')}]});p.texts[id('text.tail-maintenance')]='本次确认的长度调整已经完成，真实尾部参数更新为650毫米。';
const existingProfiles=new Set(base.flatMap(p=>p.locationProfiles??[]).map(l=>l.locationId));
const locationEnv={
 canal:['foundation:context.waterways','foundation:theme.gel','foundation:theme.risk'],
 station:['foundation:theme.boundary','foundation:theme.risk'],
 workshop:['foundation:theme.mechanical','foundation:theme.equipment'],
 market:['foundation:theme.trade','foundation:theme.economy'],
 cafe:['foundation:theme.social'],
 archive:['foundation:theme.investigation'],
 street:['foundation:theme.exploration'],
 apartment:['foundation:theme.rest'],
 clinic:['foundation:theme.care'],
 salon:['foundation:theme.social']
};
for(const loc of base.flatMap(p=>p.locations)){if(existingProfiles.has(loc.id))continue;const suffix=loc.id.split('.').at(-1);const service=({apartment:'home',market:'market',clinic:'clinic',workshop:'workshop',salon:'commons',cafe:'commons',canal:'commons',archive:'commons',station:'commons',street:'commons'})[suffix]??'commons';p.locationProfiles.push({id:id('location-profile.'+suffix),locationId:loc.id,service,light:'lit',tags:locationEnv[suffix]??[]});}
const service=values=>({op:'any',conditions:values.map(value=>({op:'environment.service',value}))});
action('rest','安全休息半小时',[time(30),{op:'var.change',id:'core:stamina',amount:12},{op:'var.change',id:'core:energy',amount:12}],[],'30分钟 · 体力+12 · 精力+12');
action('sleep','休息到次日同一时刻',[time(1440),{op:'var.change',id:'core:stamina',amount:50},{op:'var.change',id:'core:energy',amount:70}],[],'24小时 · 体力+50 · 精力+70');
action('care','接受基础伤势处理',[time(30),health(12)],[],'30分钟 · 生命+12');
for(const [stat,label]of [['attack','攻击'],['defense','防御'],['speed','速度'],['skillPower','技能强度'],['hit','命中'],['evasion','闪避'],['crit','暴击']])action('train.'+stat,'训练'+label,[{op:'progression.act',move:'train',id:'core:'+stat}],[{op:'progression.available',move:'train',id:'core:'+stat}],'45分钟 · 零钱−8 · 体力−8 · 精力−4 · '+label+'+1');
for(const [move,label,hint]of [['order','完成一份公开订单','30分钟 · 体力−8 · 精力−5 · 报酬与经营份额'],['invest','登记经营份额','45分钟 · 零钱−30 · 经营份额+2 · 契约+1'],['patrol','完成一次街区巡查','45分钟 · 体力−10 · 安全+2 · 组织影响+1'],['aid','参与公共协作','30分钟 · 体力−4 · 声望+2 · 安全+1'],['reconcile','调解一项当地分歧','30分钟 · 精力−4 · 组织影响+1']])action(move,label,[{op:'progression.act',move}],[{op:'progression.available',move}],hint);
const priceOf=slot=>slot==='held'||slot==='weapon'?25:slot==='accessory'||slot==='cosmetic'?12:30;
const part=(kind)=>({op:'body.matches',target:{kind:'player'},part:{kind}});
for(const [name,label,slot,bonuses,requires]of [
 ['blade','工坊制式工具刃','held',{attack:3},[grasp]],
 ['staff','平衡练习杖','held',{attack:2},[grasp]],
 ['vest','加固巡查背心','body',{defense:3,evasion:3},[grasp]],
 ['coat','轻型防护外套','body',{defense:2,evasion:5},[grasp]],
 ['helm','巡查护额','head',{defense:1,evasion:1},[part('head')]],
 ['gloves','工坊防护手套','hands',{defense:1},[grasp]],
 ['greaves','轻型护胫','legs',{defense:1,evasion:2},[part('leg')]],
 ['charm','街区通行挂件','accessory',{},[]],
 ['probe','工坊测量探针','held',{},[grasp]],
 ['tailguard','尾部护套','tail',{defense:1},[part('tail')]],
]){
 const eid=id('equipment.'+name);p.equipment.push({id:eid,name:label,slot,bonuses,description:label+'已穿戴；战斗时叠加装备属性，基础属性保持。',requires});
 action('buy.'+name,'购买'+label,[{op:'progression.act',move:'buy',id:eid}],[{op:'progression.available',move:'buy',id:eid}],`10分钟 · 零钱−${priceOf(slot)}`);
 action('wear.'+name,'装备'+label,[{op:'equipment.wear',id:eid}],[],'已购装备；同槽替换');
}
// 消耗品样本：恢复 / 战斗辅助 / 探索（仅已有 core 变量）；成人门类跳过
for(const [name,label,category,effects,price,usableInCombat,desc]of [
 ['salve','夜光创口胶','recovery',[{op:'var.change',id:'core:health',amount:12}],8,false,'涂抹后即时恢复生命。'],
 ['ration','电解口粮','recovery',[{op:'var.change',id:'core:energy',amount:10}],6,false,'短时补充精力。'],
 ['tonic','净水冲剂','recovery',[{op:'var.change',id:'core:stamina',amount:10}],6,false,'恢复体力。'],
 ['cell','脉冲蓄能片','combat',[{op:'var.change',id:'core:skillResource',amount:12}],10,true,'战斗中补充技能资源。'],
 ['candy','战术高糖软片','combat',[{op:'var.change',id:'core:stamina',amount:8}],8,true,'战斗中补充体力。'],
 ['calm','暗巷冷静贴','explore',[{op:'var.change',id:'core:sanity',amount:15}],15,false,'镇定药水（小）：回升理智 +15；不清除崩溃标记。'],
 ['calm.strong','深井清心饮','explore',[{op:'var.change',id:'core:sanity',amount:25}],35,false,'镇定药水（大）：回升理智 +25；不清除崩溃标记。'],
]){
 const iid=id('item.'+name);
 p.items.push({id:iid,name:label,description:desc,category,effects,price,maxStack:20,usableInCombat});
 action('buy.item.'+name,'购买'+label,[{op:'progression.act',move:'buy',id:iid}],[{op:'progression.available',move:'buy',id:iid}],`10分钟 · 零钱−${price}`);
 action('use.item.'+name,'使用'+label,[{op:'item.use',id:iid}],[{op:'item.has',id:iid,comparison:'gte',value:1}],'5分钟 · 消耗1个');
 if(usableInCombat) action('combat.item.'+name,'战内使用：'+label,[{op:'combat.turn',move:'item',id:iid}],[{op:'item.has',id:iid,comparison:'gte',value:1}],'行动点1 · 消耗1个');
}
action('combat.skill','技能击',[{op:'combat.turn',move:'skill'}],[],'技能资源−15 · 体力−4 · 行动点2');
action('combat.surrender','投降',[{op:'combat.turn',move:'surrender'}],[],'立即结束交锋，进入战败后续；不额外损失生命或体力');
action('combat.giveup','彻底放弃',[{op:'combat.turn',move:'giveup'}],[],'放弃抵抗，交由当前对手处理后续；保留本局进度');
for(const result of ['victory','escape','defeat']){
 const eid=id('event.'+result),aid=id('action.event.'+result),prompt=id('text.event.'+result),end=id('text.event.'+result+'.end');p.texts[prompt]=({victory:'交锋已经结束。实际奖励、胜利记录与街区后果已经结算。',escape:'你已经撤离这次交锋，没有获得战斗奖励。',defeat:'你暂时失去继续交锋的能力，仍可以离开并恢复。'})[result];p.texts[end]='你回到当前地点，可以休息、处理伤势或继续行动。';p.actions.push({id:aid,label:'返回安全位置',hint:'免费退出',group:'event',context:{eventId:eid,nodeId:'start'},conditions:[],effects:[{op:'event.advance',nodeId:'end'}],resultText:end});p.events.push({id:eid,startNode:'start',rating:'general',nodes:[{id:'start',type:'choice',textVariants:[prompt],actionIds:[aid],onEnter:[]},{id:'end',type:'exit',textVariants:[end],actionIds:[],onEnter:[{op:'event.exit'}]}]});
}
for(const [name,label,tier,hp,attack,defense,speed,reward,actions]of [['raider','抢占通道的游荡者','S',45,9,5,9,12,1],['sentinel','封锁通道的重装哨卫','L',90,16,12,12,28,2],['overseer','维护核心的失控监理','boss',160,18,14,11,50,2]]){
 const enemyId=id('enemy.'+name);p.enemies.push({id:enemyId,name:label,hp,reward,tier,combat:{attack,defense,speed,skillPower:attack,hit:75,evasion:8,crit:5,actionsPerTurn:actions,skillResource:0},...(tier==='boss'?{phases:[{hpRatio:0.5,defenseBonus:4,extraActions:1}]}:{}),intents:[{label:'逼近并试探',damage:5,guard:2,drain:0},{label:'稳住防护',damage:2,guard:5,drain:0},{label:'集中力量攻击',damage:12,guard:0,drain:1}],victoryEventId:id('event.victory'),defeatEventId:id('event.defeat'),escapeEventId:id('event.escape')});
 action('challenge.'+name,'挑战：'+label,[{op:'combat.start',id:enemyId}],[service(['commons','workshop']),...(tier==='L'?[{op:'adventure.compare',field:'victories',comparison:'gte',value:2}]:tier==='boss'?[{op:'adventure.compare',field:'victories',comparison:'gte',value:4},{op:'adventure.compare',field:'influence',comparison:'gte',value:4}]:[])],'观察属性后交锋；可以撤离','explore');
}
for(const [name,eid]of [['gel','district:enemy.gel'],['collector','district:enemy.collector']])action('challenge.'+name,'调查危险：'+(name==='gel'?'渠底黑胶群落':'拦路收债客'),[{op:'combat.start',id:eid}],[service(['commons','market'])],'交锋、撤离或战后恢复','explore');
for(const kind of ['encounter','exploration','daily','conversation','quest','transformation','ending']){
  const labels={encounter:'留意一次当地遭遇',exploration:'仔细查看当前环境',daily:'安排一段日常事务',conversation:'与在场居民继续交谈',quest:'核对当前进展',transformation:'练习适应当前身体',ending:'回顾已经留下的结果'};
  // 当地遭遇不强制 nsfwcombo 档案：优先地点链（城门旅馆 inn.gate）与有正文的 start；组合遭遇走专用 action。
  const effects=[{op:'narrative.start',kind}];
  const conditions=kind==='conversation'?[{op:'resident.available'}]:kind==='ending'?[{op:'adventure.compare',field:'reputation',comparison:'gte',value:1}]:[];
  const hint=kind==='encounter'?'地点场面优先（城门旅馆多拍／可读 start）；无空壳核对':'根据当前状态展开；可以免费结束';
  action('narrative.'+kind,labels[kind],effects,conditions,hint,'explore');
}
const scopedDefeat=(...keys)=>keys.map(k=>scoped('player',k));
const envRule=(name,enemyId,requires,extra={})=>p.environmentEnemyRules.push({id:id('env-enemy.'+name),enemyId,requiresTags:requires,weight:extra.weight??10,priority:extra.priority??0,...(extra.excludes?{excludesTags:extra.excludes}:{}),...(extra.name?{name:extra.name}:{}),...(extra.hp?{hp:extra.hp}:{}),...(extra.reward!==undefined?{reward:extra.reward}:{}),...(extra.combat?{combat:extra.combat}:{}),...(extra.defeatTags?{defeatTags:extra.defeatTags}:{})});
// 地点层挂接：环境 tag 组合 → scavenger / collector / gel；可覆盖数值与 defeatTags。
envRule('gel.canal','district:enemy.gel',['foundation:service.commons','foundation:context.waterways','foundation:theme.gel'],{weight:20,name:'渠底黑胶群落（湿滑）',hp:38,combat:{defense:6,speed:7,attack:8},defeatTags:scopedDefeat('clear','injured','coat.stuck')});
envRule('scavenger.canal','district:enemy.scavenger',['foundation:service.commons','foundation:context.waterways','foundation:theme.risk'],{weight:12,name:'失控搬运机（渠道）',combat:{attack:10,defense:6},defeatTags:scopedDefeat('clear','injured')});
envRule('scavenger.workshop','district:enemy.scavenger',['foundation:service.workshop','foundation:theme.mechanical'],{weight:18,name:'失控搬运机（工坊）',hp:44,combat:{attack:11,defense:7,speed:8},defeatTags:scopedDefeat('clear','injured','hands.restricted')});
envRule('collector.station','district:enemy.collector',['foundation:service.commons','foundation:theme.boundary'],{weight:16,name:'拦路收债客（检查站）',combat:{attack:13,speed:11},defeatTags:scopedDefeat('clear','injured')});
envRule('collector.market','district:enemy.collector',['foundation:service.market','foundation:theme.trade'],{weight:16,name:'拦路收债客（市集）',hp:65,reward:18,combat:{attack:12,defense:9},defeatTags:scopedDefeat('clear','injured')});
action('encounter.env','调查危险环境',[{op:'combat.encounter'}],[],'按当前地点环境 tag 匹配敌人；可覆盖数值与战败节点','explore');

// —— NSFW 定词材质×部位×动作 自动组合（制作卡 proposed-nodes / U6）——
// 合载：运行 tag + profile + encounter 候选节点；不改词库审定；不伪造 foundation:*。
const nsfwAtoms = await loadAtoms();
const nsfwCombos = sampleCombos(nsfwAtoms);
p.tags.push({
  id: tag('nsfwcombo.active'),
  label: 'NSFW组合遭遇激活',
  definition: '故事局部：本次遭遇由 NSFW 自动组合器（材质×部位×动作）选中；不等于词库审定，不授予身体能力，不表示 TF 已完成。',
  facets: ['context'],
  status: 'active',
  aliases: [],
});
p.narrativeProfiles.push({
  id: id('profile.nsfwcombo.matrix'),
  tags: [tag('nsfwcombo.active')],
  goals: [],
  tendencies: [],
  defeatTags: [],
});
const adultGate = [{ op: 'preference.adultOptional', value: true }];
// —— fantasy 遭遇场面：通用回退 + 地点特化 + 城门旅馆 3 拍 ——
const encounterProse = await json('content/adventure/encounter-prose.json');
if (encounterProse.format !== 'aetheria-encounter-location-prose' || encounterProse.schemaVersion !== 1) {
  throw new Error('encounter-prose.json 格式无效。');
}
const ep = encounterProse.texts ?? {};
const takeEp = (key, fallback = '') => {
  const body = ep[key] ?? fallback;
  if (typeof body !== 'string' || !body.trim()) throw new Error('遭遇正文空槽：' + key);
  p.texts[key] = body;
  return key;
};
const freeExit = (resultKey, body = '你停下这次接触，回到可以继续行动的位置。') => {
  p.texts[resultKey] = body;
  return { label: '结束当前经历，回到安全位置', resultText: resultKey, next: null, effects: [], conditions: [], setTags: [], unsetTags: [] };
};
const sceneChoice = (label, resultKey, next = null, effects = [], conditions = []) => ({
  label, resultText: resultKey, next, effects, conditions, setTags: [], unsetTags: [],
});
takeEp(id('text.node.encounter.start'));
takeEp(id('text.choice.encounter.generic.engage'));
takeEp(id('text.choice.encounter.generic.avoid'));
takeEp(id('text.choice.encounter.generic.alt'));
{
  const startNode = p.narrativeNodes.find((n) => n.id === id('node.encounter.start'));
  if (!startNode) throw new Error('missing encounter.start');
  startNode.title = '当地的动静';
  startNode.choices = [
    sceneChoice('上前参与眼下这一幕', id('text.choice.encounter.generic.engage'), null, [time(5)]),
    sceneChoice('先退开，从安全距离观望', id('text.choice.encounter.generic.avoid'), null, [time(5)]),
    sceneChoice('换一条路绕开', id('text.choice.encounter.generic.alt'), null, [time(5)]),
    freeExit(id('text.choice.encounter.generic.exit')),
  ];
}
takeEp(id('text.node.encounter.start.street'));
p.narrativeNodes.push({
  id: id('node.encounter.start.street'), kind: 'encounter', stage: 'start', title: '公会外的动静',
  textKey: id('text.node.encounter.start.street'), requiresTags: [], excludesTags: [scoped('opponent', 'nsfwcombo.active')],
  conditions: [{ op: 'any', conditions: [{ op: 'environment.service', value: 'commons' }, { op: 'environment.service', value: 'market' }] }],
  tendencies: [], weight: 12, priority: 4, maxVisits: 1,
  choices: [
    sceneChoice('上前拦住黏液', id('text.choice.encounter.generic.engage'), null, [time(5)]),
    sceneChoice('退回公会门口观望', id('text.choice.encounter.generic.avoid'), null, [time(5)]),
    sceneChoice('改从侧巷绕开', id('text.choice.encounter.generic.alt'), null, [time(5)]),
    freeExit(id('text.choice.encounter.street.exit'), '你离开巷口，回到可以继续行动的位置。'),
  ],
});
takeEp(id('text.node.encounter.start.canal'));
p.narrativeNodes.push({
  id: id('node.encounter.start.canal'), kind: 'encounter', stage: 'start', title: '运河边的动静',
  textKey: id('text.node.encounter.start.canal'),
  requiresTags: [{ role: 'environment', tagId: 'foundation:context.waterways' }],
  excludesTags: [scoped('opponent', 'nsfwcombo.active')], conditions: [], tendencies: [], weight: 14, priority: 5, maxVisits: 1,
  choices: [
    sceneChoice('上前察看', id('text.choice.encounter.generic.engage'), null, [time(5)]),
    sceneChoice('退到桥墩后观望', id('text.choice.encounter.generic.avoid'), null, [time(5)]),
    sceneChoice('改走市场内廊绕开', id('text.choice.encounter.generic.alt'), null, [time(5)]),
    freeExit(id('text.choice.encounter.canal.exit'), '你离开缆桩边，回到可以继续行动的位置。'),
  ],
});
for (const key of [
  'text.node.encounter.inn.gate.capture','text.node.encounter.inn.gate.press','text.node.encounter.inn.gate.press.adult',
  'text.node.encounter.inn.gate.resolve','text.node.encounter.inn.gate.detail',
  'text.choice.encounter.inn.gate.engage','text.choice.encounter.inn.gate.avoid','text.choice.encounter.inn.gate.alt',
  'text.choice.encounter.inn.gate.exit','text.choice.encounter.inn.gate.press.engage','text.choice.encounter.inn.gate.press.avoid',
  'text.choice.encounter.inn.gate.press.alt','text.choice.encounter.inn.gate.resolve.detail','text.choice.encounter.inn.gate.resolve.ask',
  'text.choice.encounter.inn.gate.resolve.leave','text.choice.encounter.inn.gate.detail.poke','text.choice.encounter.inn.gate.detail.back',
  'text.choice.encounter.inn.gate.detail.ask',
]) takeEp(id(key));
const innExit = freeExit(id('text.choice.encounter.inn.gate.exit'), ep[id('text.choice.encounter.inn.gate.exit')]);
p.narrativeNodes.push({
  id: id('node.encounter.inn.gate.capture'), kind: 'encounter', stage: 'start', title: '城门旅馆的水痕',
  textKey: id('text.node.encounter.inn.gate.capture'), requiresTags: [], excludesTags: [scoped('opponent', 'nsfwcombo.active')],
  conditions: [{ op: 'environment.service', value: 'home' }], tendencies: [], weight: 20, priority: 8, maxVisits: 1,
  choices: [
    sceneChoice('上前拦住黏液', id('text.choice.encounter.inn.gate.engage'), 'inn-gate-press', [time(5)]),
    sceneChoice('退到门口观望', id('text.choice.encounter.inn.gate.avoid'), 'inn-gate-press', [time(5)]),
    sceneChoice('改走侧廊绕开', id('text.choice.encounter.inn.gate.alt'), 'inn-gate-resolve', [time(5)]),
    innExit,
  ],
});
p.narrativeNodes.push({
  id: id('node.encounter.inn.gate.press'), kind: 'encounter', stage: 'inn-gate-press', title: '黏液贴上靴尖',
  textKey: id('text.node.encounter.inn.gate.press'), requiresTags: [], excludesTags: [], conditions: [], tendencies: [],
  weight: 10, priority: 5, maxVisits: 1,
  choices: [
    sceneChoice('伸手拨开', id('text.choice.encounter.inn.gate.press.engage'), 'inn-gate-resolve', [time(5)]),
    sceneChoice('退回门廊', id('text.choice.encounter.inn.gate.press.avoid'), 'inn-gate-resolve', [time(5)]),
    sceneChoice('用桌布隔开', id('text.choice.encounter.inn.gate.press.alt'), 'inn-gate-resolve', [time(5)]),
    innExit,
  ],
});
p.narrativeNodes.push({
  id: id('node.encounter.inn.gate.press.adult'), kind: 'encounter', stage: 'inn-gate-press', title: '黏液沿腿上爬',
  textKey: id('text.node.encounter.inn.gate.press.adult'), requiresTags: [], excludesTags: [], conditions: adultGate, tendencies: [],
  weight: 10, priority: 6, maxVisits: 1,
  choices: [
    sceneChoice('并拢腿根挡住', id('text.choice.encounter.inn.gate.press.avoid'), 'inn-gate-resolve', [time(5)]),
    sceneChoice('退开', id('text.choice.encounter.inn.gate.press.avoid'), 'inn-gate-resolve', [time(5)]),
    sceneChoice('用桌布隔开接触', id('text.choice.encounter.inn.gate.press.alt'), 'inn-gate-resolve', [time(5)]),
    innExit,
  ],
});
p.narrativeNodes.push({
  id: id('node.encounter.inn.gate.resolve'), kind: 'encounter', stage: 'inn-gate-resolve', title: '水痕停住之后',
  textKey: id('text.node.encounter.inn.gate.resolve'), requiresTags: [], excludesTags: [], conditions: [], tendencies: [],
  weight: 10, priority: 5, maxVisits: 1,
  choices: [
    sceneChoice('再看一眼残迹', id('text.choice.encounter.inn.gate.resolve.detail'), 'inn-gate-detail', [time(5)]),
    sceneChoice('向值守询问', id('text.choice.encounter.inn.gate.resolve.ask'), null, [time(5)]),
    sceneChoice('转身离开堂厅', id('text.choice.encounter.inn.gate.resolve.leave'), null, []),
    innExit,
  ],
});
p.narrativeNodes.push({
  id: id('node.encounter.inn.gate.detail'), kind: 'encounter', stage: 'inn-gate-detail', title: '桌腿旁的细节',
  textKey: id('text.node.encounter.inn.gate.detail'), requiresTags: [], excludesTags: [], conditions: [], tendencies: [],
  weight: 10, priority: 5, maxVisits: 1,
  choices: [
    sceneChoice('伸手挑开布条', id('text.choice.encounter.inn.gate.detail.poke'), null, [time(5)]),
    sceneChoice('退回原处', id('text.choice.encounter.inn.gate.detail.back'), null, []),
    sceneChoice('改问值守', id('text.choice.encounter.inn.gate.detail.ask'), null, [time(5)]),
    innExit,
  ],
});

const nsfwCandidates = [];
for (const combo of nsfwCombos) {
  const slug = (combo.sampleId ?? 'x').toLowerCase();
  const cand = toEncounterCandidate(combo, {
    nodeId: id(`node.encounter.nsfwcombo.${slug}`),
    textKey: id(`text.node.encounter.nsfwcombo.${slug}`),
    requireTagId: tag('nsfwcombo.active'),
    priority: 5,
    weight: 10,
  });
  nsfwCandidates.push(cand);
  p.texts[cand.node.textKey] = cand.fragment;
  // detail 组合键说明书仅保留在 texts / candidates（制作对照），不挂可玩节点，避免「核对组合原子」二次确认。
  const detailKey = id(`text.node.encounter.nsfwcombo.${slug}.detail`);
  p.texts[detailKey] = cand.texts.detail;
  const startChoices = [];
  let adultKey = null;
  const branchSlugs = new Set(['c6', 'c7']);
  if (branchSlugs.has(slug)) {
    // C6/C7：场面正文 + 参与／回避／换手段；成人槽为更高 priority 的 start 变体（非核对说明书）
    for (const arm of ['engage', 'avoid', 'alt']) {
      const rk = id(`text.choice.nsfwcombo.${slug}.${arm}`);
      takeEp(rk);
    }
    // max 4 choices: engage / avoid / alt / exit
    startChoices.push(
      sceneChoice(slug === 'c6' ? '放松膝弯迎上' : '任封眼收紧', id(`text.choice.nsfwcombo.${slug}.engage`), null, [time(5)]),
      sceneChoice(slug === 'c6' ? '夹紧腿根退开' : '扯开眼前黏液', id(`text.choice.nsfwcombo.${slug}.avoid`), null, [time(5)]),
      sceneChoice(slug === 'c6' ? '用衣角隔开' : '抬手护眼隔开', id(`text.choice.nsfwcombo.${slug}.alt`), null, [time(5)]),
    );
  }
  if (combo.adultRequired) {
    adultKey = id(`text.node.encounter.nsfwcombo.${slug}.adult`);
    p.texts[adultKey] = [
      `【可填成人正文槽 · ${combo.sampleId} · ${combo.comboKey}】`,
      '占位：在此写入同意前提下的成人向遭遇描写（材质×部位×动作）。',
      '关闭 adultOptional 或不满足成年资格时，玩家看不到本选项；主节点中性 fragment 仍可用。',
      '勿写未成年人；勿伪造 foundation:*；勿写物种 TF 专条。',
      `lexiconRefs：${combo.lexiconRefs.join('、')}`,
    ].join('\n');
    if (!branchSlugs.has(slug)) {
      const adultResult = id(`text.choice.nsfwcombo.${slug}.adult`);
      p.texts[adultResult] = '你留意着当下的贴身感官细节，仍可随时抽身离开。';
      startChoices.push({
        label: '阅读成人向补充描写',
        resultText: adultResult,
        next: 'nsfwcombo-adult',
        effects: [time(5)],
        conditions: adultGate,
        setTags: [],
        unsetTags: [],
      });
    }
  }
  startChoices.push(exit());
  if (startChoices.length > 4) throw new Error(`nsfwcombo.${slug} choices>${4}`);
  p.narrativeNodes.push({
    ...cand.node,
    choices: startChoices,
  });
  if (adultKey && branchSlugs.has(slug)) {
    // 成人门开启时优先抽成人场面 start（同 requiresTags），选项与中性一致
    p.narrativeNodes.push({
      id: id(`node.encounter.nsfwcombo.${slug}.adult`),
      kind: 'encounter',
      stage: 'start',
      title: `${combo.title} · 成人`,
      textKey: adultKey,
      requiresTags: [scoped('opponent', 'nsfwcombo.active')],
      excludesTags: [],
      conditions: adultGate,
      tendencies: [],
      weight: 10,
      priority: 6,
      maxVisits: 1,
      choices: startChoices.map((c) => ({ ...c })),
    });
  } else if (adultKey) {
    p.narrativeNodes.push({
      id: id(`node.encounter.nsfwcombo.${slug}.adult`),
      kind: 'encounter',
      stage: 'nsfwcombo-adult',
      title: `${combo.title} · 成人补充`,
      textKey: adultKey,
      requiresTags: [scoped('opponent', 'nsfwcombo.active')],
      excludesTags: [],
      conditions: adultGate,
      tendencies: [],
      weight: 10,
      priority: 5,
      maxVisits: 1,
      choices: [exit()],
    });
  }
  cand.adultTextKey = adultKey;
  cand.fillable = {
    neutralTextKey: cand.node.textKey,
    detailTextKey: detailKey,
    detailPlayable: false,
    adultTextKey: adultKey,
    startNodeId: cand.node.id,
    detailNodeId: null,
    adultNodeId: adultKey ? id(`node.encounter.nsfwcombo.${slug}.adult`) : null,
  };
}
action(
  'nsfwcombo.encounter',
  '试跑 NSFW 材质组合遭遇',
  [{ op: 'narrative.start', kind: 'encounter', profileId: id('profile.nsfwcombo.matrix') }],
  [],
  '定词材质×部位×动作 → 候选遭遇节点；不改审定；成人完整正文另见 adult 门',
  'explore',
);
// existing-prose 回填：覆盖 start 中性槽与已有 .adult 槽（.detail / choice 本批不动）
const proseFillsPath = 'content/nsfw-auto-combo/prose-fills.json';
let proseFillCount = 0;
try {
  const proseFills = await json(proseFillsPath);
  if (proseFills.format !== 'aetheria-nsfw-auto-combo-prose-fills' || proseFills.schemaVersion !== 1) {
    throw new Error('prose-fills.json 格式无效。');
  }
  for (const [key, body] of Object.entries(proseFills.texts ?? {})) {
    if (typeof body !== 'string' || !body.trim()) throw new Error(`散文回填空槽：${key}`);
    if (!(key in p.texts)) throw new Error(`散文回填目标不存在于 pack.texts：${key}`);
    p.texts[key] = body;
    proseFillCount += 1;
    for (const c of nsfwCandidates) {
      if (c.node.textKey === key) c.fragment = body;
      if (c.adultTextKey === key) c.adultFragment = body;
    }
  }
} catch (err) {
  if (err && err.code === 'ENOENT') {
    // 无回填文件时保留组合器 stub
  } else {
    throw err;
  }
}

await mkdir('content/nsfw-auto-combo', { recursive: true });
await writeFile(
  'content/nsfw-auto-combo/candidates.json',
  JSON.stringify(
    {
      format: 'aetheria-nsfw-auto-combo-candidates',
      schemaVersion: 1,
      generatedFrom: nsfwAtoms.sourceCard,
      count: nsfwCandidates.length,
      proseFillsApplied: proseFillCount,
      gameplayFilter: nsfwAtoms.playtestFilter ?? null,
      emptyShellDisabled: true,
      note: '当地遭遇优先地点链／可读 start；nsfwcombo 走专用 action；空壳核对与组合键 detail 不可玩。',
      howToVerifyNoEmptyGateInn: encounterProse.howToVerifyNoEmptyGateInn ?? [
        '一键 fantasy → 城门旅馆 → 留意一次当地遭遇 → 应为 inn.gate capture，无空壳核对。',
      ],
      candidates: nsfwCandidates.map((c) => ({
        sampleId: c.sampleId,
        comboKey: c.comboKey,
        gameplay: c.gameplay ?? null,
        fantasyNpcKind: c.fantasyNpcKind ?? null,
        adultRequired: c.adultRequired,
        lexiconRefs: c.lexiconRefs,
        proposedRuntimeTags: c.proposedRuntimeTags,
        nodeId: c.node.id,
        fragment: c.fragment,
        adultFragment: c.adultFragment ?? null,
        fillable: c.fillable,
        adultTextKey: c.adultTextKey,
      })),
    },
    null,
    2,
  ) + '\n',
);


// —— fantasy 战败后 8 玩法大类（proposed-nodes 合载）——
// G1–G3：4 拍 capture→press→peak→resolve；textKey progression:text.node.defeat.g{N}.{stage}[+.adult]
// G4–G8：单段 capture + adult（不硬装空多段链）；peak 样文仅 fills.peakSamplesNotInstalled
// 成人门 adultOptional；词条≠玩法≠数值；不硬换 gel 战败链（defeat.control / coat / profile.gel）
const defeatPlayStageChain = ['capture', 'press', 'peak', 'resolve'];
const defeatPlayMeta = [
  { n: 1, key: 'G1', name: '束缚制服', multiBeat: true },
  { n: 2, key: 'G2', name: '材质覆层转化', multiBeat: true },
  { n: 3, key: 'G3', name: '侵犯插入', multiBeat: true },
  { n: 4, key: 'G4', name: '口封感官剥夺', multiBeat: true },
  { n: 5, key: 'G5', name: '产卵灌注', multiBeat: true },
  { n: 6, key: 'G6', name: '公开羞辱', multiBeat: true },
  { n: 7, key: 'G7', name: '主从调教', multiBeat: true },
  { n: 8, key: 'G8', name: '多体围攻', multiBeat: true },
];
const defeatStageTitle = { capture: '捕捉', press: '加压', peak: '高峰', resolve: '收束' };
const defeatContinueLabel = {
  capture: '继续：加压收紧',
  press: '继续：推向高峰',
  peak: '继续：收束脱困',
};
p.tags.push({
  id: tag('defeat.play.active'),
  label: '战败玩法入口激活',
  definition: '故事局部：本次进入 fantasy 战败后 8 玩法大类入口；不等于词库审定，不授予身体能力，不表示脱困/转化/催眠已结算。',
  facets: ['context'],
  status: 'active',
  aliases: [],
});
for (const play of defeatPlayMeta) {
  p.tags.push({
    id: tag(`defeat.play.${play.key.toLowerCase()}`),
    label: play.name,
    definition: `故事局部：战败后玩法大类「${play.name}」选材入口；词条≠玩法≠数值；不表示该玩法效果已结算。`,
    facets: ['context'],
    status: 'active',
    aliases: [],
  });
}
p.narrativeProfiles.push({
  id: id('profile.defeat.play'),
  tags: [tag('defeat.play.active')],
  goals: [],
  tendencies: [],
  defeatTags: [],
});
const playHubChoices = [];
const defeatStageId = (n, stage, adult = false) => {
  const pad = String(n).padStart(2, '0');
  if (stage === 'capture' && !adult) return `play-${pad}`; // hub next 兼容
  return adult ? `play-${pad}-${stage}-adult` : `play-${pad}-${stage}`;
};
for (const play of defeatPlayMeta) {
  const g = `g${play.n}`;
  const pad = String(play.n).padStart(2, '0');
  const stages = play.multiBeat ? defeatPlayStageChain : ['capture'];
  const toPlay = id(`text.choice.defeat.${g}.enter`);
  p.texts[toPlay] = `眼前的局势落入「${play.name}」的压制之中，你仍可随时中断并设法脱身。`;
  playHubChoices.push({
    label: `进入：${play.name}`,
    resultText: toPlay,
    next: defeatStageId(play.n, 'capture'),
    effects: [time(5)],
    conditions: [],
    setTags: [scoped('player', `defeat.play.${play.key.toLowerCase()}`)],
    unsetTags: [],
  });
  for (let si = 0; si < stages.length; si++) {
    const stage = stages[si];
    const nextStage = stages[si + 1];
    const textKey = id(`text.node.defeat.${g}.${stage}`);
    const adultKey = id(`text.node.defeat.${g}.${stage}.adult`);
    const nodeId = id(`node.defeat.${g}.${stage}`);
    const adultNodeId = id(`node.defeat.${g}.${stage}.adult`);
    const stageId = defeatStageId(play.n, stage);
    const adultStageId = defeatStageId(play.n, stage, true);
    p.texts[textKey] = `【可填中性槽·${defeatStageTitle[stage]} ${stage} · ${play.name}】战败后，{opponent}靠近；{material}（定词挂前）贴向{part}。关闭成人偏好时使用本槽。通用转化仅「{tf}」占位，未写入。`;
    p.texts[adultKey] = `【可填成人正文槽 · ${play.name} · ${stage}】占位：同意前提下的成人向战败玩法描写。{opponent} / {material} / {part}。勿写未成年人；勿伪造 foundation:*。`;
    const adultChoiceText = id(`text.choice.defeat.${g}.${stage}.adult`);
    p.texts[adultChoiceText] = '你留意着当下的贴身感官细节，仍可随时抽身离开。';
    const choices = [];
    if (nextStage) {
      const contKey = id(`text.choice.defeat.${g}.${stage}.continue`);
      p.texts[contKey] = `处境进一步向「${defeatStageTitle[nextStage]}」阶段推进，你仍可随时中断离开。`;
      choices.push({
        label: defeatContinueLabel[stage],
        resultText: contKey,
        next: defeatStageId(play.n, nextStage),
        effects: [time(5)],
        conditions: [],
        setTags: [],
        unsetTags: [],
      });
    }
    choices.push({
      label: '阅读成人向补充描写',
      resultText: adultChoiceText,
      next: adultStageId,
      effects: [time(5)],
      conditions: adultGate,
      setTags: [],
      unsetTags: [],
    });
    choices.push(exit());
    p.narrativeNodes.push({
      id: nodeId,
      kind: 'defeat',
      stage: stageId,
      title: `战败 · ${play.name} · ${defeatStageTitle[stage]}`,
      textKey,
      requiresTags: [scoped('opponent', 'defeat.play.active')],
      excludesTags: [],
      conditions: [],
      tendencies: [],
      weight: 10,
      priority: 6,
      maxVisits: 1,
      choices,
    });
    const adultChoices = [];
    if (nextStage) {
      const contAdultKey = id(`text.choice.defeat.${g}.${stage}.adult.continue`);
      p.texts[contAdultKey] = `处境进一步向「${defeatStageTitle[nextStage]}」阶段推进，你仍可随时中断离开。`;
      adultChoices.push({
        label: defeatContinueLabel[stage],
        resultText: contAdultKey,
        next: defeatStageId(play.n, nextStage),
        effects: [time(5)],
        conditions: [],
        setTags: [],
        unsetTags: [],
      });
    }
    adultChoices.push(exit());
    p.narrativeNodes.push({
      id: adultNodeId,
      kind: 'defeat',
      stage: adultStageId,
      title: `战败 · ${play.name} · ${defeatStageTitle[stage]} · 成人补充`,
      textKey: adultKey,
      requiresTags: [scoped('opponent', 'defeat.play.active')],
      excludesTags: [],
      conditions: adultGate,
      tendencies: [],
      weight: 10,
      priority: 6,
      maxVisits: 1,
      choices: adultChoices,
    });
  }
}
const hubText = id('text.node.defeat.play.hub');
p.texts[hubText] = '交锋结束后，{opponent}仍在{place}。你还没有离开现场。你可以选择下一步应对，也可以立即结束这段经历。';
// hub 分页：每页 ≤3 玩法 + exit（shape 上限 4）。G5 必须从 hub3 路径可达。
// hub: G1 G2 | hub2: G3 G4 | hub3: G5 G6 | hub4: G7 G8
p.narrativeNodes.push({
  id: id('node.defeat.play.hub'),
  kind: 'defeat',
  stage: 'start',
  title: '战败后的玩法入口',
  textKey: hubText,
  requiresTags: [scoped('opponent', 'defeat.play.active')],
  excludesTags: [],
  conditions: [],
  tendencies: [],
  weight: 10,
  priority: 8,
  maxVisits: 1,
  choices: [
    playHubChoices[0],
    playHubChoices[1],
    { label: '查看更多玩法…', resultText: id('text.choice.defeat.play.more'), next: 'play-hub-more', effects: [], conditions: [], setTags: [], unsetTags: [] },
    exit(),
  ],
});
p.texts[id('text.choice.defeat.play.more')] = '你继续浏览其余战败玩法入口。';
p.texts[id('text.node.defeat.play.hub2')] = '还有其他玩法大类可选（侵犯插入、口封感官剥夺…）。选择一类进入，或结束回到安全位置。';
p.narrativeNodes.push({
  id: id('node.defeat.play.hub2'),
  kind: 'defeat',
  stage: 'play-hub-more',
  title: '战败玩法 · 更多',
  textKey: id('text.node.defeat.play.hub2'),
  requiresTags: [scoped('opponent', 'defeat.play.active')],
  excludesTags: [],
  conditions: [],
  tendencies: [],
  weight: 10,
  priority: 6,
  maxVisits: 1,
  choices: [
    playHubChoices[2],
    playHubChoices[3],
    { label: '查看其余玩法…', resultText: id('text.choice.defeat.play.more2'), next: 'play-hub-rest', effects: [], conditions: [], setTags: [], unsetTags: [] },
    exit(),
  ],
});
p.texts[id('text.choice.defeat.play.more2')] = '你继续浏览剩余战败玩法入口（含产卵灌注）。';
p.texts[id('text.node.defeat.play.hub3')] = '其余玩法大类：产卵灌注、公开羞辱等。选择一类进入，或查看最后两类。';
p.narrativeNodes.push({
  id: id('node.defeat.play.hub3'),
  kind: 'defeat',
  stage: 'play-hub-rest',
  title: '战败玩法 · 其余',
  textKey: id('text.node.defeat.play.hub3'),
  requiresTags: [scoped('opponent', 'defeat.play.active')],
  excludesTags: [],
  conditions: [],
  tendencies: [],
  weight: 10,
  priority: 6,
  maxVisits: 1,
  choices: [
    playHubChoices[4], // G5 产卵灌注
    playHubChoices[5], // G6
    { label: '查看最后玩法…', resultText: id('text.choice.defeat.play.more3'), next: 'play-hub-last', effects: [], conditions: [], setTags: [], unsetTags: [] },
    exit(),
  ],
});
p.texts[id('text.choice.defeat.play.more3')] = '你查看最后的战败玩法入口。';
p.texts[id('text.node.defeat.play.hub4')] = '最后两类玩法大类：主从调教、多体围攻。选择一类进入，或结束回到安全位置。';
p.narrativeNodes.push({
  id: id('node.defeat.play.hub4'),
  kind: 'defeat',
  stage: 'play-hub-last',
  title: '战败玩法 · 最后',
  textKey: id('text.node.defeat.play.hub4'),
  requiresTags: [scoped('opponent', 'defeat.play.active')],
  excludesTags: [],
  conditions: [],
  tendencies: [],
  weight: 10,
  priority: 6,
  maxVisits: 1,
  choices: [
    playHubChoices[6], // G7
    playHubChoices[7], // G8
    exit(),
  ],
});
action(
  'defeat.play',
  '试跑战败后 8 玩法',
  [{ op: 'narrative.start', kind: 'defeat', profileId: id('profile.defeat.play') }],
  [],
  'fantasy 战败后按 8 玩法大类进入；成人正文须 adultOptional；不改审定',
  'explore',
);

// 回填战败玩法正文（G1–G8 四拍；不装 peakSamplesNotInstalled）
const defeatPlayFillsPath = 'content/nsfw-auto-combo/defeat-play-fills.json';
let defeatPlayFillCount = 0;
try {
  const fills = await json(defeatPlayFillsPath);
  if (fills.format !== 'aetheria-defeat-play-prose-fills' || ![1, 2].includes(fills.schemaVersion)) throw new Error('defeat-play-fills 格式无效。');
  for (const [key, body] of Object.entries(fills.texts ?? {})) {
    if (typeof body !== 'string' || !body.trim()) throw new Error(`战败玩法散文空槽：${key}`);
    if (!(key in p.texts)) throw new Error(`战败玩法散文目标不存在：${key}`);
    p.texts[key] = body;
    defeatPlayFillCount += 1;
  }
} catch (err) {
  if (err && err.code === 'ENOENT') {
    // 无回填时保留占位
  } else {
    throw err;
  }
}
await writeFile(
  'content/nsfw-auto-combo/defeat-play-candidates.json',
  JSON.stringify({
    format: 'aetheria-defeat-play-candidates',
    schemaVersion: 3,
    worldTag: 'worlds:setting.fantasy',
    proseFillsApplied: defeatPlayFillCount,
    entryAction: id('action.defeat.play'),
    hubNodeId: id('node.defeat.play.hub'),
    stageChain: defeatPlayStageChain,
    stageNote: 'G1–G8 实装 capture→press→peak→resolve。escalate/aftermath 已弃用。',
    hubPages: {
      hub: ['G1', 'G2'],
      hub2: ['G3', 'G4'],
      hub3: ['G5', 'G6'],
      hub4: ['G7', 'G8'],
    },
    howToTestRandom: [
      'UI：新开档（不同世界种子）→ 打开「试跑战败后 8 玩法」→ 读 hub 正文中的 {opponent}/{material}/{part}/{tf} 实填。',
      '或 node --test tests/defeat-play.test.ts（含双种子可见填充差异断言）。',
      '控制台：执行 action 后查看 adventure.story.opponentName 与 adventure.story.fills。',
      '同一 transactionId 流固定；换种子或换 transactionId 即重抽。',
    ],
    plays: defeatPlayMeta.map((play) => {
      const g = `g${play.n}`;
      const stages = play.multiBeat ? defeatPlayStageChain : ['capture'];
      const stageMap = {};
      for (const stage of stages) {
        stageMap[stage] = {
          stage: defeatStageId(play.n, stage),
          nodeId: id(`node.defeat.${g}.${stage}`),
          editNodeId: `edit:node.defeat.${g}.${stage}`,
          textKey: id(`text.node.defeat.${g}.${stage}`),
          adultNodeId: id(`node.defeat.${g}.${stage}.adult`),
          editAdultNodeId: `edit:node.defeat.${g}.${stage}.adult`,
          adultTextKey: id(`text.node.defeat.${g}.${stage}.adult`),
        };
      }
      return {
        gameplay: play.key,
        name: play.name,
        multiBeat: play.multiBeat,
        nodeId: id(`node.defeat.${g}.capture`),
        editNodeId: `edit:node.defeat.${g}.capture`,
        adultNodeId: id(`node.defeat.${g}.capture.adult`),
        editAdultNodeId: `edit:node.defeat.${g}.capture.adult`,
        textKey: id(`text.node.defeat.${g}.capture`),
        adultTextKey: id(`text.node.defeat.${g}.capture.adult`),
        stages: stageMap,
      };
    }),
  }, null, 2) + '\n',
);

await writeFile(
  'content/nsfw-auto-combo/defeat-play-draws.json',
  JSON.stringify({
    format: 'aetheria-defeat-play-draws',
    schemaVersion: 1,
    note: '运行时表在 src/engine/defeat-play-draws.ts；本文件供核对 / 文档。定词挂前；goo TF 仅通用原子。',
    opponents: [
      { kind: 'human', label: '人类对手' },
      { kind: 'beast', label: '野兽' },
      { kind: 'monster', label: '异形生物' },
    ],
    materials: [
      { key: 'M1', dingci: '蛞蝓', base: '黏液', label: '蛞蝓黏液' },
      { key: 'M2', dingci: '触手', base: '黏液', label: '触手黏液' },
      { key: 'M3', dingci: '虫巢', base: '黏液', label: '虫巢黏液' },
      { key: 'M4', dingci: '史莱姆', base: '黏液', label: '史莱姆黏液' },
      { key: 'M5', dingci: null, base: '活体黑胶', label: '活体黑胶' },
      { key: 'M6', dingci: null, base: '凝胶膜', label: '凝胶膜' },
    ],
    parts: ['手腕', '腰侧', '脚踝', '大腿内侧', '脖颈', '锁骨窝', '嘴唇'],
    tfs: ['黏液化', '黑胶化'],
    wiredToNsfwAutoCombo: true,
    comboRows: 12,
  }, null, 2) + '\n',
);


// Local scenes use the actual map and residents, including the fixed test city.
for(const [suffix,locationId,name]of [['canal','district:location.canal','旧渠步道'],['station','district:location.station','下城检查站']]){
 const eid=id('event.road-threat.'+suffix),prompt=id('text.road-threat.'+suffix),end=id('text.road-threat.'+suffix+'.end');
 p.texts[prompt]=`你走到${name}的通道拐角，前方传来急促的响动。一个敌对身影挡住了道路，尚未逼到你面前。你可以迎战，也可以沿原路退开。`;
 p.texts[end]='你沿原路退回公共通道，避开了这次冲突。';
 const fight=id('action.road-threat.'+suffix+'.fight'),avoid=id('action.road-threat.'+suffix+'.avoid');
 p.actions.push({id:fight,label:'迎战拦路的对手',hint:'进入战斗；可以防守或撤离',group:'event',context:{eventId:eid,nodeId:'start'},conditions:[],effects:[{op:'event.exit'},{op:'combat.encounter'}],resultText:prompt},
 {id:avoid,label:'沿原路退开，避开冲突',hint:'免费避开；可以继续其他探索',group:'event',context:{eventId:eid,nodeId:'start'},conditions:[],effects:[{op:'event.advance',nodeId:'end'}],resultText:end});
 p.events.push({id:eid,startNode:'start',rating:'general',nodes:[{id:'start',type:'choice',textVariants:[prompt],actionIds:[fight,avoid],onEnter:[]},{id:'end',type:'exit',textVariants:[end],actionIds:[],onEnter:[{op:'event.exit'}]}]});
 (p.storylets??=[]).push({id:id('storylet.road-threat.'+suffix),locationId,conditions:[],eventId:eid,weight:10,priority:2,cooldownMinutes:60,cooldownGroup:'road-threat-'+suffix,repeat:'daily',hidden:true,tags:['foundation:theme.risk']});
}
node('encounter.local','encounter','start','{place}的动静','{period}，你在{place}停下脚步。{nearby}\n\n附近的通道通向{routeNames}。你可以参与眼前的事务，也可以先认识这里的人。',[
 choice('看看当地发生的事','你走向{place}的公共通道。',null,[{op:'world.encounter'}]),
 choice('认识此刻在场的人','你在{place}与在场的人打招呼。',null,[{op:'world.encounter',events:false}]),
],{priority:20,conditions:[{op:'any',conditions:base.flatMap(p=>p.locations).map(l=>({op:'location.is',id:l.id}))}],excludesTags:[scoped('opponent','nsfwcombo.active')]});
p.texts[id('text.node.exploration.start')]='{period}，你沿{place}的通道走了一段。路牌通向{routeNames}。{nearby}';
p.texts[id('text.node.transformation.start')]='你在{place}留出一块空地，慢慢活动身体。你目前的结构包括{bodyState}。{tfState}';
p.contributions[0].actionIds=[...new Set(p.contributions.filter(c=>c.hookId===id('hook.runtime')).flatMap(c=>c.actionIds))].filter(a=>!['action.narrative.quest','action.narrative.ending'].map(id).includes(a));p.contributions=p.contributions.slice(0,1);
// Missing prose is a build error, never an instruction shown inside the game.
for(const n of p.narrativeNodes)for(const k of [n.textKey,...n.choices.map(c=>c.resultText)]){
 const problem=proseProblem(p.texts[k]??'',true);if(problem)throw Error('可玩正文未完成：'+k+'，'+problem);
}
await mkdir('content/adventure',{recursive:true});await writeFile('content/adventure/pack.json',JSON.stringify(p,null,2)+'\n');
console.log(`Adventure content: ${p.narrativeNodes.length} narrative nodes, ${p.narrativeProfiles.length} behavior profiles, ${p.environmentEnemyRules.length} env-enemy rules, ${p.equipment.length} gear items, ${p.items.length} consumables, ${p.enemies.length} enemies, nsfw-combo samples ${nsfwCombos.length}, prose fills ${proseFillCount}, defeat-play fills ${defeatPlayFillCount}.`);

await buildPersonalityContent();

# NSFW 自动组合战败 · 缺口补齐与三车道交付说明

日期：2026-10-16  
基线 SHA：`403e5a5c3c6f651910935bd056648b849e769503`  
规范：`aetheria-install/1`

---

## 0. 三车道交付头（Mechanism / Content / Words）

### 车道 A：`mechanism`（类型、Schema、条件求值、反应规则表、抽样器）

```json
{
  "spec": "aetheria-install/1",
  "lane": "mechanism",
  "base": "403e5a5c3c6f651910935bd056648b849e769503",
  "summary": "实装一等公民 DefeatReactionRule 反应规则表、opponent.matches 精确物种优先级、M1-M10 材质键扩展与 O(1) Tag/Pack 缓存。",
  "status": "checked",
  "files": [
    "src/core/district-types.ts",
    "src/core/adventure-types.ts",
    "src/core/types.ts",
    "src/content/district-schema.ts",
    "src/content/adventure-schema.ts",
    "src/content/foundation-schema.ts",
    "src/content/append-only.ts",
    "src/content/schema.ts",
    "src/content/loader.ts",
    "src/content/registry.ts",
    "src/engine/conditions.ts",
    "src/engine/defeat-play-draws.ts",
    "src/engine/district-effects.ts",
    "src/engine/narrative.ts",
    "src/persistence/codec.ts",
    "src/world/validation.ts"
  ],
  "verify": [
    "NODE_OPTIONS='--loader /tmp/ts-loader.mjs' node scripts/build-adventure-content.mjs",
    "NODE_OPTIONS='--loader /tmp/ts-loader.mjs' node --test tests/defeat-play.test.ts tests/nsfw-auto-combo.test.ts tests/nsfw-b0017-hub.test.ts",
    "NODE_OPTIONS='--loader /tmp/ts-loader.mjs' npm run build && NODE_OPTIONS='--loader /tmp/ts-loader.mjs' node scripts/check-dist.mjs"
  ],
  "notDone": [
    "性暴力轴：矩阵已建格 → 待正文/待封装（T33 同意分轴；G3 ≠ 性暴力已实装）",
    "人兽轴：矩阵已建格 → 待正文/待封装（T34；兽化 ≠ 人兽）",
    "对话色气 / 关系恶堕：无源制作缺口，另包；不塞入本战败机制 PR"
  ]
}
```

### 车道 B：`content`（三结局 `escape` / `marked` / `tf`、独立残迹 Flag、B1/B2 事后链分账、野外六敌藤核/茧维挂载）

```json
{
  "spec": "aetheria-install/1",
  "lane": "content",
  "base": "403e5a5c3c6f651910935bd056648b849e769503",
  "summary": "补齐 G1-G8 独立 resolve.marked 第三结局节点、独立残迹标记 progression:flag.aftermath.mark（与伤势分账）、B1 体表转化与 B2 自主余韵双入口、兽径触手藤 M7/M8/M9 藤核材质与虫巢爬者 M10 丝茧挂载。",
  "status": "checked",
  "files": [
    "scripts/build-adventure-content.mjs",
    "content/adventure/pack.json",
    "content/nsfw-auto-combo/defeat-play-candidates.json",
    "content/nsfw-auto-combo/defeat-play-draws.json",
    "tests/defeat-play.test.ts"
  ],
  "verify": [
    "NODE_OPTIONS='--loader /tmp/ts-loader.mjs' node scripts/build-adventure-content.mjs",
    "NODE_OPTIONS='--loader /tmp/ts-loader.mjs' node --test tests/defeat-play.test.ts"
  ],
  "notDone": [
    "性暴力轴：矩阵已建格 → 待正文/待封装（T33 同意分轴；G3 ≠ 性暴力已实装）",
    "人兽轴：矩阵已建格 → 待正文/待封装（T34；兽化 ≠ 人兽）",
    "对话色气 / 关系恶堕：无源制作缺口，另包；不塞入本战败机制 PR"
  ]
}
```

### 车道 C：`words`（`b0018` 词库批次：E2 藤核、E4 茧维、感官现场态、脚铐/踝铐、M1 窄条对齐）

```json
{
  "spec": "aetheria-install/1",
  "lane": "words",
  "base": "403e5a5c3c6f651910935bd056648b849e769503",
  "summary": "新增 b0018 五个 v1 词库批次（34 条：活藤/缠绕茎/藤条/丝茧/蛞蝓黏液窄条、藤条封眼/藤条封口/结茧/节肢钳制、被茧缚/感官剥夺中/口封中/眼封中/耳封中、脚铐/踝铐等）并通过 v2-draft 语义校验。",
  "status": "checked",
  "files": [
    "docs/tag-hub/nsfw-batches/nsfw-material.b0018.json",
    "docs/tag-hub/nsfw-batches/nsfw-action.b0018.json",
    "docs/tag-hub/nsfw-batches/nsfw-state.b0018.json",
    "docs/tag-hub/nsfw-batches/nsfw-gear.b0018.json",
    "docs/tag-hub/nsfw-batches/nsfw-mod.b0018.json",
    "docs/tag-hub/nsfw-batches/v2-draft/nsfw-material.b0018.v2.json",
    "docs/tag-hub/nsfw-batches/v2-draft/nsfw-action.b0018.v2.json",
    "docs/tag-hub/nsfw-batches/v2-draft/nsfw-state.b0018.v2.json",
    "docs/tag-hub/nsfw-batches/v2-draft/nsfw-gear.b0018.v2.json",
    "docs/tag-hub/nsfw-batches/v2-draft/nsfw-mod.b0018.v2.json",
    "docs/tag-hub/nsfw-batches/v2-draft/MANIFEST.json",
    "scripts/nsfw-auto-combo/atoms.json"
  ],
  "verify": [
    "NODE_OPTIONS='--loader /tmp/ts-loader.mjs' node --test tests/nsfw-b0017-hub.test.ts tests/nsfw-auto-combo.test.ts"
  ],
  "notDone": [
    "b0017 / b0018 词条处于 pending-review（v2-draft 已校验通过，未自动升格为 approved 运行字典）"
  ]
}
```

---

## 1. 对照《给Gemini-还缺什么.md》逐项处理清单

### 1.1 机制缺口（Section 1）—— 已全部补齐

1. **`DefeatReactionRule` 一等公民反应规则表**：
   - 在 `src/core/adventure-types.ts` 定义 `DefeatReactionRule` 接口（包含 `id`, `label`, `stages`, `playerConditions`, `opponentConditions`, `choiceLabel`, `resultText`, `targetStage`, `effects`, `setTags`, `unsetTags`, `priority`），并挂入 `ContentPack`、`Registry.defeatReactionRules`、`parseAdventurePack` 与 `validateAdventureDefinitions`。
   - 在 `src/engine/narrative.ts` 实装 `matchingDefeatReactions(s, r)` 与 `resolveDefeatReactionStage(targetStage, currentStage)`：当战败节点处于匹配阶段（如 `capture` / `press` / `peak`）且剩余选项槽位 `< 4` 时，引擎自动按优先级注入最高优先级的双方属性对偶反应选项（例如玩家有 `tailGrip` 时出现「借机械尾支点撬开束缚」；对阵藤蔓敌人且速度达标时出现「趁活藤收拢间隙滑步脱身」；对阵甲壳虫巢敌人且防御达标时出现「曲肘撑开丝茧留出脱身余地」；玩家已有黏液/黑胶覆层时出现「借体表既有覆层卸开牵制力道」）。
2. **独立战后残迹 Flag `progression:flag.aftermath.mark`（与伤势 `district:flag.injury` 彻底分账）**：
   - 在 `aetheria/adventure` 包中注册 `progression:flag.aftermath.mark`（初始值 `false`）。
   - 所有 G1–G8 战败收束的「带痕脱身 (`resolve.marked`)」与「覆层浸染 (`resolve.tf`)」均只写入 `progression:flag.aftermath.mark = true`，不再污染通用伤势 `district:flag.injury`；「挣脱抽身 (`resolve.escape`)」与「洗净体表异质覆层 (`action.tf.cleanse-coatings`)」清除 `progression:flag.aftermath.mark`。
3. **独立 `resolve.marked` 第三结局节点（`escape` / `marked` / `tf` 三结局完备）**：
   - 为 G1–G8 全部新增 `progression:node.defeat.gN.resolve.marked`（阶段 `play-0N-resolve-marked`，标题 `战败 · <玩法名> · 带痕脱身`）。
   - 玩家在 `resolve`（含普通与成人补充节点）选择「带着残迹退回安全位置」时，进入 `resolve.marked` 专拍节点：描写脱离正面压制但 `{part}` 与衣料内侧仍留有 `{material}` 残迹、尚未立刻引发身体转化的收束演出，并提供「保留体表残迹退回安全处（解锁事后余韵入口）」与「当场拭去表层残迹后离开」两个出口。
4. **B 链产品对齐（B1 体表转化余韵 + B2 自主心性回响双入口分立）**：
   - **B1（体表 TF 余韵）**：`progression:action.residue.trace`（「检视战后体表残迹与转化感应」，由 `progression:flag.aftermath.mark` 解锁），专注处理体表残迹洗净或引导虫巢甲质、共生藤膜、兽化长尾三类身体转化。
   - **B2（自主事后心性回响）**：新增独立入口 `progression:action.aftermath.corruption`（「回味战后余韵与支配回响」，需 `progression:flag.aftermath.mark = true` 且 `preference.adultOptional = true`），进入 `progression:node.transformation.corruption.start`。仅当玩家主动选择「沉入受制余韵，任由顺从与渴望滋长」时才增加 `core:submissionTendency`、`core:desire` 与 `core:aftertaste`；A 链战败本身绝不强制改写心性。
5. **`speciesKind` vs `fills.opponentKind` 求值优先级**：
   - 在 `src/engine/conditions.ts` 的 `opponent.matches` 求值中，明确优先级为：
     `rule?.speciesKind ?? profile?.speciesKind ?? enemy?.speciesKind ?? story?.fills?.opponentKind`
     优先读取权威敌方定义/环境规则的 `speciesKind`（7 细类：`human` / `beast` / `monster` / `plant` / `slime` / `insect` / `construct`），仅在无具名敌人档案时才回退至 `fills.opponentKind`。

---

### 1.2 内容与词条缺口（Section 2）—— 已补齐项与未实装边界

1. **E2 藤核（`活藤` / `缠绕茎` / `藤条` + `藤条封眼` / `藤条封口`）**：
   - 在 `docs/tag-hub/nsfw-batches/nsfw-material.b0018.json` 收录 `lx.nsfw-material.b0018.0001`（`活藤`）、`0002`（`缠绕茎`）、`0003`（`藤条`）；在 `nsfw-action.b0018.json` 收录 `lx.nsfw-action.b0018.0001`（`藤条封眼`）、`0002`（`藤条封口`）、`0005`（`藤蔓吊缚`）。
   - 在 `src/engine/defeat-play-draws.ts` 新增 `M7`（`兽径活藤`）、`M8`（`翠暗缠绕茎`）、`M9`（`柔韧藤条`）。
   - 将野外敌人 `progression:enemy.tentacle-vine`（「兽径触手藤」）的 `defeatCombo.materials` 改为 `['M7', 'M8', 'M9']`，并移除其 `attr.mucus` 标签，彻底杜绝触手藤冒用黏液/凝胶材质 `M2/M6`。
2. **E4 茧维（`结茧` / `被茧缚` / `节肢钳制` / `丝茧`）**：
   - 在 `b0018` 收录 `lx.nsfw-material.b0018.0004`（`丝茧`）、`lx.nsfw-action.b0018.0003`（`结茧`）、`lx.nsfw-action.b0018.0004`（`节肢钳制`）、`lx.nsfw-state.b0018.0001`（`被茧缚`）。
   - 在 `defeat-play-draws.ts` 新增 `M10`（`虫巢丝茧`），并将 `progression:enemy.hive-crawler`（「虫巢爬者」）的 `defeatCombo.materials` 更新为 `['M3', 'M10']`。
3. **感官现场态（≠ kink「感官剥夺」）与运行情境 Tag 加厚**：
   - 在 `nsfw-state.b0018.json` 收录现场态词条：`感官剥夺中`、`口封中`、`眼封中`、`耳封中`、`被藤蔓束缚`、`悬吊受制`、`残迹未消`。
   - 在 `aetheria/adventure` 注册运行态情境 Tag：`progression:tag.state.bound`（束缚状态）、`state.coated`（涂覆状态）、`state.suspended`（悬吊受制）、`state.gagged`（口封中）、`state.blindfolded`（眼封中）、`state.ear-sealed`（耳封中）、`state.sensory-deprived`（感官剥夺中）、`state.cocooned`（被茧缚）、`state.exposed`（衣料敞露），并在战败阶段流转中动态挂载与清理。
4. **M1 命名对齐与 `脚铐` / `踝铐`**：
   - 在 `nsfw-material.b0018.json` 增补窄条 `lx.nsfw-material.b0018.0005`（`蛞蝓黏液`），并在 `scripts/nsfw-auto-combo/atoms.json` 的 `M1` 条目中通过 `narrowId: "lx.nsfw-material.b0018.0005"` 与 `lx.nsfw-material.b0002.0001`（定词「蛞蝓」+主名「黏液」）双向对齐。
   - 在 `nsfw-gear.b0018.json` 增补 `lx.nsfw-gear.b0018.0001`（`脚铐`）、`0002`（`踝铐`）及配套拘束具。

# 本批唯一任务：B1-floating（浮空世界）

此页优先于后附旧配额与阶段口径。只做这一题材/这一任务；已经完成的五题材modern/cyberpunk/fantasy/xianxia/post-apocalypse不重写。

基准commit：eca297ae38e7733e35c31b0124629d94cec2f0a7
交付文件名：B1-floating-delivery.json 与同名.md。format=aetheria-authoring-delivery，specVersion=1.3，task=B1，theme=floating，batchId全局唯一，revision从1起。每批至少3条manual/hypothetical-only手工预览。

数量：environment.prop 25条 + 感官15条，共40条；感官15是所有子池合计，至少覆盖四种通道。

每条requires带scene.setting eq floating，确保题材边界；其它事实需要查询条件。词条不写死人名/地点/实例ID。原稿只用draft/hold；细动作、衣着、位置、容器内物、材质等未知现场事实要hold并填pendingFacts，不能将Tag代替事实。不得自称游戏批准或自动可见。正文general，不扩写成人情节。

本批来源是作者候选；当前游戏已有A54与B945，以及三个观察入口。后附目录中fixture-only事实仍是作者测试合同；生产实际支持以当前适配器为准。不要因旧规范写“尚未接入”而重做引擎或A模板。

解压后可运行 node tools/validate-delivery.mjs 文件.json；附工具只校验作者格式，不保证现场语义或实装。说明填写词条数量、draft/hold分账、每种未知事实、题材辨识与预览所用ID。不得为凑配额重复同义词。

---

# 任务卡 B1 · 道具与感官词池 · v1.3

必需输入：01-通用规范.md、02-词池总表.json、03-示例与手工拼装方法.json、05-Tag参考.json、06-Tag增量规则.md、07-两层格式与转换契约.md、09-事实目录.json。独立发卡全文版已附齐这些内容。

## 任务需求

一人领一个题材。首批modern/cyberpunk/fantasy/xianxia/post-apocalypse各40条environment.prop与25条感官，共每题材65条。感官25条总额分布到smell/sound/light/thermal/touch子池，至少四通道有词，不把每个子池再做25条。第二批其余12题材各25道具+15感官。带旧痕/缺角/位置/湿度的具体词需要对应记录，未知条件标hold，画面感不能靠虚构事实。名词短语应能接进声明池的模板，不写万能从句。通用词可同档500，不按概率百分比分配；真实专用条件才提高优先级。按05相关分组选Tag，缺标签可按06随批提案，但标签不能代替事实。

## 共同约束

统一使用v1.3，正文只做general展示。交作者层JSON与说明，不写运行实例ID、approved、weight、未知字段或玩法效果。已冻结查询可进requires，未知映射标hold并填pendingFacts；hold不计可试拼覆盖。Tag不证明现场事实，按08/05取canonical ID，不注册提案。可互换普通词允许同priority；专用高档带真实条件、通用词低档回退。每条模板至少2个手工预览，每批至少3个，标manual/hypothetical-only并记录ID/fixture/seed/revision。结构、虚构事实、串线、无出口错误零容忍。

## 交付

交付按schemas/delivery.schema.json：format=aetheria-authoring-delivery、specVersion=1.3、task、theme、author、batchId、revision、entries、handPreviews、suggestedTags，notes可选。原稿只收draft/hold。没有运行环境不影响交稿，但只能说手工预览；由整合方执行tools校验。示例批少于正式配额，不冒领任务完成。

说明必须列实际数量、待补事项、未执行检查和外部引用；A/B另列draft/hold分账。不要用目录、指纹或“请查看工程”代替任务所需内容。


# 本任务全部输入正文


## 完整输入文件：01-通用规范.md

# 通用规范 v1.3：作者层词条与模板

本包只生产普通展示文案数据，不能代替游戏功能、事件结果或存档实现。写手无需完整工程；整合方使用07转换契约和工具做离线核查。默认以本版规范、词池表、事实目录和完整样例为准，旧1.0/1.2交付先转换再审，不混收不同字段格式。

## 八槽与绑定

冻结 place / propEnv / bodyPart / senseMod / actionCore / materialFluid / opponentForm / exitChoice，不新增姓名、气味或定词槽。词条一槽一制作池；模板可重复出现同一种槽，但每个key唯一。place.current、actor.name、exit.current由适配器填充，作者不交这些词。姓名读取已保存的精确对象快照，不重新拼姓/名、随机改名或由正文推定家族。

02列出所有制作池、主体类型、角色与逻辑绑定键。逻辑键place/actor/part/prop/material/sense/exit不是真实ID；整合时必须绑定到唯一实际实例。part的subject是部件所有者、instanceId是部件实例，不能将不同部件的材质混用。

## 词条完整字段

每条按schemas/word.schema.json提交：id、text、allowedSlots、poolIds、priority、review、status、role、binding、requires、pendingFacts、excludes、exclusive、contentTier、tagIds。不是“12字段”，不省略空数组。

- id用word开头的小写稳定ID；text为可入槽短语，通常1–40字，必要时最长80字；不要用长从句逃避槽位约束。动作池可用动词短语，其他池以匹配语法的短语为准。
- review只允许draft或hold。draft是字段、已冻结查询引用已自检的稿，不代表事实在当前场景成立、更不代表批准。hold必须在pendingFacts中列出尚未映射的语义前置；不得猜造事实名或删条件硬交。
- draft至少有一个事实前置、pendingFacts为空；hold可以没有requires，但pendingFacts不得为空。status为active/inactive，inactive不参与试拼。
- binding只写subjectType；作者不写subject/instanceId。requires只能用09登记的事实键，eq/gte/lte/exists四种比较。exists没有value；其他操作必须提供对应类型的value。未知查询走hold，已支持查询在某次场景未知/不成立时正常不入候选。
- exclusive始终是[{group,value}]数组。同一主体的同一实例同组异值冲突；不同实例的温度不同不冲突。excludes为稳定词条ID列表，任一方向声明均生效；交付时缺失的目标ID须在说明中列为外部依赖，不拼写不存在的ID。
- qualifier仅用于materialFluid，不带末尾“的”；连接符在模板qualifierPlan声明。
- contentTier在本包固定general；tagIds可为空，只用05或08中已登记且active的canonical ID。Tag登记不证明天气、姿态、道具、能力或意愿。
- 编辑备注写交付说明或批次notes，不往词条塞note/notes/weight/效果/代码字段。

09中的查询映射目前只在中性演示快照中可复现，生产游戏适配器尚未接入。使用这些键的draft最多证明作者层查询引用合法，不能计为已上线覆盖；其他事实先hold。未来生产查询加入09时须说明值类型、实例范围、真实来源和已实现状态。

## 选择机制与多样性

当前离线拼装器按priority降序，同优先级按seed+规则ID+槽key+词条ID的稳定散列排序，最后ID兜底；每槽取前4候选，最多64次有限搜索，上限配置8/128。没有weight字段，没有概率加权，也不保证所有低优先级候选最终出场。

可互换的普通词建议同档500，便于同seed稳定、换seed变化；不强迫每批分带。专用词若应覆盖通用词，采用较高priority且真实条件严格成立，通用回退词放较低档。给低档词加条件不会让无条件高档词消失。优先级不能代替资格；tagIds也不能代替事实前置。模板轮换需整合方另做确定性选择和存档复现，现有assembleProse只执行指定规则。

## 模板完整字段

按schemas/template.schema.json交id/domain/mode/contentTier/fallbackTier/proseTemplate/qualifierPlan/prose。九类domain为01–09。mode为prose；contentTier及fallbackTier均为general。

每个token含key/slot/poolId/bindTo/required/prefix/suffix，可用sameAs、subjectAs。sameAs要求主体及实例完全相同；subjectAs只要求同一主体。部件属于人物需subjectAs，材质属于该部件需sameAs；容器包含材料的关系需明确事实，不能用sameAs冒充。

prefix/suffix只用不含未验证状态的连接文字和标点。不得写“角落里”“袖口”“比昨天不同”“还没散去”“比记忆中更小”等常量。感官通用池只配“你察觉到”等通道中性的骨架；“空气里飘着”只能用于smell专池，不用于声音、光线、温度或触感。

qualifierPlan是作者层挂前意图，不是运行prefixPools。每项{key,poolId,required,separator}指定材料token；顺序即挂前顺序。body.material只配body.material.qualifier，material.current只配material.qualifier；必须绑定同一实例。最多两组，禁止同一key重复挂同池。separator为空或“的”；没有plan就不挂定词，整合者不得自行猜。07负责机械转换。

每条模板必须有required=true的exitChoice槽。可选槽无词时连连接文字/标点一起删除。prose为完整普通回退，建议“你可以结束观察，继续自己的安排。”；不声称已离开、已完成动作、无人有事或没有变化。回退不能凭空创建按钮，适配器未提供真实免费出口时应blocked。

## 交付与自检

使用schemas/delivery.schema.json，顶层format/specVersion/task/theme/author/batchId/revision/entries/handPreviews/suggestedTags，notes可选。specVersion固定1.3，主题用02的17项或generic。任务卡要求的配额以02的quotas为准，hold数量与可试拼数量分开，别把hold包装成已完成可用覆盖。

每条模板至少2条预览，每批至少3条；P0仅需2条。handPreviews是对象，含templateId、entryIds、fixtureId、seed、revision、mode、text、evidenceStatus。手工填写用manual/hypothetical-only；实际运行参考拼装器并附复跑记录，才能用reference-assembler/fixture-verified。本包03的示例由真实离线工具生成并测试，所以使用后者，仍不表示游戏接入。未有真实上下文时说明假设，不能宣称已复现。人工轮换低档词只能用于语感检查，不伪称引擎自然会选中。

提交前检查：Schema与版本、ID冲突、词池/槽/主体、事实来源与hold、同实例互斥、连接语法、定词挂前、动态名称、真实免费出口、完整普通回退。结构/串线/虚构事实/分级错误零容忍；文字画面感由人工审核，机器不能从自然语言自动证明事实完整。


## 完整输入文件：02-词池总表.json

~~~json
{
  "specVersion": "1.3",
  "slots": [
    "place",
    "propEnv",
    "bodyPart",
    "senseMod",
    "actionCore",
    "materialFluid",
    "opponentForm",
    "exitChoice"
  ],
  "themes": {
    "list": [
      "modern",
      "cyberpunk",
      "steampunk",
      "fantasy",
      "xianxia",
      "desert",
      "polar",
      "volcanic",
      "jungle",
      "underground",
      "underwater",
      "floating",
      "harbor",
      "western",
      "dungeon",
      "space-station",
      "post-apocalypse"
    ],
    "mvpOrder": [
      "modern",
      "cyberpunk",
      "fantasy",
      "xianxia",
      "post-apocalypse"
    ]
  },
  "bindingRoles": {
    "place": "location",
    "actor": "person",
    "part": "part",
    "prop": "object",
    "material": "object",
    "sense": "location",
    "exit": "event"
  },
  "pools": [
    {
      "id": "place.current",
      "slot": "place",
      "subjectType": "location",
      "role": "core",
      "authoringTarget": false,
      "contentTier": "general"
    },
    {
      "id": "actor.name",
      "slot": "opponentForm",
      "subjectType": "person",
      "role": "core",
      "authoringTarget": false,
      "contentTier": "general"
    },
    {
      "id": "exit.current",
      "slot": "exitChoice",
      "subjectType": "event",
      "role": "core",
      "authoringTarget": false,
      "contentTier": "general"
    },
    {
      "id": "environment.prop",
      "slot": "propEnv",
      "subjectType": "object",
      "role": "core",
      "authoringTarget": true,
      "contentTier": "general"
    },
    {
      "id": "environment.sense",
      "slot": "senseMod",
      "subjectType": "location",
      "role": "core",
      "authoringTarget": true,
      "contentTier": "general",
      "grammar": "名词短语；仅配“你察觉到”等通用感知连接词；不假定具体感官通道。"
    },
    {
      "id": "environment.sense.smell",
      "slot": "senseMod",
      "subjectType": "location",
      "role": "core",
      "authoringTarget": true,
      "contentTier": "general",
      "channel": "smell",
      "runtimeAlsoIn": [
        "environment.sense"
      ]
    },
    {
      "id": "environment.sense.sound",
      "slot": "senseMod",
      "subjectType": "location",
      "role": "core",
      "authoringTarget": true,
      "contentTier": "general",
      "channel": "sound",
      "runtimeAlsoIn": [
        "environment.sense"
      ]
    },
    {
      "id": "environment.sense.light",
      "slot": "senseMod",
      "subjectType": "location",
      "role": "core",
      "authoringTarget": true,
      "contentTier": "general",
      "channel": "light",
      "runtimeAlsoIn": [
        "environment.sense"
      ]
    },
    {
      "id": "environment.sense.thermal",
      "slot": "senseMod",
      "subjectType": "location",
      "role": "core",
      "authoringTarget": true,
      "contentTier": "general",
      "channel": "thermal",
      "runtimeAlsoIn": [
        "environment.sense"
      ]
    },
    {
      "id": "environment.sense.touch",
      "slot": "senseMod",
      "subjectType": "location",
      "role": "core",
      "authoringTarget": true,
      "contentTier": "general",
      "channel": "touch",
      "runtimeAlsoIn": [
        "environment.sense"
      ]
    },
    {
      "id": "actor.form",
      "slot": "opponentForm",
      "subjectType": "person",
      "role": "core",
      "authoringTarget": true,
      "contentTier": "general"
    },
    {
      "id": "action.observed",
      "slot": "actionCore",
      "subjectType": "person",
      "role": "core",
      "authoringTarget": true,
      "contentTier": "general"
    },
    {
      "id": "actor.bodyPart",
      "slot": "bodyPart",
      "subjectType": "part",
      "role": "core",
      "authoringTarget": true,
      "contentTier": "general"
    },
    {
      "id": "body.material",
      "slot": "materialFluid",
      "subjectType": "part",
      "role": "core",
      "authoringTarget": true,
      "contentTier": "general"
    },
    {
      "id": "body.material.qualifier",
      "slot": "materialFluid",
      "subjectType": "part",
      "role": "qualifier",
      "authoringTarget": true,
      "contentTier": "general"
    },
    {
      "id": "material.current",
      "slot": "materialFluid",
      "subjectType": "object",
      "role": "core",
      "authoringTarget": true,
      "contentTier": "general"
    },
    {
      "id": "material.qualifier",
      "slot": "materialFluid",
      "subjectType": "object",
      "role": "qualifier",
      "authoringTarget": true,
      "contentTier": "general"
    }
  ],
  "quotas": {
    "templates": {
      "A1": {
        "01": [
          6,
          8
        ],
        "03": [
          6,
          8
        ],
        "05": [
          6,
          8
        ]
      },
      "A2": {
        "02": [
          6,
          8
        ],
        "04": [
          6,
          8
        ],
        "06": [
          6,
          8
        ],
        "07": [
          6,
          8
        ],
        "09": [
          6,
          8
        ]
      },
      "A3": {
        "08": [
          6,
          8
        ]
      }
    },
    "mvpThemes": [
      "modern",
      "cyberpunk",
      "fantasy",
      "xianxia",
      "post-apocalypse"
    ],
    "firstBatch": {
      "B1": {
        "environment.prop": 40,
        "environment.sense.*": 25
      },
      "B2": {
        "actor.form": 30,
        "action.observed": 40
      }
    },
    "secondBatch": {
      "B1": {
        "environment.prop": 25,
        "environment.sense.*": 15
      },
      "B2": {
        "actor.form": 20,
        "action.observed": 25
      }
    },
    "generic": {
      "B3": {
        "actor.bodyPart": 40,
        "body.material": 15,
        "body.material.qualifier": 30,
        "material.current": 20,
        "material.qualifier": 30
      }
    },
    "totals": {
      "templates": [
        54,
        72
      ],
      "words": 810
    }
  },
  "selection": {
    "strategy": "priority-desc-then-seeded-hash-then-id",
    "samePriorityAllowed": true,
    "weightFieldSupported": false,
    "maxCandidatesPerSlot": 4,
    "maxSteps": 64,
    "templateSelectionImplemented": false,
    "source": "tools/runtime/assembly.mjs"
  }
}

~~~


## 完整输入文件：03-示例与手工拼装方法.json

~~~json
{
  "format": "aetheria-authoring-examples",
  "specVersion": "1.3",
  "fixtureOnly": true,
  "templates": [
    {
      "id": "assembly.05.demo.observation",
      "domain": "05",
      "mode": "prose",
      "contentTier": "general",
      "fallbackTier": "general",
      "proseTemplate": [
        {
          "key": "where",
          "slot": "place",
          "poolId": "place.current",
          "bindTo": "place",
          "required": true,
          "prefix": "在",
          "suffix": "，"
        },
        {
          "key": "actor",
          "slot": "opponentForm",
          "poolId": "actor.name",
          "bindTo": "actor",
          "required": true,
          "prefix": "你留意到",
          "suffix": ""
        },
        {
          "key": "part",
          "slot": "bodyPart",
          "poolId": "actor.bodyPart",
          "bindTo": "part",
          "required": true,
          "prefix": "的",
          "suffix": "。",
          "subjectAs": [
            "actor"
          ]
        },
        {
          "key": "act",
          "slot": "actionCore",
          "poolId": "action.observed",
          "bindTo": "actor",
          "required": true,
          "prefix": "对方",
          "suffix": "。"
        },
        {
          "key": "prop",
          "slot": "propEnv",
          "poolId": "environment.prop",
          "bindTo": "prop",
          "required": true,
          "prefix": "你注意到",
          "suffix": "，"
        },
        {
          "key": "material",
          "slot": "materialFluid",
          "poolId": "material.current",
          "bindTo": "material",
          "required": true,
          "prefix": "其中盛着",
          "suffix": "。"
        },
        {
          "key": "sense",
          "slot": "senseMod",
          "poolId": "environment.sense",
          "bindTo": "sense",
          "required": false,
          "prefix": "你察觉到",
          "suffix": "。"
        },
        {
          "key": "exit",
          "slot": "exitChoice",
          "poolId": "exit.current",
          "bindTo": "exit",
          "required": true,
          "prefix": "你可以",
          "suffix": "。"
        }
      ],
      "qualifierPlan": [
        {
          "key": "material",
          "poolId": "material.qualifier",
          "required": false,
          "separator": ""
        }
      ],
      "prose": "你可以结束观察，继续自己的安排。"
    },
    {
      "id": "assembly.08.demo.body",
      "domain": "08",
      "mode": "prose",
      "contentTier": "general",
      "fallbackTier": "general",
      "proseTemplate": [
        {
          "key": "actor",
          "slot": "opponentForm",
          "poolId": "actor.name",
          "bindTo": "actor",
          "required": true,
          "prefix": "你留意到",
          "suffix": ""
        },
        {
          "key": "part",
          "slot": "bodyPart",
          "poolId": "actor.bodyPart",
          "bindTo": "part",
          "required": true,
          "prefix": "的",
          "suffix": "。",
          "subjectAs": [
            "actor"
          ]
        },
        {
          "key": "material",
          "slot": "materialFluid",
          "poolId": "body.material",
          "bindTo": "part",
          "required": true,
          "prefix": "该部件的表面呈现",
          "suffix": "质感。",
          "sameAs": [
            "part"
          ]
        },
        {
          "key": "exit",
          "slot": "exitChoice",
          "poolId": "exit.current",
          "bindTo": "exit",
          "required": true,
          "prefix": "你可以",
          "suffix": "。"
        }
      ],
      "qualifierPlan": [
        {
          "key": "material",
          "poolId": "body.material.qualifier",
          "required": false,
          "separator": "的"
        }
      ],
      "prose": "你可以结束观察，继续自己的安排。"
    },
    {
      "id": "assembly.05.demo.sense",
      "domain": "05",
      "mode": "prose",
      "contentTier": "general",
      "fallbackTier": "general",
      "proseTemplate": [
        {
          "key": "where",
          "slot": "place",
          "poolId": "place.current",
          "bindTo": "place",
          "required": true,
          "prefix": "在",
          "suffix": "，"
        },
        {
          "key": "sense",
          "slot": "senseMod",
          "poolId": "environment.sense",
          "bindTo": "sense",
          "required": false,
          "prefix": "你察觉到",
          "suffix": "。"
        },
        {
          "key": "exit",
          "slot": "exitChoice",
          "poolId": "exit.current",
          "bindTo": "exit",
          "required": true,
          "prefix": "你可以",
          "suffix": "。"
        }
      ],
      "qualifierPlan": [],
      "prose": "你可以结束观察，继续自己的安排。"
    }
  ],
  "lexemes": [
    {
      "id": "word.part.generic.hand",
      "text": "手",
      "allowedSlots": [
        "bodyPart"
      ],
      "poolIds": [
        "actor.bodyPart"
      ],
      "priority": 500,
      "review": "draft",
      "status": "active",
      "role": "core",
      "binding": {
        "subjectType": "part"
      },
      "requires": [
        {
          "fact": "part.kind",
          "comparison": "eq",
          "value": "hand"
        },
        {
          "fact": "actor.present",
          "comparison": "eq",
          "value": true
        }
      ],
      "pendingFacts": [],
      "excludes": [],
      "exclusive": [],
      "contentTier": "general",
      "tagIds": []
    },
    {
      "id": "word.prop.generic.cup",
      "text": "一只量杯",
      "allowedSlots": [
        "propEnv"
      ],
      "poolIds": [
        "environment.prop"
      ],
      "priority": 500,
      "review": "draft",
      "status": "active",
      "role": "core",
      "binding": {
        "subjectType": "object"
      },
      "requires": [
        {
          "fact": "prop.kind",
          "comparison": "eq",
          "value": "measuring-cup"
        }
      ],
      "pendingFacts": [],
      "excludes": [],
      "exclusive": [],
      "contentTier": "general",
      "tagIds": []
    },
    {
      "id": "word.action.generic.return-tools",
      "text": "将工具放回原处",
      "allowedSlots": [
        "actionCore"
      ],
      "poolIds": [
        "action.observed"
      ],
      "priority": 500,
      "review": "draft",
      "status": "active",
      "role": "core",
      "binding": {
        "subjectType": "person"
      },
      "requires": [
        {
          "fact": "actor.present",
          "comparison": "eq",
          "value": true
        },
        {
          "fact": "action.observed",
          "comparison": "eq",
          "value": "tool-returned"
        }
      ],
      "pendingFacts": [],
      "excludes": [],
      "exclusive": [],
      "contentTier": "general",
      "tagIds": []
    },
    {
      "id": "word.action.generic.store-tools",
      "text": "把工具归回原位",
      "allowedSlots": [
        "actionCore"
      ],
      "poolIds": [
        "action.observed"
      ],
      "priority": 500,
      "review": "draft",
      "status": "active",
      "role": "core",
      "binding": {
        "subjectType": "person"
      },
      "requires": [
        {
          "fact": "actor.present",
          "comparison": "eq",
          "value": true
        },
        {
          "fact": "action.observed",
          "comparison": "eq",
          "value": "tool-returned"
        }
      ],
      "pendingFacts": [],
      "excludes": [],
      "exclusive": [],
      "contentTier": "general",
      "tagIds": []
    },
    {
      "id": "word.sense.generic.herbal",
      "text": "草木的清香",
      "allowedSlots": [
        "senseMod"
      ],
      "poolIds": [
        "environment.sense.smell"
      ],
      "priority": 500,
      "review": "draft",
      "status": "active",
      "role": "core",
      "binding": {
        "subjectType": "location"
      },
      "requires": [
        {
          "fact": "sense.available",
          "comparison": "eq",
          "value": true
        },
        {
          "fact": "sense.channel",
          "comparison": "eq",
          "value": "smell"
        },
        {
          "fact": "sense.sample",
          "comparison": "eq",
          "value": "herbal"
        }
      ],
      "pendingFacts": [],
      "excludes": [],
      "exclusive": [],
      "contentTier": "general",
      "tagIds": []
    },
    {
      "id": "word.material.generic.water",
      "text": "水",
      "allowedSlots": [
        "materialFluid"
      ],
      "poolIds": [
        "material.current"
      ],
      "priority": 500,
      "review": "draft",
      "status": "active",
      "role": "core",
      "binding": {
        "subjectType": "object"
      },
      "requires": [
        {
          "fact": "material.kind",
          "comparison": "eq",
          "value": "water"
        },
        {
          "fact": "prop.contains",
          "comparison": "eq",
          "value": "water-1"
        }
      ],
      "pendingFacts": [],
      "excludes": [],
      "exclusive": [],
      "contentTier": "general",
      "tagIds": []
    },
    {
      "id": "word.qualifier.generic.filtered",
      "text": "过滤",
      "allowedSlots": [
        "materialFluid"
      ],
      "poolIds": [
        "material.qualifier"
      ],
      "priority": 500,
      "review": "draft",
      "status": "active",
      "role": "qualifier",
      "binding": {
        "subjectType": "object"
      },
      "requires": [
        {
          "fact": "water.filtered",
          "comparison": "eq",
          "value": true
        }
      ],
      "pendingFacts": [],
      "excludes": [],
      "exclusive": [],
      "contentTier": "general",
      "tagIds": []
    },
    {
      "id": "word.material.generic.brass",
      "text": "黄铜",
      "allowedSlots": [
        "materialFluid"
      ],
      "poolIds": [
        "body.material"
      ],
      "priority": 500,
      "review": "draft",
      "status": "active",
      "role": "core",
      "binding": {
        "subjectType": "part"
      },
      "requires": [
        {
          "fact": "part.material",
          "comparison": "eq",
          "value": "brass"
        }
      ],
      "pendingFacts": [],
      "excludes": [],
      "exclusive": [],
      "contentTier": "general",
      "tagIds": []
    },
    {
      "id": "word.qualifier.generic.fine-grain",
      "text": "带细纹",
      "allowedSlots": [
        "materialFluid"
      ],
      "poolIds": [
        "body.material.qualifier"
      ],
      "priority": 500,
      "review": "draft",
      "status": "active",
      "role": "qualifier",
      "binding": {
        "subjectType": "part"
      },
      "requires": [
        {
          "fact": "part.finish",
          "comparison": "eq",
          "value": "fine-grain"
        }
      ],
      "pendingFacts": [],
      "excludes": [],
      "exclusive": [],
      "contentTier": "general",
      "tagIds": []
    },
    {
      "id": "word.form.modern.doorframe",
      "text": "靠在门框上的短发人物",
      "allowedSlots": [
        "opponentForm"
      ],
      "poolIds": [
        "actor.form"
      ],
      "priority": 500,
      "review": "hold",
      "status": "active",
      "role": "core",
      "binding": {
        "subjectType": "person"
      },
      "requires": [],
      "pendingFacts": [
        "确认同一人物正倚靠真实门框，且短发特征已知。"
      ],
      "excludes": [],
      "exclusive": [],
      "contentTier": "general",
      "tagIds": []
    },
    {
      "id": "word.action.modern.ticket-rub",
      "text": "用拇指反复蹭着票据边缘",
      "allowedSlots": [
        "actionCore"
      ],
      "poolIds": [
        "action.observed"
      ],
      "priority": 500,
      "review": "hold",
      "status": "active",
      "role": "core",
      "binding": {
        "subjectType": "person"
      },
      "requires": [],
      "pendingFacts": [
        "确认该人物有适用部件、持有真实票据，且正在做该动作。"
      ],
      "excludes": [],
      "exclusive": [],
      "contentTier": "general",
      "tagIds": []
    },
    {
      "id": "word.part.generic.open-palm",
      "text": "摊开的手掌",
      "allowedSlots": [
        "bodyPart"
      ],
      "poolIds": [
        "actor.bodyPart"
      ],
      "priority": 500,
      "review": "hold",
      "status": "active",
      "role": "core",
      "binding": {
        "subjectType": "part"
      },
      "requires": [],
      "pendingFacts": [
        "确认该部件有对应手掌结构且处于张开姿态，不能仅凭hand kind推断。"
      ],
      "excludes": [],
      "exclusive": [],
      "contentTier": "general",
      "tagIds": []
    }
  ],
  "deliveries": [
    {
      "format": "aetheria-authoring-delivery",
      "specVersion": "1.3",
      "task": "A1",
      "theme": "generic",
      "author": "协作包中性参考稿",
      "batchId": "demo-a1",
      "revision": 1,
      "entries": [
        {
          "id": "assembly.05.demo.observation",
          "domain": "05",
          "mode": "prose",
          "contentTier": "general",
          "fallbackTier": "general",
          "proseTemplate": [
            {
              "key": "where",
              "slot": "place",
              "poolId": "place.current",
              "bindTo": "place",
              "required": true,
              "prefix": "在",
              "suffix": "，"
            },
            {
              "key": "actor",
              "slot": "opponentForm",
              "poolId": "actor.name",
              "bindTo": "actor",
              "required": true,
              "prefix": "你留意到",
              "suffix": ""
            },
            {
              "key": "part",
              "slot": "bodyPart",
              "poolId": "actor.bodyPart",
              "bindTo": "part",
              "required": true,
              "prefix": "的",
              "suffix": "。",
              "subjectAs": [
                "actor"
              ]
            },
            {
              "key": "act",
              "slot": "actionCore",
              "poolId": "action.observed",
              "bindTo": "actor",
              "required": true,
              "prefix": "对方",
              "suffix": "。"
            },
            {
              "key": "prop",
              "slot": "propEnv",
              "poolId": "environment.prop",
              "bindTo": "prop",
              "required": true,
              "prefix": "你注意到",
              "suffix": "，"
            },
            {
              "key": "material",
              "slot": "materialFluid",
              "poolId": "material.current",
              "bindTo": "material",
              "required": true,
              "prefix": "其中盛着",
              "suffix": "。"
            },
            {
              "key": "sense",
              "slot": "senseMod",
              "poolId": "environment.sense",
              "bindTo": "sense",
              "required": false,
              "prefix": "你察觉到",
              "suffix": "。"
            },
            {
              "key": "exit",
              "slot": "exitChoice",
              "poolId": "exit.current",
              "bindTo": "exit",
              "required": true,
              "prefix": "你可以",
              "suffix": "。"
            }
          ],
          "qualifierPlan": [
            {
              "key": "material",
              "poolId": "material.qualifier",
              "required": false,
              "separator": ""
            }
          ],
          "prose": "你可以结束观察，继续自己的安排。"
        },
        {
          "id": "assembly.05.demo.sense",
          "domain": "05",
          "mode": "prose",
          "contentTier": "general",
          "fallbackTier": "general",
          "proseTemplate": [
            {
              "key": "where",
              "slot": "place",
              "poolId": "place.current",
              "bindTo": "place",
              "required": true,
              "prefix": "在",
              "suffix": "，"
            },
            {
              "key": "sense",
              "slot": "senseMod",
              "poolId": "environment.sense",
              "bindTo": "sense",
              "required": false,
              "prefix": "你察觉到",
              "suffix": "。"
            },
            {
              "key": "exit",
              "slot": "exitChoice",
              "poolId": "exit.current",
              "bindTo": "exit",
              "required": true,
              "prefix": "你可以",
              "suffix": "。"
            }
          ],
          "qualifierPlan": [],
          "prose": "你可以结束观察，继续自己的安排。"
        }
      ],
      "handPreviews": [
        {
          "templateId": "assembly.05.demo.observation",
          "entryIds": [
            "runtime:display.place",
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.action.generic.store-tools",
            "word.prop.generic.cup",
            "word.qualifier.generic.filtered",
            "word.material.generic.water",
            "word.sense.generic.herbal",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 7,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "在工坊，你留意到阿洛·灰谷的手。对方把工具归回原位。你注意到一只量杯，其中盛着过滤水。你察觉到草木的清香。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        },
        {
          "templateId": "assembly.05.demo.observation",
          "entryIds": [
            "runtime:display.place",
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.action.generic.return-tools",
            "word.prop.generic.cup",
            "word.qualifier.generic.filtered",
            "word.material.generic.water",
            "word.sense.generic.herbal",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 8,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "在工坊，你留意到阿洛·灰谷的手。对方将工具放回原处。你注意到一只量杯，其中盛着过滤水。你察觉到草木的清香。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        },
        {
          "templateId": "assembly.05.demo.sense",
          "entryIds": [
            "runtime:display.place",
            "word.sense.generic.herbal",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 7,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "在工坊，你察觉到草木的清香。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        },
        {
          "templateId": "assembly.05.demo.sense",
          "entryIds": [
            "runtime:display.place",
            "word.sense.generic.herbal",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 8,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "在工坊，你察觉到草木的清香。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        }
      ],
      "suggestedTags": [],
      "notes": "演示批，未达到正式任务配额；只有离线测试用途。"
    },
    {
      "format": "aetheria-authoring-delivery",
      "specVersion": "1.3",
      "task": "A3",
      "theme": "generic",
      "author": "协作包中性参考稿",
      "batchId": "demo-a3",
      "revision": 1,
      "entries": [
        {
          "id": "assembly.08.demo.body",
          "domain": "08",
          "mode": "prose",
          "contentTier": "general",
          "fallbackTier": "general",
          "proseTemplate": [
            {
              "key": "actor",
              "slot": "opponentForm",
              "poolId": "actor.name",
              "bindTo": "actor",
              "required": true,
              "prefix": "你留意到",
              "suffix": ""
            },
            {
              "key": "part",
              "slot": "bodyPart",
              "poolId": "actor.bodyPart",
              "bindTo": "part",
              "required": true,
              "prefix": "的",
              "suffix": "。",
              "subjectAs": [
                "actor"
              ]
            },
            {
              "key": "material",
              "slot": "materialFluid",
              "poolId": "body.material",
              "bindTo": "part",
              "required": true,
              "prefix": "该部件的表面呈现",
              "suffix": "质感。",
              "sameAs": [
                "part"
              ]
            },
            {
              "key": "exit",
              "slot": "exitChoice",
              "poolId": "exit.current",
              "bindTo": "exit",
              "required": true,
              "prefix": "你可以",
              "suffix": "。"
            }
          ],
          "qualifierPlan": [
            {
              "key": "material",
              "poolId": "body.material.qualifier",
              "required": false,
              "separator": "的"
            }
          ],
          "prose": "你可以结束观察，继续自己的安排。"
        }
      ],
      "handPreviews": [
        {
          "templateId": "assembly.08.demo.body",
          "entryIds": [
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.qualifier.generic.fine-grain",
            "word.material.generic.brass",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 7,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "你留意到阿洛·灰谷的手。该部件的表面呈现带细纹的黄铜质感。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        },
        {
          "templateId": "assembly.08.demo.body",
          "entryIds": [
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.qualifier.generic.fine-grain",
            "word.material.generic.brass",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 8,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "你留意到阿洛·灰谷的手。该部件的表面呈现带细纹的黄铜质感。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        },
        {
          "templateId": "assembly.08.demo.body",
          "entryIds": [
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.qualifier.generic.fine-grain",
            "word.material.generic.brass",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 9,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "你留意到阿洛·灰谷的手。该部件的表面呈现带细纹的黄铜质感。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        }
      ],
      "suggestedTags": [],
      "notes": "演示批，未达到正式任务配额；只有离线测试用途。"
    },
    {
      "format": "aetheria-authoring-delivery",
      "specVersion": "1.3",
      "task": "B1",
      "theme": "generic",
      "author": "协作包中性参考稿",
      "batchId": "demo-b1",
      "revision": 1,
      "entries": [
        {
          "id": "word.prop.generic.cup",
          "text": "一只量杯",
          "allowedSlots": [
            "propEnv"
          ],
          "poolIds": [
            "environment.prop"
          ],
          "priority": 500,
          "review": "draft",
          "status": "active",
          "role": "core",
          "binding": {
            "subjectType": "object"
          },
          "requires": [
            {
              "fact": "prop.kind",
              "comparison": "eq",
              "value": "measuring-cup"
            }
          ],
          "pendingFacts": [],
          "excludes": [],
          "exclusive": [],
          "contentTier": "general",
          "tagIds": []
        },
        {
          "id": "word.sense.generic.herbal",
          "text": "草木的清香",
          "allowedSlots": [
            "senseMod"
          ],
          "poolIds": [
            "environment.sense.smell"
          ],
          "priority": 500,
          "review": "draft",
          "status": "active",
          "role": "core",
          "binding": {
            "subjectType": "location"
          },
          "requires": [
            {
              "fact": "sense.available",
              "comparison": "eq",
              "value": true
            },
            {
              "fact": "sense.channel",
              "comparison": "eq",
              "value": "smell"
            },
            {
              "fact": "sense.sample",
              "comparison": "eq",
              "value": "herbal"
            }
          ],
          "pendingFacts": [],
          "excludes": [],
          "exclusive": [],
          "contentTier": "general",
          "tagIds": []
        }
      ],
      "handPreviews": [
        {
          "templateId": "assembly.05.demo.observation",
          "entryIds": [
            "runtime:display.place",
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.action.generic.store-tools",
            "word.prop.generic.cup",
            "word.qualifier.generic.filtered",
            "word.material.generic.water",
            "word.sense.generic.herbal",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 7,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "在工坊，你留意到阿洛·灰谷的手。对方把工具归回原位。你注意到一只量杯，其中盛着过滤水。你察觉到草木的清香。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        },
        {
          "templateId": "assembly.05.demo.observation",
          "entryIds": [
            "runtime:display.place",
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.action.generic.return-tools",
            "word.prop.generic.cup",
            "word.qualifier.generic.filtered",
            "word.material.generic.water",
            "word.sense.generic.herbal",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 8,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "在工坊，你留意到阿洛·灰谷的手。对方将工具放回原处。你注意到一只量杯，其中盛着过滤水。你察觉到草木的清香。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        },
        {
          "templateId": "assembly.05.demo.observation",
          "entryIds": [
            "runtime:display.place",
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.action.generic.return-tools",
            "word.prop.generic.cup",
            "word.qualifier.generic.filtered",
            "word.material.generic.water",
            "word.sense.generic.herbal",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 9,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "在工坊，你留意到阿洛·灰谷的手。对方将工具放回原处。你注意到一只量杯，其中盛着过滤水。你察觉到草木的清香。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        }
      ],
      "suggestedTags": [],
      "notes": "演示批，未达到正式任务配额；只有离线测试用途。"
    },
    {
      "format": "aetheria-authoring-delivery",
      "specVersion": "1.3",
      "task": "B2",
      "theme": "generic",
      "author": "协作包中性参考稿",
      "batchId": "demo-b2",
      "revision": 1,
      "entries": [
        {
          "id": "word.action.generic.return-tools",
          "text": "将工具放回原处",
          "allowedSlots": [
            "actionCore"
          ],
          "poolIds": [
            "action.observed"
          ],
          "priority": 500,
          "review": "draft",
          "status": "active",
          "role": "core",
          "binding": {
            "subjectType": "person"
          },
          "requires": [
            {
              "fact": "actor.present",
              "comparison": "eq",
              "value": true
            },
            {
              "fact": "action.observed",
              "comparison": "eq",
              "value": "tool-returned"
            }
          ],
          "pendingFacts": [],
          "excludes": [],
          "exclusive": [],
          "contentTier": "general",
          "tagIds": []
        },
        {
          "id": "word.action.generic.store-tools",
          "text": "把工具归回原位",
          "allowedSlots": [
            "actionCore"
          ],
          "poolIds": [
            "action.observed"
          ],
          "priority": 500,
          "review": "draft",
          "status": "active",
          "role": "core",
          "binding": {
            "subjectType": "person"
          },
          "requires": [
            {
              "fact": "actor.present",
              "comparison": "eq",
              "value": true
            },
            {
              "fact": "action.observed",
              "comparison": "eq",
              "value": "tool-returned"
            }
          ],
          "pendingFacts": [],
          "excludes": [],
          "exclusive": [],
          "contentTier": "general",
          "tagIds": []
        },
        {
          "id": "word.form.modern.doorframe",
          "text": "靠在门框上的短发人物",
          "allowedSlots": [
            "opponentForm"
          ],
          "poolIds": [
            "actor.form"
          ],
          "priority": 500,
          "review": "hold",
          "status": "active",
          "role": "core",
          "binding": {
            "subjectType": "person"
          },
          "requires": [],
          "pendingFacts": [
            "确认同一人物正倚靠真实门框，且短发特征已知。"
          ],
          "excludes": [],
          "exclusive": [],
          "contentTier": "general",
          "tagIds": []
        },
        {
          "id": "word.action.modern.ticket-rub",
          "text": "用拇指反复蹭着票据边缘",
          "allowedSlots": [
            "actionCore"
          ],
          "poolIds": [
            "action.observed"
          ],
          "priority": 500,
          "review": "hold",
          "status": "active",
          "role": "core",
          "binding": {
            "subjectType": "person"
          },
          "requires": [],
          "pendingFacts": [
            "确认该人物有适用部件、持有真实票据，且正在做该动作。"
          ],
          "excludes": [],
          "exclusive": [],
          "contentTier": "general",
          "tagIds": []
        }
      ],
      "handPreviews": [
        {
          "templateId": "assembly.05.demo.observation",
          "entryIds": [
            "runtime:display.place",
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.action.generic.store-tools",
            "word.prop.generic.cup",
            "word.qualifier.generic.filtered",
            "word.material.generic.water",
            "word.sense.generic.herbal",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 7,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "在工坊，你留意到阿洛·灰谷的手。对方把工具归回原位。你注意到一只量杯，其中盛着过滤水。你察觉到草木的清香。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        },
        {
          "templateId": "assembly.05.demo.observation",
          "entryIds": [
            "runtime:display.place",
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.action.generic.return-tools",
            "word.prop.generic.cup",
            "word.qualifier.generic.filtered",
            "word.material.generic.water",
            "word.sense.generic.herbal",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 8,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "在工坊，你留意到阿洛·灰谷的手。对方将工具放回原处。你注意到一只量杯，其中盛着过滤水。你察觉到草木的清香。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        },
        {
          "templateId": "assembly.05.demo.observation",
          "entryIds": [
            "runtime:display.place",
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.action.generic.return-tools",
            "word.prop.generic.cup",
            "word.qualifier.generic.filtered",
            "word.material.generic.water",
            "word.sense.generic.herbal",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 9,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "在工坊，你留意到阿洛·灰谷的手。对方将工具放回原处。你注意到一只量杯，其中盛着过滤水。你察觉到草木的清香。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        }
      ],
      "suggestedTags": [],
      "notes": "演示批，未达到正式任务配额；只有离线测试用途。"
    },
    {
      "format": "aetheria-authoring-delivery",
      "specVersion": "1.3",
      "task": "B3",
      "theme": "generic",
      "author": "协作包中性参考稿",
      "batchId": "demo-b3",
      "revision": 1,
      "entries": [
        {
          "id": "word.part.generic.hand",
          "text": "手",
          "allowedSlots": [
            "bodyPart"
          ],
          "poolIds": [
            "actor.bodyPart"
          ],
          "priority": 500,
          "review": "draft",
          "status": "active",
          "role": "core",
          "binding": {
            "subjectType": "part"
          },
          "requires": [
            {
              "fact": "part.kind",
              "comparison": "eq",
              "value": "hand"
            },
            {
              "fact": "actor.present",
              "comparison": "eq",
              "value": true
            }
          ],
          "pendingFacts": [],
          "excludes": [],
          "exclusive": [],
          "contentTier": "general",
          "tagIds": []
        },
        {
          "id": "word.material.generic.water",
          "text": "水",
          "allowedSlots": [
            "materialFluid"
          ],
          "poolIds": [
            "material.current"
          ],
          "priority": 500,
          "review": "draft",
          "status": "active",
          "role": "core",
          "binding": {
            "subjectType": "object"
          },
          "requires": [
            {
              "fact": "material.kind",
              "comparison": "eq",
              "value": "water"
            },
            {
              "fact": "prop.contains",
              "comparison": "eq",
              "value": "water-1"
            }
          ],
          "pendingFacts": [],
          "excludes": [],
          "exclusive": [],
          "contentTier": "general",
          "tagIds": []
        },
        {
          "id": "word.qualifier.generic.filtered",
          "text": "过滤",
          "allowedSlots": [
            "materialFluid"
          ],
          "poolIds": [
            "material.qualifier"
          ],
          "priority": 500,
          "review": "draft",
          "status": "active",
          "role": "qualifier",
          "binding": {
            "subjectType": "object"
          },
          "requires": [
            {
              "fact": "water.filtered",
              "comparison": "eq",
              "value": true
            }
          ],
          "pendingFacts": [],
          "excludes": [],
          "exclusive": [],
          "contentTier": "general",
          "tagIds": []
        },
        {
          "id": "word.material.generic.brass",
          "text": "黄铜",
          "allowedSlots": [
            "materialFluid"
          ],
          "poolIds": [
            "body.material"
          ],
          "priority": 500,
          "review": "draft",
          "status": "active",
          "role": "core",
          "binding": {
            "subjectType": "part"
          },
          "requires": [
            {
              "fact": "part.material",
              "comparison": "eq",
              "value": "brass"
            }
          ],
          "pendingFacts": [],
          "excludes": [],
          "exclusive": [],
          "contentTier": "general",
          "tagIds": []
        },
        {
          "id": "word.qualifier.generic.fine-grain",
          "text": "带细纹",
          "allowedSlots": [
            "materialFluid"
          ],
          "poolIds": [
            "body.material.qualifier"
          ],
          "priority": 500,
          "review": "draft",
          "status": "active",
          "role": "qualifier",
          "binding": {
            "subjectType": "part"
          },
          "requires": [
            {
              "fact": "part.finish",
              "comparison": "eq",
              "value": "fine-grain"
            }
          ],
          "pendingFacts": [],
          "excludes": [],
          "exclusive": [],
          "contentTier": "general",
          "tagIds": []
        },
        {
          "id": "word.part.generic.open-palm",
          "text": "摊开的手掌",
          "allowedSlots": [
            "bodyPart"
          ],
          "poolIds": [
            "actor.bodyPart"
          ],
          "priority": 500,
          "review": "hold",
          "status": "active",
          "role": "core",
          "binding": {
            "subjectType": "part"
          },
          "requires": [],
          "pendingFacts": [
            "确认该部件有对应手掌结构且处于张开姿态，不能仅凭hand kind推断。"
          ],
          "excludes": [],
          "exclusive": [],
          "contentTier": "general",
          "tagIds": []
        }
      ],
      "handPreviews": [
        {
          "templateId": "assembly.08.demo.body",
          "entryIds": [
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.qualifier.generic.fine-grain",
            "word.material.generic.brass",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 7,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "你留意到阿洛·灰谷的手。该部件的表面呈现带细纹的黄铜质感。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        },
        {
          "templateId": "assembly.08.demo.body",
          "entryIds": [
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.qualifier.generic.fine-grain",
            "word.material.generic.brass",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 8,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "你留意到阿洛·灰谷的手。该部件的表面呈现带细纹的黄铜质感。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        },
        {
          "templateId": "assembly.08.demo.body",
          "entryIds": [
            "runtime:display.actor",
            "word.part.generic.hand",
            "word.qualifier.generic.fine-grain",
            "word.material.generic.brass",
            "runtime:display.exit"
          ],
          "fixtureId": "neutral-workshop-v1",
          "seed": 9,
          "revision": 12,
          "mode": "reference-assembler",
          "text": "你留意到阿洛·灰谷的手。该部件的表面呈现带细纹的黄铜质感。你可以结束观察。",
          "evidenceStatus": "fixture-verified"
        }
      ],
      "suggestedTags": [],
      "notes": "演示批，未达到正式任务配额；只有离线测试用途。"
    }
  ],
  "context": {
    "revision": 12,
    "seed": 7,
    "bindings": {
      "place": {
        "subject": "location",
        "instanceId": "workshop-1"
      },
      "actor": {
        "subject": "resident:alo",
        "instanceId": "resident:alo"
      },
      "part": {
        "subject": "resident:alo",
        "instanceId": "hand-left"
      },
      "prop": {
        "subject": "object",
        "instanceId": "cup-1"
      },
      "material": {
        "subject": "object",
        "instanceId": "water-1"
      },
      "sense": {
        "subject": "location",
        "instanceId": "workshop-1"
      },
      "exit": {
        "subject": "event:observation",
        "instanceId": "exit-1"
      }
    },
    "facts": {
      "actor.present": {
        "known": true,
        "value": true,
        "source": "snapshot",
        "binding": {
          "subject": "resident:alo",
          "instanceId": "resident:alo"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      },
      "part.kind": {
        "known": true,
        "value": "hand",
        "source": "engine-query",
        "binding": {
          "subject": "resident:alo",
          "instanceId": "hand-left"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      },
      "part.changed": {
        "known": true,
        "value": false,
        "source": "snapshot",
        "binding": {
          "subject": "resident:alo",
          "instanceId": "hand-left"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      },
      "part.material": {
        "known": true,
        "value": "brass",
        "source": "engine-query",
        "binding": {
          "subject": "resident:alo",
          "instanceId": "hand-left"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      },
      "part.finish": {
        "known": true,
        "value": "fine-grain",
        "source": "engine-query",
        "binding": {
          "subject": "resident:alo",
          "instanceId": "hand-left"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      },
      "action.observed": {
        "known": true,
        "value": "tool-returned",
        "source": "snapshot",
        "binding": {
          "subject": "resident:alo",
          "instanceId": "resident:alo"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      },
      "prop.kind": {
        "known": true,
        "value": "measuring-cup",
        "source": "snapshot",
        "binding": {
          "subject": "object",
          "instanceId": "cup-1"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      },
      "prop.contains": {
        "known": true,
        "value": "water-1",
        "source": "snapshot",
        "binding": {
          "subject": "object",
          "instanceId": "cup-1"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      },
      "material.kind": {
        "known": true,
        "value": "water",
        "source": "snapshot",
        "binding": {
          "subject": "object",
          "instanceId": "water-1"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      },
      "water.filtered": {
        "known": true,
        "value": true,
        "source": "snapshot",
        "binding": {
          "subject": "object",
          "instanceId": "water-1"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      },
      "sense.available": {
        "known": true,
        "value": true,
        "source": "snapshot",
        "binding": {
          "subject": "location",
          "instanceId": "workshop-1"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      },
      "sense.channel": {
        "known": true,
        "value": "smell",
        "source": "snapshot",
        "binding": {
          "subject": "location",
          "instanceId": "workshop-1"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      },
      "sense.sample": {
        "known": true,
        "value": "herbal",
        "source": "snapshot",
        "binding": {
          "subject": "location",
          "instanceId": "workshop-1"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      },
      "scene.setting": {
        "known": true,
        "value": "worlds:setting.fantasy",
        "source": "snapshot",
        "binding": {
          "subject": "location",
          "instanceId": "workshop-1"
        },
        "provenance": "人工构造的中性测试快照，不是游戏查询结果"
      }
    },
    "participants": [
      {
        "id": "resident:alo",
        "classification": "sapient",
        "intelligent": true,
        "present": true
      }
    ],
    "policy": {
      "adultOptional": false,
      "consentBySubject": {}
    },
    "registeredTags": [],
    "exitChoice": {
      "actionId": "example:exit",
      "label": "结束观察",
      "next": null,
      "conditions": [],
      "effects": [],
      "setTags": [],
      "unsetTags": []
    },
    "displayValues": [
      {
        "binding": {
          "subject": "location",
          "instanceId": "workshop-1"
        },
        "name": "工坊",
        "revision": 12,
        "source": "snapshot"
      },
      {
        "binding": {
          "subject": "resident:alo",
          "instanceId": "resident:alo"
        },
        "name": "阿洛·灰谷",
        "revision": 12,
        "source": "snapshot"
      }
    ],
    "fixtureId": "neutral-workshop-v1",
    "syntheticTestSnapshot": true,
    "bindingTypes": {
      "place": "location",
      "actor": "person",
      "part": "part",
      "prop": "object",
      "material": "object",
      "sense": "location",
      "exit": "event"
    }
  },
  "plan": {
    "authority": "fixture-review-only",
    "runtimeIntegrated": false,
    "approvals": [
      {
        "entryId": "word.part.generic.hand",
        "sha256": "5f63b045902d0a1fdcfaeaba210065917fbc851243870063c5fc8254a60c8784",
        "bindingKey": "part",
        "semanticFacts": [
          "part.kind",
          "actor.present"
        ],
        "relatedBindings": [
          "actor"
        ]
      },
      {
        "entryId": "word.prop.generic.cup",
        "sha256": "ca23508d87518b0a1c723076ecfd7e8103e324e26eb2e3a75335a4e655348517",
        "bindingKey": "prop",
        "semanticFacts": [
          "prop.kind"
        ],
        "relatedBindings": []
      },
      {
        "entryId": "word.action.generic.return-tools",
        "sha256": "0cc13eab5f5f46e7f2c15a9972e5e6ce2c2f42f2742321dd415de57b20dbac68",
        "bindingKey": "actor",
        "semanticFacts": [
          "actor.present",
          "action.observed"
        ],
        "relatedBindings": []
      },
      {
        "entryId": "word.action.generic.store-tools",
        "sha256": "87c737ca752987d87c0cf139114fbdeac2c629eb9c5a3984371405a297e958f8",
        "bindingKey": "actor",
        "semanticFacts": [
          "actor.present",
          "action.observed"
        ],
        "relatedBindings": []
      },
      {
        "entryId": "word.sense.generic.herbal",
        "sha256": "9df97bbe9c7ba9ae32a96ba610bb565ac788f8b44b5508386c12bb56b1a805b1",
        "bindingKey": "sense",
        "semanticFacts": [
          "sense.available",
          "sense.channel",
          "sense.sample"
        ],
        "relatedBindings": []
      },
      {
        "entryId": "word.material.generic.water",
        "sha256": "ecc2f2ffcced16701c385d897937f5fae2ac9b0b4746ff3fbf3c63fee46d79a7",
        "bindingKey": "material",
        "semanticFacts": [
          "material.kind",
          "prop.contains"
        ],
        "relatedBindings": [
          "prop"
        ]
      },
      {
        "entryId": "word.qualifier.generic.filtered",
        "sha256": "384102627217a23b75aa0cd91fd8025dec22ab8b27b31a12db423045daed9dc9",
        "bindingKey": "material",
        "semanticFacts": [
          "water.filtered"
        ],
        "relatedBindings": []
      },
      {
        "entryId": "word.material.generic.brass",
        "sha256": "536bef4ab85d41af9ee3ca9bc3f8f81b55f40c309019ebf82f1ef3361fb8a24d",
        "bindingKey": "part",
        "semanticFacts": [
          "part.material"
        ],
        "relatedBindings": []
      },
      {
        "entryId": "word.qualifier.generic.fine-grain",
        "sha256": "f634edfabd58e7a89e2bc23986893ef9039f9fb5fe53ad13c08506d2976b6cba",
        "bindingKey": "part",
        "semanticFacts": [
          "part.finish"
        ],
        "relatedBindings": []
      }
    ],
    "warning": "这些审稿记录仅授权中性测试快照；不是真实游戏批准、不会保存approved记录。"
  },
  "manualMethod": [
    "先选择模板和已声明测试快照，不按文字编造物件或身体。",
    "每个出现位按合法词池/精确实例/已知事实选择；无条件的高优先级不会因低优先级条件为真而失效。",
    "按qualifierPlan顺序挂前；连接符由plan提供，定词文本不带末尾的。",
    "可选槽为空时一起删除连接词。",
    "记录templateId、entryIds、fixtureId、seed、revision，标manual/hypothetical-only。",
    "手工轮换用于语感检查；运行能否生成以真实拼装结果为准。"
  ],
  "scope": "独立构造的普通观察快照；游戏引擎接入仍待实施。"
}

~~~


## 完整输入文件：05-Tag参考.json

~~~json
{
  "title": "词池Tag参考子集",
  "specVersion": "1.3",
  "sourceCommit": "eca297ae38e7733e35c31b0124629d94cec2f0a7",
  "usage": "登记/检索分类，不证明场景事实；全库查重使用08。material.all是参考分组，不是可入槽池。environment.sense子池共用environment.sense参考分组。",
  "themes": [
    "general-taxonomy:setting.modern",
    "general-taxonomy:setting.cyberpunk",
    "general-taxonomy:setting.fantasy",
    "general-taxonomy:setting.xianxia",
    "general-taxonomy:setting.post-apocalypse"
  ],
  "pools": {
    "environment.prop": {
      "general-taxonomy:common.object.battery": "电池",
      "general-taxonomy:common.object.blanket": "毯子",
      "general-taxonomy:common.object.calendar": "日历",
      "general-taxonomy:common.object.charger": "充电器",
      "general-taxonomy:common.object.chopsticks": "筷子",
      "general-taxonomy:common.object.clip": "夹子",
      "general-taxonomy:common.object.clock": "时钟",
      "general-taxonomy:common.object.clothes-pin": "晾衣夹",
      "general-taxonomy:common.object.cushion": "坐垫",
      "general-taxonomy:common.object.earphones": "耳机",
      "general-taxonomy:common.object.envelope": "信封",
      "general-taxonomy:common.object.flashlight": "手电筒",
      "general-taxonomy:common.object.fork": "餐叉",
      "general-taxonomy:common.object.hanger": "衣架",
      "general-taxonomy:common.object.identity-card": "证件",
      "general-taxonomy:common.object.kettle": "水壶",
      "general-taxonomy:common.object.key": "钥匙",
      "general-taxonomy:common.object.lunchbox": "饭盒",
      "general-taxonomy:common.object.map": "地图",
      "general-taxonomy:common.object.mattress": "床垫",
      "general-taxonomy:common.object.medicine-box": "药盒",
      "general-taxonomy:common.object.napkin": "餐巾",
      "general-taxonomy:common.object.pen": "笔",
      "general-taxonomy:common.object.phone": "通讯器",
      "general-taxonomy:common.object.pillow": "枕头",
      "general-taxonomy:common.object.plate": "餐盘",
      "general-taxonomy:common.object.powerbank": "移动电源",
      "general-taxonomy:common.object.raincoat": "雨衣",
      "general-taxonomy:common.object.receipt": "收据",
      "general-taxonomy:common.object.saucepan": "锅",
      "general-taxonomy:common.object.shopping-bag": "购物袋",
      "general-taxonomy:common.object.storage-bag": "收纳袋",
      "general-taxonomy:common.object.thermometer": "温度计",
      "general-taxonomy:common.object.thermos": "保温瓶",
      "general-taxonomy:common.object.ticket": "票券",
      "general-taxonomy:common.object.towel": "毛巾",
      "general-taxonomy:common.object.transit-card": "交通卡",
      "general-taxonomy:common.object.umbrella": "伞",
      "general-taxonomy:common.object.wallet": "钱包",
      "general-taxonomy:common.object.water-bottle": "水杯",
      "general-taxonomy:common.tool.brush": "刷子",
      "general-taxonomy:common.tool.bucket": "水桶",
      "general-taxonomy:common.tool.cable-tie": "扎带",
      "general-taxonomy:common.tool.clamp": "固定夹",
      "general-taxonomy:common.tool.cleaning-cloth": "抹布",
      "general-taxonomy:common.tool.detergent": "清洁剂",
      "general-taxonomy:common.tool.dustpan": "簸箕",
      "general-taxonomy:common.tool.file": "锉刀",
      "general-taxonomy:common.tool.glue": "胶黏剂",
      "general-taxonomy:common.tool.lubricant": "润滑剂",
      "general-taxonomy:common.tool.mop": "拖把",
      "general-taxonomy:common.tool.needle": "针",
      "general-taxonomy:common.tool.pliers": "钳子",
      "general-taxonomy:common.tool.sandpaper": "砂纸",
      "general-taxonomy:common.tool.scissors": "剪刀",
      "general-taxonomy:common.tool.scraper": "刮板",
      "general-taxonomy:common.tool.screwdriver": "螺丝刀",
      "general-taxonomy:common.tool.spirit-level": "水平尺",
      "general-taxonomy:common.tool.sponge": "海绵",
      "general-taxonomy:common.tool.tape": "胶带",
      "general-taxonomy:common.tool.tape-measure": "卷尺",
      "general-taxonomy:common.tool.thread": "线",
      "general-taxonomy:common.tool.work-gloves": "劳动手套",
      "general-taxonomy:common.tool.wrench": "扳手",
      "general-taxonomy:common.facility.access-panel": "门禁读卡器",
      "general-taxonomy:common.facility.air-filter": "空气过滤器",
      "general-taxonomy:common.facility.automatic-door": "自动门",
      "general-taxonomy:common.facility.backup-power": "备用电源",
      "general-taxonomy:common.facility.bike-rack": "自行车架",
      "general-taxonomy:common.facility.bulletin-screen": "公告屏",
      "general-taxonomy:common.facility.charging-point": "充电点",
      "general-taxonomy:common.facility.drain": "排水口",
      "general-taxonomy:common.facility.elevator": "电梯",
      "general-taxonomy:common.facility.escalator": "扶梯",
      "general-taxonomy:common.facility.fire-extinguisher": "灭火器",
      "general-taxonomy:common.facility.first-aid-kit": "急救箱",
      "general-taxonomy:common.facility.guardrail": "护栏",
      "general-taxonomy:common.facility.handrail": "扶手",
      "general-taxonomy:common.facility.intercom": "对讲机",
      "general-taxonomy:common.facility.locker": "储物柜",
      "general-taxonomy:common.facility.mailbox": "信箱",
      "general-taxonomy:common.facility.parcel-locker": "快递柜",
      "general-taxonomy:common.facility.public-terminal": "公共终端",
      "general-taxonomy:common.facility.queue-display": "叫号屏",
      "general-taxonomy:common.facility.ramp": "坡道",
      "general-taxonomy:common.facility.shade-canopy": "遮阳棚",
      "general-taxonomy:common.facility.ticket-machine": "售票机",
      "general-taxonomy:common.facility.turnstile": "闸机",
      "general-taxonomy:common.facility.vending-machine": "售货机",
      "general-taxonomy:common.facility.vent": "通风口",
      "general-taxonomy:common.facility.washbasin": "洗手台",
      "general-taxonomy:common.facility.waste-sort-bin": "分类垃圾桶",
      "general-taxonomy:common.facility.water-dispenser": "饮水机",
      "general-taxonomy:common.facility.wheelchair-space": "轮椅停留位",
      "general-taxonomy:v2.services.animal-shelter": "动物收容所",
      "general-taxonomy:v2.services.bakery": "面包店",
      "general-taxonomy:v2.services.barbershop": "理发店",
      "general-taxonomy:v2.services.bookshop": "书店",
      "general-taxonomy:v2.services.butcher": "肉铺",
      "general-taxonomy:v2.services.exhibition-room": "展览室",
      "general-taxonomy:v2.services.fabric-shop": "布料店",
      "general-taxonomy:v2.services.flower-shop": "花店",
      "general-taxonomy:v2.services.grain-shop": "粮店",
      "general-taxonomy:v2.services.hardware-shop": "五金店",
      "general-taxonomy:v2.services.lost-property": "失物招领处",
      "general-taxonomy:v2.services.mediation": "调解室",
      "general-taxonomy:v2.services.music-room": "音乐室",
      "general-taxonomy:v2.services.pet-care": "动物照护站",
      "general-taxonomy:v2.services.print-shop": "打印店",
      "general-taxonomy:v2.services.produce-shop": "蔬果店",
      "general-taxonomy:v2.services.public-toilet": "公共卫生间",
      "general-taxonomy:v2.services.repair-bench": "公共修理台",
      "general-taxonomy:v2.services.shoe-repair": "修鞋铺",
      "general-taxonomy:v2.services.training-room": "培训室",
      "general-taxonomy:v2.food.apple": "苹果",
      "general-taxonomy:v2.food.bread": "面包",
      "general-taxonomy:v2.food.cabbage": "白菜",
      "general-taxonomy:v2.food.corn": "玉米",
      "general-taxonomy:v2.food.dumpling": "饺子",
      "general-taxonomy:v2.food.egg": "蛋",
      "general-taxonomy:v2.food.filled-bun": "包子",
      "general-taxonomy:v2.food.flatbread": "饼",
      "general-taxonomy:v2.food.onion": "洋葱",
      "general-taxonomy:v2.food.orange": "橙",
      "general-taxonomy:v2.food.pear": "梨",
      "general-taxonomy:v2.food.porridge": "粥",
      "general-taxonomy:v2.food.potato": "马铃薯",
      "general-taxonomy:v2.food.rice": "米饭",
      "general-taxonomy:v2.food.soup": "汤",
      "general-taxonomy:v2.food.steamed-bun": "馒头",
      "general-taxonomy:v2.food.stew": "炖菜",
      "general-taxonomy:v2.food.sweet-potato": "甘薯",
      "general-taxonomy:v2.food.tofu": "豆腐",
      "general-taxonomy:v2.food.tomato": "番茄",
      "general-taxonomy:v2.drink.astringency": "涩感",
      "general-taxonomy:v2.drink.bitterness": "苦味",
      "general-taxonomy:v2.drink.broth": "清汤",
      "general-taxonomy:v2.drink.coffee": "咖啡",
      "general-taxonomy:v2.drink.crispness": "酥脆口感",
      "general-taxonomy:v2.drink.drinking-water": "饮用水",
      "general-taxonomy:v2.drink.fruit-juice": "果汁",
      "general-taxonomy:v2.drink.milk": "乳饮",
      "general-taxonomy:v2.drink.oil": "食用油",
      "general-taxonomy:v2.drink.salt": "食盐",
      "general-taxonomy:v2.drink.saltiness": "咸味",
      "general-taxonomy:v2.drink.sourness": "酸味",
      "general-taxonomy:v2.drink.soy-milk": "豆浆",
      "general-taxonomy:v2.drink.soy-sauce": "酱油",
      "general-taxonomy:v2.drink.sparkling-water": "气泡水",
      "general-taxonomy:v2.drink.sugar": "糖",
      "general-taxonomy:v2.drink.sweetness": "甜味",
      "general-taxonomy:v2.drink.tea": "茶",
      "general-taxonomy:v2.drink.umami": "鲜味",
      "general-taxonomy:v2.drink.vinegar": "醋"
    },
    "environment.sense": {
      "general-taxonomy:common.env.breeze": "微风",
      "general-taxonomy:common.env.chilly": "微凉",
      "general-taxonomy:common.env.crosswind": "侧风",
      "general-taxonomy:common.env.dew": "结露",
      "general-taxonomy:common.env.downpour": "暴雨",
      "general-taxonomy:common.env.draft": "穿堂风",
      "general-taxonomy:common.env.drizzle": "细雨",
      "general-taxonomy:common.env.dry-air": "空气干燥",
      "general-taxonomy:common.env.dust": "扬尘",
      "general-taxonomy:common.env.foggy": "起雾",
      "general-taxonomy:common.env.fresh": "空气清新",
      "general-taxonomy:common.env.frost": "结霜",
      "general-taxonomy:common.env.gust": "阵风",
      "general-taxonomy:common.env.haze": "烟霾",
      "general-taxonomy:common.env.hot": "闷热",
      "general-taxonomy:common.env.humid-air": "空气潮湿",
      "general-taxonomy:common.env.icy-surface": "结冰",
      "general-taxonomy:common.env.mild": "温和",
      "general-taxonomy:common.env.odorless": "无明显气味",
      "general-taxonomy:common.env.sleet": "雨夹雪",
      "general-taxonomy:common.env.smoky": "烟气",
      "general-taxonomy:common.env.snowfall": "降雪",
      "general-taxonomy:common.env.stuffy": "空气滞闷",
      "general-taxonomy:common.env.warm": "温暖",
      "general-taxonomy:v2.sensory.afterglow": "余辉",
      "general-taxonomy:v2.sensory.color-temperature": "色温",
      "general-taxonomy:v2.sensory.diffraction": "衍射光纹",
      "general-taxonomy:v2.sensory.glow": "辉光",
      "general-taxonomy:v2.sensory.hard-shadow": "硬阴影",
      "general-taxonomy:v2.sensory.high-pitch": "高音",
      "general-taxonomy:v2.sensory.highlight": "高光",
      "general-taxonomy:v2.sensory.light-pool": "光斑",
      "general-taxonomy:v2.sensory.low-hum": "低鸣",
      "general-taxonomy:v2.sensory.low-pitch": "低音",
      "general-taxonomy:v2.sensory.opacity": "不透光",
      "general-taxonomy:v2.sensory.overexposure": "亮部失细节",
      "general-taxonomy:v2.sensory.resonance": "共振",
      "general-taxonomy:v2.sensory.shadow-detail": "暗部细节",
      "general-taxonomy:v2.sensory.silhouette": "剪影",
      "general-taxonomy:v2.sensory.soft-shadow": "柔阴影",
      "general-taxonomy:v2.sensory.sound-absorption": "吸声",
      "general-taxonomy:v2.sensory.sound-masking": "掩蔽声",
      "general-taxonomy:v2.sensory.translucence": "半透光",
      "general-taxonomy:v2.sensory.white-noise": "白噪声",
      "general-taxonomy:v2.hydrology.cloudburst": "骤雨",
      "general-taxonomy:v2.hydrology.dripping": "滴水",
      "general-taxonomy:v2.hydrology.ebbing": "退水",
      "general-taxonomy:v2.hydrology.eddy": "涡流",
      "general-taxonomy:v2.hydrology.falling-tide": "落潮",
      "general-taxonomy:v2.hydrology.flooding": "漫水",
      "general-taxonomy:v2.hydrology.freezing-rain": "冻雨",
      "general-taxonomy:v2.hydrology.frost-thaw": "融霜",
      "general-taxonomy:v2.hydrology.hail": "冰雹",
      "general-taxonomy:v2.hydrology.ponding": "积水",
      "general-taxonomy:v2.hydrology.rain-break": "雨歇",
      "general-taxonomy:v2.hydrology.rain-front": "雨带",
      "general-taxonomy:v2.hydrology.rainbow": "彩虹",
      "general-taxonomy:v2.hydrology.rising-tide": "涨潮",
      "general-taxonomy:v2.hydrology.runoff": "地表径流",
      "general-taxonomy:v2.hydrology.seepage": "渗水",
      "general-taxonomy:v2.hydrology.snowmelt": "融雪",
      "general-taxonomy:v2.hydrology.sunshower": "太阳雨",
      "general-taxonomy:v2.hydrology.thunderstorm": "雷雨",
      "general-taxonomy:v2.hydrology.water-ripple": "涟漪",
      "general-taxonomy:expanded.scent.disinfectant": "消毒液气味",
      "general-taxonomy:expanded.scent.dust": "粉尘气味",
      "general-taxonomy:expanded.scent.fruit": "果香",
      "general-taxonomy:expanded.scent.fuel": "燃料气味",
      "general-taxonomy:expanded.scent.herb": "草本气味",
      "general-taxonomy:expanded.scent.iodine": "碘气味",
      "general-taxonomy:expanded.scent.leather": "皮革气味",
      "general-taxonomy:expanded.scent.mud": "泥土气味",
      "general-taxonomy:expanded.scent.oil": "油脂气味",
      "general-taxonomy:expanded.scent.ozone": "臭氧气味",
      "general-taxonomy:expanded.scent.pickles": "发酵气味",
      "general-taxonomy:expanded.scent.plastic": "塑料气味",
      "general-taxonomy:expanded.scent.rubber": "橡胶气味",
      "general-taxonomy:expanded.scent.rust": "锈味",
      "general-taxonomy:expanded.scent.salt": "盐水气味",
      "general-taxonomy:expanded.scent.smoke": "烟气味",
      "general-taxonomy:expanded.scent.spice": "香料气味",
      "general-taxonomy:expanded.scent.sulfide": "硫化物气味",
      "general-taxonomy:expanded.scent.sulfur": "硫磺气味",
      "general-taxonomy:sound.bell": "铃声",
      "general-taxonomy:sound.birds": "鸟声",
      "general-taxonomy:sound.footsteps": "脚步声",
      "general-taxonomy:sound.insects": "虫鸣",
      "general-taxonomy:sound.machine": "机器声",
      "general-taxonomy:sound.tools": "工具声",
      "general-taxonomy:sound.water": "水声",
      "general-taxonomy:sound.wind": "风声",
      "general-taxonomy:weather.cold": "寒冷感",
      "general-taxonomy:weather.fog": "雾",
      "general-taxonomy:weather.heat": "炎热感",
      "general-taxonomy:weather.rain": "雨",
      "general-taxonomy:weather.sunlight": "日光",
      "general-taxonomy:weather.wind": "风"
    },
    "actor.form": {
      "general-taxonomy:common.job.archivist": "档案管理员",
      "general-taxonomy:common.job.baker": "烘焙师",
      "general-taxonomy:common.job.barista": "饮品师",
      "general-taxonomy:common.job.cashier": "收银员",
      "general-taxonomy:common.job.courier": "快递员",
      "general-taxonomy:common.job.dispatcher": "调度员",
      "general-taxonomy:common.job.driver": "司机",
      "general-taxonomy:common.job.electrician": "电工",
      "general-taxonomy:common.job.firefighter": "消防员",
      "general-taxonomy:common.job.gardener": "园艺工",
      "general-taxonomy:common.job.hairdresser": "理发师",
      "general-taxonomy:common.job.inspector": "巡检员",
      "general-taxonomy:common.job.kitchen-assistant": "厨房帮工",
      "general-taxonomy:common.job.lab-assistant": "实验助理",
      "general-taxonomy:common.job.librarian": "图书管理员",
      "general-taxonomy:common.job.mail-carrier": "邮递员",
      "general-taxonomy:common.job.maintenance-dispatch": "报修接线员",
      "general-taxonomy:common.job.mechanic": "机械维修员",
      "general-taxonomy:common.job.plumber": "水管工",
      "general-taxonomy:common.job.property-manager": "物业管理员",
      "general-taxonomy:common.job.receptionist": "前台接待",
      "general-taxonomy:common.job.researcher": "研究员",
      "general-taxonomy:common.job.scheduler": "排班员",
      "general-taxonomy:common.job.security": "保安员",
      "general-taxonomy:common.job.shop-assistant": "店员",
      "general-taxonomy:common.job.sorter": "分拣员",
      "general-taxonomy:common.job.translator": "翻译员",
      "general-taxonomy:common.job.volunteer": "志愿服务者",
      "general-taxonomy:common.job.waiter": "服务员",
      "general-taxonomy:common.job.warehouse-clerk": "仓管员",
      "general-taxonomy:job.carer": "照护员",
      "general-taxonomy:job.carpenter": "木工",
      "general-taxonomy:job.cleaner": "清洁工",
      "general-taxonomy:job.clerk": "办事员",
      "general-taxonomy:job.cook": "厨工",
      "general-taxonomy:job.courier": "递送员",
      "general-taxonomy:job.custodian": "看管员",
      "general-taxonomy:job.guide": "引导员",
      "general-taxonomy:job.mediator": "调解员",
      "general-taxonomy:job.metalworker": "金工",
      "general-taxonomy:job.painter": "漆工",
      "general-taxonomy:job.porter": "搬运工",
      "general-taxonomy:job.reader": "代读员",
      "general-taxonomy:job.reception": "接待员",
      "general-taxonomy:job.scribe": "记录员",
      "general-taxonomy:job.tailor": "缝纫工",
      "general-taxonomy:job.teacher": "教习",
      "general-taxonomy:job.vendor": "售货员",
      "general-taxonomy:job.weigher": "称重员",
      "general-taxonomy:disposition.ask-first": "事先询问",
      "general-taxonomy:disposition.brevity": "简洁表达",
      "general-taxonomy:disposition.caution": "谨慎",
      "general-taxonomy:disposition.curiosity": "好奇",
      "general-taxonomy:disposition.helpfulness": "助人",
      "general-taxonomy:disposition.permission": "尊重权限",
      "general-taxonomy:disposition.privacy": "尊重隐私",
      "general-taxonomy:disposition.resource-care": "惜物",
      "general-taxonomy:disposition.tension": "紧张表现",
      "general-taxonomy:appearance.asymmetry": "不对称",
      "general-taxonomy:appearance.crystal": "晶体外观",
      "general-taxonomy:appearance.double-shadow": "重影",
      "general-taxonomy:appearance.flow": "流动外观",
      "general-taxonomy:appearance.rock": "岩石纹理",
      "general-taxonomy:appearance.shadow-lag": "影像滞后",
      "general-taxonomy:appearance.transparency": "透光",
      "general-taxonomy:identity.apprentice": "学徒",
      "general-taxonomy:identity.association": "社群成员",
      "general-taxonomy:identity.housemate": "合住者",
      "general-taxonomy:identity.representative": "社区代表",
      "general-taxonomy:identity.resident": "住户",
      "general-taxonomy:identity.sibling": "兄弟姐妹",
      "general-taxonomy:identity.volunteer": "志愿者"
    },
    "action.observed": {
      "general-taxonomy:common.action.book": "预约",
      "general-taxonomy:common.action.borrow": "借用",
      "general-taxonomy:common.action.cancel-booking": "取消预约",
      "general-taxonomy:common.action.charge": "充电",
      "general-taxonomy:common.action.check-in": "报到",
      "general-taxonomy:common.action.check-list": "核对清单",
      "general-taxonomy:common.action.collect": "领取",
      "general-taxonomy:common.action.dry": "晾干",
      "general-taxonomy:common.action.exchange": "换货",
      "general-taxonomy:common.action.fold": "折叠",
      "general-taxonomy:common.action.follow-up": "跟进",
      "general-taxonomy:common.action.keep-record": "记账",
      "general-taxonomy:common.action.label": "贴标",
      "general-taxonomy:common.action.lock": "上锁",
      "general-taxonomy:common.action.measure": "测量",
      "general-taxonomy:common.action.pack": "打包",
      "general-taxonomy:common.action.pay": "付款",
      "general-taxonomy:common.action.queue": "排队",
      "general-taxonomy:common.action.refill": "补充消耗品",
      "general-taxonomy:common.action.refund": "退款",
      "general-taxonomy:common.action.register": "登记",
      "general-taxonomy:common.action.report-fault": "报修",
      "general-taxonomy:common.action.reschedule": "改期",
      "general-taxonomy:common.action.retrieve": "取回",
      "general-taxonomy:common.action.return": "归还",
      "general-taxonomy:common.action.sign-receipt": "签收",
      "general-taxonomy:common.action.sort": "分类",
      "general-taxonomy:common.action.submit": "提交",
      "general-taxonomy:common.action.take-break": "休息片刻",
      "general-taxonomy:common.action.test": "试用",
      "general-taxonomy:common.action.transfer": "换乘",
      "general-taxonomy:common.action.unlock": "解锁",
      "general-taxonomy:common.action.unpack": "拆包",
      "general-taxonomy:common.action.ventilate": "通风",
      "general-taxonomy:common.action.weigh": "称量",
      "general-taxonomy:action.adapt-space": "适应空间",
      "general-taxonomy:action.adjust-pose": "调整姿态",
      "general-taxonomy:action.be-alone": "独处",
      "general-taxonomy:action.carry": "搬运",
      "general-taxonomy:action.clean": "清洁",
      "general-taxonomy:action.climb": "攀行",
      "general-taxonomy:action.compare": "比较",
      "general-taxonomy:action.cook": "备餐",
      "general-taxonomy:action.drink": "饮用",
      "general-taxonomy:action.handover": "交接",
      "general-taxonomy:action.host": "待客",
      "general-taxonomy:action.inspect": "检查",
      "general-taxonomy:action.inspect-near": "近看",
      "general-taxonomy:action.listen": "侧听",
      "general-taxonomy:action.look-far": "远望",
      "general-taxonomy:action.make": "制作",
      "general-taxonomy:action.make-room": "让出空间",
      "general-taxonomy:action.organize": "整理",
      "general-taxonomy:action.pause": "停顿",
      "general-taxonomy:action.prepare": "准备",
      "general-taxonomy:action.prepare-cooperation": "协作准备",
      "general-taxonomy:action.prepare-shopping": "购物准备",
      "general-taxonomy:action.prepare-sleep": "睡前整理",
      "general-taxonomy:action.relax": "放松",
      "general-taxonomy:action.repair": "修补",
      "general-taxonomy:action.search": "翻查",
      "general-taxonomy:action.self-care": "个人照料",
      "general-taxonomy:action.share": "分享",
      "general-taxonomy:action.sit-rest": "坐歇",
      "general-taxonomy:action.slide": "滑行",
      "general-taxonomy:action.store": "收纳",
      "general-taxonomy:action.stretch": "舒展",
      "general-taxonomy:action.swim": "游动",
      "general-taxonomy:action.taste": "品尝",
      "general-taxonomy:action.walk": "步行",
      "general-taxonomy:action.wash-dishes": "清理餐具",
      "general-taxonomy:common.state.available": "可用",
      "general-taxonomy:common.state.blocked": "堵塞",
      "general-taxonomy:common.state.changed": "安排变更",
      "general-taxonomy:common.state.cleaning": "清洁中",
      "general-taxonomy:common.state.closed": "关闭中",
      "general-taxonomy:common.state.drying": "晾干中",
      "general-taxonomy:common.state.fault": "故障",
      "general-taxonomy:common.state.idle": "空闲",
      "general-taxonomy:common.state.in-service": "服务中",
      "general-taxonomy:common.state.inspection-pending": "待检查",
      "general-taxonomy:common.state.leaking": "漏水",
      "general-taxonomy:common.state.low-stock": "库存不足",
      "general-taxonomy:common.state.maintenance": "维护中",
      "general-taxonomy:common.state.notice-posted": "已公告",
      "general-taxonomy:common.state.occupied": "占用中",
      "general-taxonomy:common.state.open": "开放中",
      "general-taxonomy:common.state.out-of-stock": "缺货",
      "general-taxonomy:common.state.power-cut": "断电",
      "general-taxonomy:common.state.reserved": "已预约",
      "general-taxonomy:common.state.restocking": "补货中",
      "general-taxonomy:common.state.return-pending": "待归还",
      "general-taxonomy:common.state.temporary": "临时安排",
      "general-taxonomy:common.state.unavailable": "不可用",
      "general-taxonomy:common.state.waiting": "等候中",
      "general-taxonomy:common.state.water-cut": "停水",
      "general-taxonomy:activity.boundary": "保持边界",
      "general-taxonomy:activity.collect": "收藏",
      "general-taxonomy:activity.draw": "绘画",
      "general-taxonomy:activity.exercise": "锻炼",
      "general-taxonomy:activity.learn": "学习",
      "general-taxonomy:activity.meditate": "冥想",
      "general-taxonomy:activity.recover": "恢复",
      "general-taxonomy:activity.relocate": "迁居",
      "general-taxonomy:activity.repair": "修补",
      "general-taxonomy:activity.shared-meal": "共餐",
      "general-taxonomy:activity.volunteer": "志愿服务",
      "general-taxonomy:activity.write": "记录"
    },
    "actor.bodyPart": {
      "general-taxonomy:part.arm": "臂",
      "general-taxonomy:part.armor": "甲片",
      "general-taxonomy:part.back": "背",
      "general-taxonomy:part.cavity": "腔",
      "general-taxonomy:part.claw": "爪",
      "general-taxonomy:part.ear": "耳",
      "general-taxonomy:part.fin": "鳍",
      "general-taxonomy:part.finger": "指",
      "general-taxonomy:part.foot": "足",
      "general-taxonomy:part.hand": "手掌",
      "general-taxonomy:part.hip": "胯",
      "general-taxonomy:part.hoof": "蹄",
      "general-taxonomy:part.horn": "角",
      "general-taxonomy:part.leg": "腿",
      "general-taxonomy:part.membrane": "膜",
      "general-taxonomy:part.muzzle": "吻部",
      "general-taxonomy:part.nose": "鼻",
      "general-taxonomy:part.ridge": "冠脊",
      "general-taxonomy:part.sac": "囊",
      "general-taxonomy:part.scale": "鳞片",
      "general-taxonomy:part.shoulder": "肩",
      "general-taxonomy:part.tail": "尾",
      "general-taxonomy:part.waist": "腰",
      "general-taxonomy:part.webbing": "蹼",
      "general-taxonomy:part.whisker": "须",
      "general-taxonomy:part.wing": "翼",
      "general-taxonomy:expanded.anatomy.abdomen": "腹部",
      "general-taxonomy:expanded.anatomy.ankle": "踝",
      "general-taxonomy:expanded.anatomy.body-fold": "褶",
      "general-taxonomy:expanded.anatomy.body-keratin": "甲质",
      "general-taxonomy:expanded.anatomy.body-slit": "裂隙",
      "general-taxonomy:expanded.anatomy.chest": "胸部",
      "general-taxonomy:expanded.anatomy.collarbone": "锁骨",
      "general-taxonomy:expanded.anatomy.elbow": "肘",
      "general-taxonomy:expanded.anatomy.eye": "眼",
      "general-taxonomy:expanded.anatomy.hair-lock": "发绺",
      "general-taxonomy:expanded.anatomy.knee": "膝",
      "general-taxonomy:expanded.anatomy.mouth": "口部",
      "general-taxonomy:expanded.anatomy.neck": "颈部",
      "general-taxonomy:expanded.anatomy.paw-pad": "掌垫",
      "general-taxonomy:expanded.anatomy.throat": "喉部",
      "general-taxonomy:expanded.anatomy.toe": "趾",
      "general-taxonomy:expanded.anatomy.wrist": "手腕"
    },
    "material.all": {
      "general-taxonomy:material.bamboo": "竹",
      "general-taxonomy:material.bone": "骨",
      "general-taxonomy:material.brass": "黄铜",
      "general-taxonomy:material.canvas": "帆布",
      "general-taxonomy:material.ceramic": "陶瓷",
      "general-taxonomy:material.copper": "铜",
      "general-taxonomy:material.cotton": "棉",
      "general-taxonomy:material.glass": "玻璃",
      "general-taxonomy:material.hemp": "麻",
      "general-taxonomy:material.iron": "铁",
      "general-taxonomy:material.leather": "皮革",
      "general-taxonomy:material.rattan": "藤",
      "general-taxonomy:material.shell": "贝壳",
      "general-taxonomy:material.stone": "石",
      "general-taxonomy:material.tin": "锡",
      "general-taxonomy:material.wood": "木",
      "general-taxonomy:common.mat.aluminium": "铝",
      "general-taxonomy:common.mat.asphalt": "沥青",
      "general-taxonomy:common.mat.brick": "砖",
      "general-taxonomy:common.mat.cardboard": "纸板",
      "general-taxonomy:common.mat.cement": "水泥",
      "general-taxonomy:common.mat.concrete": "混凝土",
      "general-taxonomy:common.mat.cork": "软木",
      "general-taxonomy:common.mat.felt": "毛毡",
      "general-taxonomy:common.mat.foam": "泡棉",
      "general-taxonomy:common.mat.linen": "亚麻",
      "general-taxonomy:common.mat.nylon": "尼龙",
      "general-taxonomy:common.mat.paper": "纸",
      "general-taxonomy:common.mat.plastic": "塑料",
      "general-taxonomy:common.mat.polyester": "涤纶",
      "general-taxonomy:common.mat.resin": "树脂",
      "general-taxonomy:common.mat.rubber": "橡胶",
      "general-taxonomy:common.mat.silicone": "硅胶",
      "general-taxonomy:common.mat.stainless-steel": "不锈钢",
      "general-taxonomy:common.mat.steel": "钢",
      "general-taxonomy:common.mat.wool": "羊毛",
      "general-taxonomy:surface.coarse": "粗糙",
      "general-taxonomy:surface.glossy": "光亮",
      "general-taxonomy:surface.hard": "坚硬",
      "general-taxonomy:surface.matte": "哑光",
      "general-taxonomy:surface.soft": "柔软",
      "general-taxonomy:surface.transparent": "透明",
      "general-taxonomy:color.apricot": "杏色",
      "general-taxonomy:color.black": "黑",
      "general-taxonomy:color.blue": "蓝",
      "general-taxonomy:color.brown": "褐",
      "general-taxonomy:color.green": "绿",
      "general-taxonomy:color.grey": "灰",
      "general-taxonomy:color.pink": "粉",
      "general-taxonomy:color.red": "红",
      "general-taxonomy:color.white": "白",
      "general-taxonomy:color.yellow": "黄",
      "general-taxonomy:shape.ball": "球状",
      "general-taxonomy:shape.drooping": "垂",
      "general-taxonomy:shape.flat": "扁",
      "general-taxonomy:shape.pointed": "尖",
      "general-taxonomy:shape.ringed": "环纹",
      "general-taxonomy:shape.round": "圆",
      "general-taxonomy:shape.serrated": "齿状",
      "general-taxonomy:shape.spotted": "斑点",
      "general-taxonomy:shape.stacked": "层叠",
      "general-taxonomy:shape.striped": "条纹",
      "general-taxonomy:shape.wire": "丝状",
      "general-taxonomy:shape.woven": "编织"
    }
  }
}

~~~


## 完整输入文件：06-Tag增量规则.md

# Tag增量规则 v1.3

08是发包时从工程实际定义导出的完整canonical注册快照，含全部命名空间、别名/替代信息、active状态、定义、所属包/依赖、文件指纹及用途说明。05只是写手按池选词的参考子集，不是全库查重基准。数量随实际工程变动，以08为准，不硬记2030或其他旧数字。

Tag仅证明登记身份，不保证现场有物件、某人有部件/姿态/能力或某事件发生。general-taxonomy编辑检索概念与worlds世界题材快照分账。新增Tag不会自动新增BodyGraph字段、天气模拟、职业服务或事实查询。

## 提案格式

使用schemas/proposal.schema.json。共同字段：mode、proposedId、label、dimension、definition、closestExisting、whyNotExisting。proposedId是建议名，不是已注册引用；词条不得抢先把它放进tagIds。

- attached：只写neededByLexemes，至少3条本批真实存在的词条ID；不写neededByPools/themes。
- advance：只写neededByPools及themes，至少一个合法池、至少两个02题材；不写neededByLexemes。

closestExisting必须是08的canonical ID或明确none；说明不同概念层/语义，不能只因前缀不同就重复创建。同义候选需结合别名和定义人工核查；机器只能查ID/引用，不能证明语义不重复。备注写批次说明，不塞进运行词条notes。

先行示例：{"mode":"advance","proposedId":"general-taxonomy:appearance.weariness","label":"疲惫神态","dimension":"actor.form","definition":"可见的眼下阴影或动作迟缓等当下疲惫表现；不凭外貌推断内在意愿","neededByPools":["actor.form"],"themes":["modern","cyberpunk"],"closestExisting":"general-taxonomy:v2.emotion.weariness","whyNotExisting":"既有词是内在情绪概念，拟议项限定观察者可核实的外在表现；还需整合方核查其他近义项"}。

## 命名与审批

开放建议前缀仅general-taxonomy下的appearance、sound、weather、material、part、color、shape、surface、common.object/env/action/job/tool/facility、expanded.scent。setting/place、foundation及新顶级命名空间不由外部作者扩充。小写、点分层级、连字符分词；提案不自动建立包依赖或授予能力。

每审批批最多40项。分别按mode检查需求；统一查canonical/别名/替代与全命名空间近义定义，人工审粒度及可判性。批准、合并、拒绝均记录理由，未决稿保留proposed，不能偷偷入库。T1可以交40–55条建议，但超过40项的批准拆为多个批次；数量上限不是强制增加无用Tag。

批准注册时同步：真实目标包的Tag定义、消费依赖、版本/指纹、05/08参考、业务与文案覆盖、最小引用/未知/停用测试。只往tags数组追加而不完成这些动作不算注册完毕。

## 互斥与矩阵

词条exclusive使用数组，例如[{"group":"temperature","value":"warm"}]。同主体同实例同组异值互斥，跨实例不互斥；excludes是双向生效的成对ID列表。它们不替代真实事实前置或系统的绑定/退出/分级约束。

既有九类矩阵由脚本生成实际来源/规则职责/任务阶段/缺口覆盖，不是作者手写9562格，也不是槽位词量报告。后者按入库词条聚合为另一个自动视图。规则保留完整语义，不为凑“≤30条”删除既有约束；新稿引用独立assemblyRuleId，拼装规则在独立assembly-rules.json中，不在矩阵格里复制正文。


## 完整输入文件：07-两层格式与转换契约.md

# 两层格式与转换契约 v1.3

作者层由01与schemas定义；运行层由独立assembly-rules.json和tools/runtime/assembly.mjs定义。tools/authoring.mjs是可执行的**中性测试快照转换参考**，不是游戏适配器，不创建人物/物件/动作、不写批准记录、不修改游戏状态。

## 转换表

| 作者层 | 运行层 |
| --- | --- |
| binding.subjectType | 独立审稿计划指定逻辑bindingKey，从权威快照取subject+instanceId；类型必须匹配 |
| pendingFacts + review=hold | 保留待补列表，不进入运行候选 |
| draft、已核实语义前置 | 构造一次性approved运行测试副本；通过全部验收后才可另行持久审批，不能先改原稿 |
| qualifierPlan | 按顺序转换为对应token的prefixPools，仅poolId/required/separator；无plan则不挂定词 |
| proseTemplate与prose | 添加checks T32–T37及完整规则外壳，fallbackTier始终general |
| 文字池对应的tagIds/theme | 登记/制作分类；实际场景资格由requires与对象查询提供，不能冒充已实现Tag过滤 |
| 专门感官子池 | 保留子池，并按02的runtimeAlsoIn加入通道中性的父池；绑定和感官通道条件不变 |
| place.current / actor.name | 生成displayRef:{field:'name'}词条，读取同revision精确绑定的唯一displayValues记录 |
| exit.current | 从真实免费退出动作生成text/actionId；next=null、零条件/零效果/零Tag改动 |

text与displayRef二选一；动态名字不二次展开模板、不执行HTML/代码、不改姓或重抽。旧存档/固定人物保留其已保存名称。主体名称相同不代表同一实例。

## 审核与测试顺序

1. 作者层Schema、版本、ID、池/槽/主体、查询引用先校验；原稿保持draft/hold。
2. 整合方核实词义涉及的全部事实和真实查询；无法映射的保留hold。自然语言真实性必须人工核对，不能靠一个Tag或机器字段检查代替。
3. 制定独立审稿计划：entryId、当前稿件SHA-256、bindingKey、已核查semanticFacts与跨对象relatedBindings；不能让作者自批。修改稿件后摘要不符必须重审。
4. 从可信快照解析唯一实例及事实记录。事实既要对应登记查询，也要绑定正确主体/实例。跨对象包含/持有等关系另有明确证据；不把多个候选随便选一个。
5. 只在临时运行副本中用approved跑严格词条校验和真实拼装器，检查正常/失败/状态不变/名称绑定/预算/退出/存档复现；测试副本不改变原稿审批状态。
6. 全部通过再进入独立的持久审批/入仓事务。此事务及游戏运行适配器尚未实装；本包工具只输出fixture-only结果。

中性闭环用10中的人工构造快照及独立测试审稿计划。其facts使用现有拼装器接受的snapshot/engine-query来源枚举，但每条均标明synthetic测试来源，不是假称调用了游戏查询。09的productionAdapterImplemented均为false，禁止把演示快照拿去给真实玩家背书。

## 定词的完整约定

主名“水” + 定词“过滤” + separator="" → 过滤水。
主名“黄铜” + 定词“带细纹” + separator="的" → 带细纹的黄铜。

定词和主名同实例；body.material与部件sameAs。required=false且无合法定词时只输出主名，required=true则整段回退；主名不存在时不留孤立定词。相同定词池不能在同一主名上重复挂载，词条末尾不写“的”，防止“的的”。不同实例可有不同温度，exclusive不跨实例全局互斥。

## 实施边界

本包完成作者格式、普通中性样例及离线验收参考。ENG仍需在工程中实现真实查询/Tag资格/模板选择/文本包/UI/存档接入；先一个普通节点端到端验证再扩大。T32/T34复核与免费出口不可因回退绕过，本包不新增年龄字段。其他分级稿件不在本包制作范围；任何扩展也必须保留完整普通回退与真实资格检查。


## 完整输入文件：09-事实目录.json

~~~json
{
  "specVersion": "1.3",
  "scope": "已冻结的中性fixture查询合同；真实游戏适配器未接入。未知查询走hold，不能由文本生成事实。",
  "facts": [
    {
      "id": "actor.present",
      "valueType": "boolean",
      "bindingKey": "actor",
      "meaning": "绑定人物在当前地点在场。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false
    },
    {
      "id": "part.kind",
      "valueType": "string",
      "bindingKey": "part",
      "meaning": "真实部件 kind。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false,
      "values": [
        "root",
        "head",
        "ear",
        "arm",
        "hand",
        "leg",
        "foot",
        "tail"
      ]
    },
    {
      "id": "part.changed",
      "valueType": "boolean",
      "bindingKey": "part",
      "meaning": "对照明确历史记录确认部件是否发生变化；无记录为未知。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false
    },
    {
      "id": "part.material",
      "valueType": "string",
      "bindingKey": "part",
      "meaning": "绑定部件的真实材质标识；不从正文或种族称呼推断。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false
    },
    {
      "id": "part.finish",
      "valueType": "string",
      "bindingKey": "part",
      "meaning": "绑定部件已记录的表面状态；生产查询尚未接入。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false
    },
    {
      "id": "action.observed",
      "valueType": "string",
      "bindingKey": "actor",
      "meaning": "已发生并记录的绑定人物动作，不由候选词创造。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false
    },
    {
      "id": "prop.kind",
      "valueType": "string",
      "bindingKey": "prop",
      "meaning": "绑定环境物件的真实类型。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false
    },
    {
      "id": "prop.contains",
      "valueType": "string",
      "bindingKey": "prop",
      "meaning": "物件所包含的另一个精确实例 ID。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false
    },
    {
      "id": "material.kind",
      "valueType": "string",
      "bindingKey": "material",
      "meaning": "绑定材料/流体的真实种类。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false
    },
    {
      "id": "water.filtered",
      "valueType": "boolean",
      "bindingKey": "material",
      "meaning": "当前水实例的过滤事实；不得借用另一杯水。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false
    },
    {
      "id": "sense.available",
      "valueType": "boolean",
      "bindingKey": "sense",
      "meaning": "当前地点该感知通道的记录可用。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false
    },
    {
      "id": "sense.channel",
      "valueType": "string",
      "bindingKey": "sense",
      "meaning": "感官通道。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false,
      "values": [
        "smell",
        "sound",
        "light",
        "thermal",
        "touch"
      ]
    },
    {
      "id": "sense.sample",
      "valueType": "string",
      "bindingKey": "sense",
      "meaning": "该通道当前已记录的具体感知内容。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false
    },
    {
      "id": "scene.setting",
      "valueType": "string",
      "bindingKey": "place",
      "meaning": "当前世界题材的权威快照值；不把编辑分类 Tag 当现场事实。",
      "mappingStatus": "fixture-only",
      "productionAdapterImplemented": false
    }
  ]
}

~~~


## 完整输入文件：schemas/word.schema.json

~~~json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Aetheria authoring word v1.3",
  "$ref": "#/$defs/word",
  "$defs": {
    "condition": {
      "type": "object",
      "properties": {
        "fact": {
          "type": "string",
          "minLength": 1
        },
        "comparison": {
          "enum": [
            "eq",
            "gte",
            "lte",
            "exists"
          ]
        },
        "value": {
          "type": [
            "string",
            "number",
            "boolean"
          ]
        }
      },
      "required": [
        "fact",
        "comparison"
      ],
      "additionalProperties": false
    },
    "word": {
      "type": "object",
      "properties": {
        "id": {
          "type": "string",
          "pattern": "^word\\.[a-z0-9]+(?:[.-][a-z0-9]+)*$"
        },
        "text": {
          "type": "string",
          "minLength": 1,
          "maxLength": 80
        },
        "allowedSlots": {
          "type": "array",
          "items": {
            "enum": [
              "place",
              "propEnv",
              "bodyPart",
              "senseMod",
              "actionCore",
              "materialFluid",
              "opponentForm",
              "exitChoice"
            ]
          },
          "minItems": 1,
          "maxItems": 1
        },
        "poolIds": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "minItems": 1,
          "maxItems": 1
        },
        "priority": {
          "type": "integer",
          "minimum": 1,
          "maximum": 999
        },
        "review": {
          "enum": [
            "draft",
            "hold"
          ]
        },
        "status": {
          "enum": [
            "active",
            "inactive"
          ]
        },
        "role": {
          "enum": [
            "core",
            "qualifier"
          ]
        },
        "binding": {
          "type": "object",
          "properties": {
            "subjectType": {
              "enum": [
                "location",
                "object",
                "person",
                "part",
                "event"
              ]
            }
          },
          "required": [
            "subjectType"
          ],
          "additionalProperties": false
        },
        "requires": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/condition"
          },
          "minItems": 0
        },
        "pendingFacts": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "excludes": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "exclusive": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "group": {
                "type": "string",
                "minLength": 1
              },
              "value": {
                "type": "string",
                "minLength": 1
              }
            },
            "required": [
              "group",
              "value"
            ],
            "additionalProperties": false
          },
          "minItems": 0
        },
        "contentTier": {
          "const": "general"
        },
        "tagIds": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        }
      },
      "required": [
        "id",
        "text",
        "allowedSlots",
        "poolIds",
        "priority",
        "review",
        "status",
        "role",
        "binding",
        "requires",
        "pendingFacts",
        "excludes",
        "exclusive",
        "contentTier",
        "tagIds"
      ],
      "additionalProperties": false
    },
    "token": {
      "type": "object",
      "properties": {
        "key": {
          "type": "string",
          "pattern": "^[A-Za-z][A-Za-z0-9_-]*$"
        },
        "slot": {
          "enum": [
            "place",
            "propEnv",
            "bodyPart",
            "senseMod",
            "actionCore",
            "materialFluid",
            "opponentForm",
            "exitChoice"
          ]
        },
        "poolId": {
          "type": "string",
          "minLength": 1
        },
        "bindTo": {
          "enum": [
            "place",
            "actor",
            "part",
            "prop",
            "material",
            "sense",
            "exit"
          ]
        },
        "required": {
          "type": "boolean"
        },
        "prefix": {
          "type": "string"
        },
        "suffix": {
          "type": "string"
        },
        "sameAs": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "subjectAs": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        }
      },
      "required": [
        "key",
        "slot",
        "poolId",
        "bindTo",
        "required",
        "prefix",
        "suffix"
      ],
      "additionalProperties": false
    },
    "template": {
      "type": "object",
      "properties": {
        "id": {
          "type": "string",
          "pattern": "^assembly\\.[a-z0-9]+(?:[.-][a-z0-9]+)*$"
        },
        "domain": {
          "enum": [
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09"
          ]
        },
        "mode": {
          "const": "prose"
        },
        "contentTier": {
          "const": "general"
        },
        "fallbackTier": {
          "const": "general"
        },
        "proseTemplate": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/token"
          },
          "minItems": 1,
          "maxItems": 16
        },
        "qualifierPlan": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "key": {
                "type": "string",
                "minLength": 1
              },
              "poolId": {
                "type": "string",
                "minLength": 1
              },
              "required": {
                "type": "boolean"
              },
              "separator": {
                "enum": [
                  "",
                  "的"
                ]
              }
            },
            "required": [
              "key",
              "poolId",
              "required",
              "separator"
            ],
            "additionalProperties": false
          },
          "minItems": 0
        },
        "prose": {
          "type": "string",
          "minLength": 1
        }
      },
      "required": [
        "id",
        "domain",
        "mode",
        "contentTier",
        "fallbackTier",
        "proseTemplate",
        "qualifierPlan",
        "prose"
      ],
      "additionalProperties": false
    },
    "preview": {
      "type": "object",
      "properties": {
        "templateId": {
          "type": "string",
          "minLength": 1
        },
        "entryIds": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "fixtureId": {
          "type": "string",
          "minLength": 1
        },
        "seed": {
          "type": "integer",
          "minimum": 0,
          "maximum": 4294967295
        },
        "revision": {
          "type": "integer",
          "minimum": 0
        },
        "mode": {
          "enum": [
            "manual",
            "reference-assembler"
          ]
        },
        "text": {
          "type": "string",
          "minLength": 1
        },
        "evidenceStatus": {
          "enum": [
            "hypothetical-only",
            "fixture-verified"
          ]
        }
      },
      "required": [
        "templateId",
        "entryIds",
        "fixtureId",
        "seed",
        "revision",
        "mode",
        "text",
        "evidenceStatus"
      ],
      "additionalProperties": false
    },
    "proposal": {
      "type": "object",
      "properties": {
        "mode": {
          "enum": [
            "attached",
            "advance"
          ]
        },
        "proposedId": {
          "type": "string",
          "pattern": "^[a-z][a-z0-9-]*:[a-z][a-z0-9.-]*$"
        },
        "label": {
          "type": "string",
          "minLength": 1
        },
        "dimension": {
          "type": "string",
          "minLength": 1
        },
        "definition": {
          "type": "string",
          "minLength": 1
        },
        "neededByLexemes": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "neededByPools": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "themes": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "closestExisting": {
          "type": "string",
          "minLength": 1
        },
        "whyNotExisting": {
          "type": "string",
          "minLength": 1
        }
      },
      "required": [
        "mode",
        "proposedId",
        "label",
        "dimension",
        "definition",
        "closestExisting",
        "whyNotExisting"
      ],
      "additionalProperties": false
    },
    "delivery": {
      "type": "object",
      "properties": {
        "format": {
          "const": "aetheria-authoring-delivery"
        },
        "specVersion": {
          "const": "1.3"
        },
        "task": {
          "enum": [
            "A1",
            "A2",
            "A3",
            "B1",
            "B2",
            "B3",
            "P0"
          ]
        },
        "theme": {
          "type": "string",
          "minLength": 1
        },
        "author": {
          "type": "string",
          "minLength": 1
        },
        "batchId": {
          "type": "string",
          "minLength": 1
        },
        "revision": {
          "type": "integer",
          "minimum": 1
        },
        "entries": {
          "type": "array",
          "items": {
            "anyOf": [
              {
                "$ref": "#/$defs/word"
              },
              {
                "$ref": "#/$defs/template"
              }
            ]
          },
          "minItems": 1
        },
        "handPreviews": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/preview"
          },
          "minItems": 0
        },
        "suggestedTags": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/proposal"
          },
          "minItems": 0
        },
        "notes": {
          "type": "string"
        }
      },
      "required": [
        "format",
        "specVersion",
        "task",
        "theme",
        "author",
        "batchId",
        "revision",
        "entries",
        "handPreviews",
        "suggestedTags"
      ],
      "additionalProperties": false
    },
    "tagBatch": {
      "type": "object",
      "properties": {
        "format": {
          "const": "aetheria-tag-proposals"
        },
        "specVersion": {
          "const": "1.3"
        },
        "task": {
          "const": "T1"
        },
        "author": {
          "type": "string",
          "minLength": 1
        },
        "batchId": {
          "type": "string",
          "minLength": 1
        },
        "revision": {
          "type": "integer",
          "minimum": 1
        },
        "suggestedTags": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/proposal"
          },
          "minItems": 1
        },
        "notes": {
          "type": "string"
        }
      },
      "required": [
        "format",
        "specVersion",
        "task",
        "author",
        "batchId",
        "revision",
        "suggestedTags"
      ],
      "additionalProperties": false
    }
  }
}

~~~


## 完整输入文件：schemas/delivery.schema.json

~~~json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Aetheria authoring delivery v1.3",
  "$ref": "#/$defs/delivery",
  "$defs": {
    "condition": {
      "type": "object",
      "properties": {
        "fact": {
          "type": "string",
          "minLength": 1
        },
        "comparison": {
          "enum": [
            "eq",
            "gte",
            "lte",
            "exists"
          ]
        },
        "value": {
          "type": [
            "string",
            "number",
            "boolean"
          ]
        }
      },
      "required": [
        "fact",
        "comparison"
      ],
      "additionalProperties": false
    },
    "word": {
      "type": "object",
      "properties": {
        "id": {
          "type": "string",
          "pattern": "^word\\.[a-z0-9]+(?:[.-][a-z0-9]+)*$"
        },
        "text": {
          "type": "string",
          "minLength": 1,
          "maxLength": 80
        },
        "allowedSlots": {
          "type": "array",
          "items": {
            "enum": [
              "place",
              "propEnv",
              "bodyPart",
              "senseMod",
              "actionCore",
              "materialFluid",
              "opponentForm",
              "exitChoice"
            ]
          },
          "minItems": 1,
          "maxItems": 1
        },
        "poolIds": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "minItems": 1,
          "maxItems": 1
        },
        "priority": {
          "type": "integer",
          "minimum": 1,
          "maximum": 999
        },
        "review": {
          "enum": [
            "draft",
            "hold"
          ]
        },
        "status": {
          "enum": [
            "active",
            "inactive"
          ]
        },
        "role": {
          "enum": [
            "core",
            "qualifier"
          ]
        },
        "binding": {
          "type": "object",
          "properties": {
            "subjectType": {
              "enum": [
                "location",
                "object",
                "person",
                "part",
                "event"
              ]
            }
          },
          "required": [
            "subjectType"
          ],
          "additionalProperties": false
        },
        "requires": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/condition"
          },
          "minItems": 0
        },
        "pendingFacts": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "excludes": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "exclusive": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "group": {
                "type": "string",
                "minLength": 1
              },
              "value": {
                "type": "string",
                "minLength": 1
              }
            },
            "required": [
              "group",
              "value"
            ],
            "additionalProperties": false
          },
          "minItems": 0
        },
        "contentTier": {
          "const": "general"
        },
        "tagIds": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        }
      },
      "required": [
        "id",
        "text",
        "allowedSlots",
        "poolIds",
        "priority",
        "review",
        "status",
        "role",
        "binding",
        "requires",
        "pendingFacts",
        "excludes",
        "exclusive",
        "contentTier",
        "tagIds"
      ],
      "additionalProperties": false
    },
    "token": {
      "type": "object",
      "properties": {
        "key": {
          "type": "string",
          "pattern": "^[A-Za-z][A-Za-z0-9_-]*$"
        },
        "slot": {
          "enum": [
            "place",
            "propEnv",
            "bodyPart",
            "senseMod",
            "actionCore",
            "materialFluid",
            "opponentForm",
            "exitChoice"
          ]
        },
        "poolId": {
          "type": "string",
          "minLength": 1
        },
        "bindTo": {
          "enum": [
            "place",
            "actor",
            "part",
            "prop",
            "material",
            "sense",
            "exit"
          ]
        },
        "required": {
          "type": "boolean"
        },
        "prefix": {
          "type": "string"
        },
        "suffix": {
          "type": "string"
        },
        "sameAs": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "subjectAs": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        }
      },
      "required": [
        "key",
        "slot",
        "poolId",
        "bindTo",
        "required",
        "prefix",
        "suffix"
      ],
      "additionalProperties": false
    },
    "template": {
      "type": "object",
      "properties": {
        "id": {
          "type": "string",
          "pattern": "^assembly\\.[a-z0-9]+(?:[.-][a-z0-9]+)*$"
        },
        "domain": {
          "enum": [
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09"
          ]
        },
        "mode": {
          "const": "prose"
        },
        "contentTier": {
          "const": "general"
        },
        "fallbackTier": {
          "const": "general"
        },
        "proseTemplate": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/token"
          },
          "minItems": 1,
          "maxItems": 16
        },
        "qualifierPlan": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "key": {
                "type": "string",
                "minLength": 1
              },
              "poolId": {
                "type": "string",
                "minLength": 1
              },
              "required": {
                "type": "boolean"
              },
              "separator": {
                "enum": [
                  "",
                  "的"
                ]
              }
            },
            "required": [
              "key",
              "poolId",
              "required",
              "separator"
            ],
            "additionalProperties": false
          },
          "minItems": 0
        },
        "prose": {
          "type": "string",
          "minLength": 1
        }
      },
      "required": [
        "id",
        "domain",
        "mode",
        "contentTier",
        "fallbackTier",
        "proseTemplate",
        "qualifierPlan",
        "prose"
      ],
      "additionalProperties": false
    },
    "preview": {
      "type": "object",
      "properties": {
        "templateId": {
          "type": "string",
          "minLength": 1
        },
        "entryIds": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "fixtureId": {
          "type": "string",
          "minLength": 1
        },
        "seed": {
          "type": "integer",
          "minimum": 0,
          "maximum": 4294967295
        },
        "revision": {
          "type": "integer",
          "minimum": 0
        },
        "mode": {
          "enum": [
            "manual",
            "reference-assembler"
          ]
        },
        "text": {
          "type": "string",
          "minLength": 1
        },
        "evidenceStatus": {
          "enum": [
            "hypothetical-only",
            "fixture-verified"
          ]
        }
      },
      "required": [
        "templateId",
        "entryIds",
        "fixtureId",
        "seed",
        "revision",
        "mode",
        "text",
        "evidenceStatus"
      ],
      "additionalProperties": false
    },
    "proposal": {
      "type": "object",
      "properties": {
        "mode": {
          "enum": [
            "attached",
            "advance"
          ]
        },
        "proposedId": {
          "type": "string",
          "pattern": "^[a-z][a-z0-9-]*:[a-z][a-z0-9.-]*$"
        },
        "label": {
          "type": "string",
          "minLength": 1
        },
        "dimension": {
          "type": "string",
          "minLength": 1
        },
        "definition": {
          "type": "string",
          "minLength": 1
        },
        "neededByLexemes": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "neededByPools": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "themes": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "closestExisting": {
          "type": "string",
          "minLength": 1
        },
        "whyNotExisting": {
          "type": "string",
          "minLength": 1
        }
      },
      "required": [
        "mode",
        "proposedId",
        "label",
        "dimension",
        "definition",
        "closestExisting",
        "whyNotExisting"
      ],
      "additionalProperties": false
    },
    "delivery": {
      "type": "object",
      "properties": {
        "format": {
          "const": "aetheria-authoring-delivery"
        },
        "specVersion": {
          "const": "1.3"
        },
        "task": {
          "enum": [
            "A1",
            "A2",
            "A3",
            "B1",
            "B2",
            "B3",
            "P0"
          ]
        },
        "theme": {
          "type": "string",
          "minLength": 1
        },
        "author": {
          "type": "string",
          "minLength": 1
        },
        "batchId": {
          "type": "string",
          "minLength": 1
        },
        "revision": {
          "type": "integer",
          "minimum": 1
        },
        "entries": {
          "type": "array",
          "items": {
            "anyOf": [
              {
                "$ref": "#/$defs/word"
              },
              {
                "$ref": "#/$defs/template"
              }
            ]
          },
          "minItems": 1
        },
        "handPreviews": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/preview"
          },
          "minItems": 0
        },
        "suggestedTags": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/proposal"
          },
          "minItems": 0
        },
        "notes": {
          "type": "string"
        }
      },
      "required": [
        "format",
        "specVersion",
        "task",
        "theme",
        "author",
        "batchId",
        "revision",
        "entries",
        "handPreviews",
        "suggestedTags"
      ],
      "additionalProperties": false
    },
    "tagBatch": {
      "type": "object",
      "properties": {
        "format": {
          "const": "aetheria-tag-proposals"
        },
        "specVersion": {
          "const": "1.3"
        },
        "task": {
          "const": "T1"
        },
        "author": {
          "type": "string",
          "minLength": 1
        },
        "batchId": {
          "type": "string",
          "minLength": 1
        },
        "revision": {
          "type": "integer",
          "minimum": 1
        },
        "suggestedTags": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/proposal"
          },
          "minItems": 1
        },
        "notes": {
          "type": "string"
        }
      },
      "required": [
        "format",
        "specVersion",
        "task",
        "author",
        "batchId",
        "revision",
        "suggestedTags"
      ],
      "additionalProperties": false
    }
  }
}

~~~


## 完整输入文件：schemas/proposal.schema.json

~~~json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Aetheria authoring proposal v1.3",
  "$ref": "#/$defs/proposal",
  "$defs": {
    "condition": {
      "type": "object",
      "properties": {
        "fact": {
          "type": "string",
          "minLength": 1
        },
        "comparison": {
          "enum": [
            "eq",
            "gte",
            "lte",
            "exists"
          ]
        },
        "value": {
          "type": [
            "string",
            "number",
            "boolean"
          ]
        }
      },
      "required": [
        "fact",
        "comparison"
      ],
      "additionalProperties": false
    },
    "word": {
      "type": "object",
      "properties": {
        "id": {
          "type": "string",
          "pattern": "^word\\.[a-z0-9]+(?:[.-][a-z0-9]+)*$"
        },
        "text": {
          "type": "string",
          "minLength": 1,
          "maxLength": 80
        },
        "allowedSlots": {
          "type": "array",
          "items": {
            "enum": [
              "place",
              "propEnv",
              "bodyPart",
              "senseMod",
              "actionCore",
              "materialFluid",
              "opponentForm",
              "exitChoice"
            ]
          },
          "minItems": 1,
          "maxItems": 1
        },
        "poolIds": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "minItems": 1,
          "maxItems": 1
        },
        "priority": {
          "type": "integer",
          "minimum": 1,
          "maximum": 999
        },
        "review": {
          "enum": [
            "draft",
            "hold"
          ]
        },
        "status": {
          "enum": [
            "active",
            "inactive"
          ]
        },
        "role": {
          "enum": [
            "core",
            "qualifier"
          ]
        },
        "binding": {
          "type": "object",
          "properties": {
            "subjectType": {
              "enum": [
                "location",
                "object",
                "person",
                "part",
                "event"
              ]
            }
          },
          "required": [
            "subjectType"
          ],
          "additionalProperties": false
        },
        "requires": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/condition"
          },
          "minItems": 0
        },
        "pendingFacts": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "excludes": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "exclusive": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "group": {
                "type": "string",
                "minLength": 1
              },
              "value": {
                "type": "string",
                "minLength": 1
              }
            },
            "required": [
              "group",
              "value"
            ],
            "additionalProperties": false
          },
          "minItems": 0
        },
        "contentTier": {
          "const": "general"
        },
        "tagIds": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        }
      },
      "required": [
        "id",
        "text",
        "allowedSlots",
        "poolIds",
        "priority",
        "review",
        "status",
        "role",
        "binding",
        "requires",
        "pendingFacts",
        "excludes",
        "exclusive",
        "contentTier",
        "tagIds"
      ],
      "additionalProperties": false
    },
    "token": {
      "type": "object",
      "properties": {
        "key": {
          "type": "string",
          "pattern": "^[A-Za-z][A-Za-z0-9_-]*$"
        },
        "slot": {
          "enum": [
            "place",
            "propEnv",
            "bodyPart",
            "senseMod",
            "actionCore",
            "materialFluid",
            "opponentForm",
            "exitChoice"
          ]
        },
        "poolId": {
          "type": "string",
          "minLength": 1
        },
        "bindTo": {
          "enum": [
            "place",
            "actor",
            "part",
            "prop",
            "material",
            "sense",
            "exit"
          ]
        },
        "required": {
          "type": "boolean"
        },
        "prefix": {
          "type": "string"
        },
        "suffix": {
          "type": "string"
        },
        "sameAs": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "subjectAs": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        }
      },
      "required": [
        "key",
        "slot",
        "poolId",
        "bindTo",
        "required",
        "prefix",
        "suffix"
      ],
      "additionalProperties": false
    },
    "template": {
      "type": "object",
      "properties": {
        "id": {
          "type": "string",
          "pattern": "^assembly\\.[a-z0-9]+(?:[.-][a-z0-9]+)*$"
        },
        "domain": {
          "enum": [
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09"
          ]
        },
        "mode": {
          "const": "prose"
        },
        "contentTier": {
          "const": "general"
        },
        "fallbackTier": {
          "const": "general"
        },
        "proseTemplate": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/token"
          },
          "minItems": 1,
          "maxItems": 16
        },
        "qualifierPlan": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "key": {
                "type": "string",
                "minLength": 1
              },
              "poolId": {
                "type": "string",
                "minLength": 1
              },
              "required": {
                "type": "boolean"
              },
              "separator": {
                "enum": [
                  "",
                  "的"
                ]
              }
            },
            "required": [
              "key",
              "poolId",
              "required",
              "separator"
            ],
            "additionalProperties": false
          },
          "minItems": 0
        },
        "prose": {
          "type": "string",
          "minLength": 1
        }
      },
      "required": [
        "id",
        "domain",
        "mode",
        "contentTier",
        "fallbackTier",
        "proseTemplate",
        "qualifierPlan",
        "prose"
      ],
      "additionalProperties": false
    },
    "preview": {
      "type": "object",
      "properties": {
        "templateId": {
          "type": "string",
          "minLength": 1
        },
        "entryIds": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "fixtureId": {
          "type": "string",
          "minLength": 1
        },
        "seed": {
          "type": "integer",
          "minimum": 0,
          "maximum": 4294967295
        },
        "revision": {
          "type": "integer",
          "minimum": 0
        },
        "mode": {
          "enum": [
            "manual",
            "reference-assembler"
          ]
        },
        "text": {
          "type": "string",
          "minLength": 1
        },
        "evidenceStatus": {
          "enum": [
            "hypothetical-only",
            "fixture-verified"
          ]
        }
      },
      "required": [
        "templateId",
        "entryIds",
        "fixtureId",
        "seed",
        "revision",
        "mode",
        "text",
        "evidenceStatus"
      ],
      "additionalProperties": false
    },
    "proposal": {
      "type": "object",
      "properties": {
        "mode": {
          "enum": [
            "attached",
            "advance"
          ]
        },
        "proposedId": {
          "type": "string",
          "pattern": "^[a-z][a-z0-9-]*:[a-z][a-z0-9.-]*$"
        },
        "label": {
          "type": "string",
          "minLength": 1
        },
        "dimension": {
          "type": "string",
          "minLength": 1
        },
        "definition": {
          "type": "string",
          "minLength": 1
        },
        "neededByLexemes": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "neededByPools": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "themes": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "closestExisting": {
          "type": "string",
          "minLength": 1
        },
        "whyNotExisting": {
          "type": "string",
          "minLength": 1
        }
      },
      "required": [
        "mode",
        "proposedId",
        "label",
        "dimension",
        "definition",
        "closestExisting",
        "whyNotExisting"
      ],
      "additionalProperties": false
    },
    "delivery": {
      "type": "object",
      "properties": {
        "format": {
          "const": "aetheria-authoring-delivery"
        },
        "specVersion": {
          "const": "1.3"
        },
        "task": {
          "enum": [
            "A1",
            "A2",
            "A3",
            "B1",
            "B2",
            "B3",
            "P0"
          ]
        },
        "theme": {
          "type": "string",
          "minLength": 1
        },
        "author": {
          "type": "string",
          "minLength": 1
        },
        "batchId": {
          "type": "string",
          "minLength": 1
        },
        "revision": {
          "type": "integer",
          "minimum": 1
        },
        "entries": {
          "type": "array",
          "items": {
            "anyOf": [
              {
                "$ref": "#/$defs/word"
              },
              {
                "$ref": "#/$defs/template"
              }
            ]
          },
          "minItems": 1
        },
        "handPreviews": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/preview"
          },
          "minItems": 0
        },
        "suggestedTags": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/proposal"
          },
          "minItems": 0
        },
        "notes": {
          "type": "string"
        }
      },
      "required": [
        "format",
        "specVersion",
        "task",
        "theme",
        "author",
        "batchId",
        "revision",
        "entries",
        "handPreviews",
        "suggestedTags"
      ],
      "additionalProperties": false
    },
    "tagBatch": {
      "type": "object",
      "properties": {
        "format": {
          "const": "aetheria-tag-proposals"
        },
        "specVersion": {
          "const": "1.3"
        },
        "task": {
          "const": "T1"
        },
        "author": {
          "type": "string",
          "minLength": 1
        },
        "batchId": {
          "type": "string",
          "minLength": 1
        },
        "revision": {
          "type": "integer",
          "minimum": 1
        },
        "suggestedTags": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/proposal"
          },
          "minItems": 1
        },
        "notes": {
          "type": "string"
        }
      },
      "required": [
        "format",
        "specVersion",
        "task",
        "author",
        "batchId",
        "revision",
        "suggestedTags"
      ],
      "additionalProperties": false
    }
  }
}

~~~

